# Release Checklist — tools-config-server

Follow every step in order. Verify at the end before declaring done.

## Steps

1. Bump version in `tools-server/package.json`
2. Update `tools-server/CHANGELOG.md` with new entry
3. **Verify `README.md` Supported Services table** matches `lib/usage.js` — add any new services, remove any removed ones
   - Also update the **`Streamliner-One/tools` install repo README** (Supported services table) to match — it's a separate file, not subtree-pushed
4. Commit: `git add tools-server/package.json tools-server/CHANGELOG.md tools-server/server.js && git commit -m "tools-server vX.Y.Z: <description>"`
5. Push to mel-memory: `git push origin master`
6. Tag: `git tag vX.Y.Z && git push origin vX.Y.Z`
7. **Pre-push diff review** — eyeball the tools-server slice that's about to go public:
   ```bash
   git diff --name-only <previous-tag>..HEAD -- tools-server/ | head -50
   git diff --stat <previous-tag>..HEAD -- tools-server/ | tail -5
   ```
   Look for: any path under `tools-server/data/` (vault content shouldn't be here — moved out 2026-05-25), any `.pem`/`.key` files, any unexpectedly large blob. If anything looks wrong, stop and investigate. This gate was added 2026-05-25 after the leak audit found 1.0.2+ tarballs had bundled the vault and the TLS key pair because the tar excludes were misspelled.
8. Subtree push to Streamliner: `git subtree push --prefix=tools-server streamliner main`
9. Create GitHub Release on `Streamliner-One/tools-config-server` via API (⚠️ tags do NOT transfer via subtree push — must be created explicitly)
10. Build artifact: `tar -czf tools-config-server-X.Y.Z.tar.gz --exclude='tools-server/node_modules' --exclude='tools-server/.certs' --exclude='tools-server/certs' --exclude='tools-server/data' --exclude='tools-server/.claude' --exclude='tools-server/*.log' --exclude='tools-server/tools-registry.json' --exclude='tools-server/.health-cache.json' tools-server/` (⚠️ excludes use the full `tools-server/<path>` form — the previous shorthand `--exclude=certs` did NOT match the actual `.certs/` dir, which is why TLS keys leaked into 1.0.2+ tarballs. Always verify with: `tar tzf <artifact> | grep -E "data|certs|node_modules" | head` — expected output: 0 lines.)
11. Upload artifact to `Streamliner-One/tools` → `artifacts/tools-config-server-X.Y.Z.tar.gz`
    ⚠️ **Do NOT inline base64 in curl args** — hits shell ARG_MAX. Use Python to write a temp payload file first:
    ```python
    import base64, json
    with open('artifact.tar.gz', 'rb') as f: content = base64.b64encode(f.read()).decode()
    with open('/tmp/upload-payload.json', 'w') as f:
        f.write(json.dumps({"message": "artifact: ...", "content": content}))
    ```
    Then: `curl ... -d @/tmp/upload-payload.json`
12. Update `Streamliner-One/tools` → `versions.json` (both `stable` and `latest` channels — version AND artifact_url)
13. Update `Streamliner-One/tools` → `README.md` channels table (both `stable` and `latest` rows) to match new version
    - Use targeted sed: `sed -i "s/| \`stable\` | [0-9.]* |/| \`stable\` | X.X.Y |/" README.md` (and same for `latest`)
    - ⚠️ Do NOT use a blanket version replace — it clobbers artifact URLs and other refs
14. Create GitHub Release on `Streamliner-One/tools`
15. Create GitHub Release on `Streamliner-One/tools-packages`

## Mandatory Verification

Run this and confirm all three show the new version before declaring done:

```bash
COOKIE=$(mktemp); trap "rm -f $COOKIE" EXIT
curl -sk -c "$COOKIE" -X POST https://100.84.57.51:8443/api/login \
  -H 'Content-Type: application/json' -d '{"password":"mel2026"}' >/dev/null
GH_TOKEN=$(curl -sk -b "$COOKIE" https://100.84.57.51:8443/api/credentials/github | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('primaryKey',''))")

for repo in "Streamliner-One/tools-config-server" "Streamliner-One/tools" "Streamliner-One/tools-packages"; do
  curl -s "https://api.github.com/repos/$repo/releases/latest" \
    -H "Authorization: Bearer $GH_TOKEN" | python3 -c "import sys,json; d=json.load(sys.stdin); print('$repo:', d.get('tag_name'))"
done
```

All three must match the new version. If any shows the old version — fix before declaring done.

Also verify the branch artifact exists and matches the new version:
```bash
curl -fI https://raw.githubusercontent.com/Streamliner-One/tools/main/artifacts/tools-config-server-X.Y.Z.tar.gz
# Expected: HTTP 200

curl -s https://raw.githubusercontent.com/Streamliner-One/tools/main/versions.json | grep "tools-config-server-X.Y.Z.tar.gz"
# Expected: artifact_url points to the same X.Y.Z file that actually exists on main
```

Also verify README channels table AND Supported Services are updated:
```bash
curl -s https://raw.githubusercontent.com/Streamliner-One/tools/main/README.md | grep -A3 "## Channels"
# Expected: both stable and latest showing the new version

curl -s https://raw.githubusercontent.com/Streamliner-One/tools/main/README.md | grep -A 40 "## Supported services"
# Expected: any new services added in this release appear in the correct category row
```

⚠️ The Supported Services table uses category rows like `| **Search** | Brave Search, Perplexity, ... |` — append to the value cell, don't add a new row. Verify the new service name actually appears in the fetched output before declaring done.

## Never Stage
`.health-cache.json`, `server.log`, `update-run.log`, `tools-registry.json`, `node_modules/`, `.certs/`, `data/obsidian-vault*/`, `.claude/`
