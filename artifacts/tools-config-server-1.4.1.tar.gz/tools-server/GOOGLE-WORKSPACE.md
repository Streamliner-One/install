# Google Workspace — Multi-Account Setup Guide

## Architecture

Google Workspace on this system uses **four components**:

1. **GCP OAuth Clients** — One per GCP project (Streamliner, Via Travel, etc.). Each is a "Desktop app" type with `http://localhost` redirect URI.
2. **Tools Server** — Manages OAuth flows (auth URL generation + token exchange), stores tokens in `~/.config/gws/credentials-{emailKey}.json`, and provides re-auth dashboard cards.
3. **gog CLI** — Lightweight daily driver for Gmail/Calendar/Drive/Contacts. Supports multi-account natively via `--account` and `--client` flags. Uses its own keyring + client credentials in `~/.config/gogcli/`.
4. **gws CLI** (`@googleworkspace/cli`) — Google's official CLI with broader API coverage (Admin, Chat, Meet, Vault, Keep, etc.). Single-account per config dir, multi-account via `GOOGLE_WORKSPACE_CLI_CONFIG_DIR` env var.

### File Layout

```
~/.config/gws/                                   # gws config dir (Streamliner account)
├── client_secret.json                           #   Streamliner OAuth client (Desktop app)
├── client_secret-alexey_prudkov_via_travel.json #   Via Travel client (used by tools server OAuth flow)
├── credentials.json                             #   Active gws credentials (= Streamliner)
├── credentials-alexey_streamliner_one.json      #   Token for alexey@streamliner.one
├── credentials-alexey_prudkov_via_travel.json   #   Token for alexey.prudkov@via.travel
├── token_cache.json                             #   gws token cache
└── .encryption_key                              #   Encryption key (gws + gog shared)

~/.config/gws-via-travel/                        # Via Travel gws config dir
├── client_secret.json                           #   Via Travel OAuth client (Desktop app)
├── credentials.json                             #   Via Travel token
└── token_cache.json                             #   Separate token cache

~/.config/gogcli/                                # gog client credentials (flat format)
├── credentials-alexey_streamliner_one.json   #   Streamliner client (explicit name)
└── credentials-alexey_prudkov_via_travel.json   #   Via Travel client
```

### Which Tool for What

| Tool | Multi-account | Use for |
|------|---------------|---------|
| **gog** | Native (`--client`) | Daily Gmail/Calendar/Drive/Contacts. Primary tool. Use `--client <name>`, NOT `--account <email>`. |
| **gws** | Via config dir (`GOOGLE_WORKSPACE_CLI_CONFIG_DIR`) | Admin, Chat, Meet, Vault, Keep, Forms, Classroom, Slides, Tasks — APIs gog doesn't cover. |

Default: use gog. Reach for gws only when you need an API gog doesn't have.

### Key Rules

- **Each GCP project gets its own OAuth client** (Desktop app type). Tokens are bound to the client that issued them.
- **Per-account client secrets** in `~/.config/gws/` follow the naming pattern `client_secret-{emailKey}.json` where `emailKey` = email with `@` and `.` replaced by `_`.
- **gog client credentials** in `~/.config/gogcli/` must be **flat format**: `{"client_id": "...", "client_secret": "..."}` — NOT the nested Google JSON format.
- **Tools server credential cards** (`google-workspace` package) are NOT needed. The OAuth flow cards at the top of the dashboard are authoritative. Delete any legacy credential cards.

---

## Adding a New Account (Step by Step)

### Prerequisites

- A Google Workspace domain with the target account
- Admin access to GCP Console for that domain's project
- The tools server running on this machine

### Step 1: GCP Setup

1. Go to [Google Cloud Console](https://console.cloud.google.com)
2. Select (or create) the GCP project for this organization
3. **APIs & Services → Library** — Enable:
   - Gmail API
   - Google Calendar API
   - Google Drive API
   - Google People API
   - Google Docs API
   - Google Sheets API
4. **APIs & Services → OAuth consent screen**:
   - User Type: **Internal** (if Workspace domain — gives permanent tokens, no 7-day expiry)
   - App name: `<Company> Tools`
   - Support email + developer contact: the account being added
5. **APIs & Services → Credentials → Create Credentials → OAuth client ID**:
   - Application type: **Desktop app** ← CRITICAL — NOT "Web application"
   - Name: `<Company> Tools Server`
6. Download the JSON → it should have `"installed"` type with `"redirect_uris": ["http://localhost"]`

### Step 2: Install Client Secret

```bash
# Compute the email key
EMAIL="user@domain.com"
EMAIL_KEY=$(echo "$EMAIL" | tr '@.' '_')

# Save the Desktop app JSON as the per-account client secret
cp downloaded_client_secret.json ~/.config/gws/client_secret-${EMAIL_KEY}.json

# Also create the flat version for gog CLI
jq '{client_id: .installed.client_id, client_secret: .installed.client_secret}' \
  ~/.config/gws/client_secret-${EMAIL_KEY}.json \
  > ~/.config/gogcli/credentials-${EMAIL_KEY}.json
```

### Step 3: Configure Scopes (if needed)

The tools server has per-account scope overrides in `server.js`:

```javascript
const GWS_ACCOUNT_SCOPES = {
  'alexey_prudkov_via_travel': GWS_SCOPES_READONLY
};
```

- Default: full read/write access (`GWS_SCOPES_FULL`)
- Add an entry here for read-only accounts

After changing: restart tools server (`systemctl --user restart tools-config-server`).

### Step 4: Run OAuth Flow

Via tools server API:

```bash
COOKIE=$(mktemp); trap "rm -f $COOKIE" EXIT
curl -s -c "$COOKIE" -X POST http://localhost:8080/api/login \
  -H 'Content-Type: application/json' -d '{"password":"mel2026"}' >/dev/null

# Start OAuth — account param triggers per-account client + scopes
curl -s -b "$COOKIE" -X POST http://localhost:8080/api/oauth/google/start \
  -H 'Content-Type: application/json' \
  -d '{"account":"user@domain.com"}' | jq '.'
```

This returns an `authUrl` and `sessionId`.

1. Open `authUrl` in browser
2. Sign in as the target account
3. Consent to permissions
4. Browser redirects to `http://localhost?code=...` — page will fail to load
5. Copy the **full URL** from the browser address bar
6. Complete the exchange:

```bash
curl -s -b "$COOKIE" -X POST http://localhost:8080/api/oauth/google/complete \
  -H 'Content-Type: application/json' \
  -d '{"sessionId":"<sessionId>","callbackUrlOrCode":"<full-redirect-url>"}'
```

### Step 5: Import Token into gog Keyring

The tools server saved the token to `~/.config/gws/credentials-${EMAIL_KEY}.json`, but gog uses its own keyring. Import it:

```bash
# Build gog-compatible import file
REFRESH=$(jq -r '.refresh_token' ~/.config/gws/credentials-${EMAIL_KEY}.json)
cat > /tmp/gog-import.json <<EOF
{
  "email": "user@domain.com",
  "client": "${EMAIL_KEY}",
  "services": ["calendar", "contacts", "docs", "drive", "gmail", "sheets"],
  "scopes": [<list of granted scopes>],
  "created_at": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "refresh_token": "$REFRESH"
}
EOF

# Delete old token if exists, then import
GOG_KEYRING_PASSWORD=$(cat ~/.openclaw/workspace/memory/gog_keyring_password.txt) \
  gog auth tokens delete user@domain.com --force 2>/dev/null
GOG_KEYRING_PASSWORD=$(cat ~/.openclaw/workspace/memory/gog_keyring_password.txt) \
  gog auth tokens import /tmp/gog-import.json

rm -f /tmp/gog-import.json
```

### Step 6: Set Up gws Config Dir

gws uses one account per config directory. Create a dedicated dir for the new account:

```bash
mkdir -p ~/.config/gws-${SHORT_NAME}  # e.g. gws-via-travel, gws-acme
cp ~/.config/gws/client_secret-${EMAIL_KEY}.json ~/.config/gws-${SHORT_NAME}/client_secret.json
cp ~/.config/gws/credentials-${EMAIL_KEY}.json ~/.config/gws-${SHORT_NAME}/credentials.json
```

Test it:
```bash
GOOGLE_WORKSPACE_CLI_CONFIG_DIR=~/.config/gws-${SHORT_NAME} gws auth status
```

### Step 7: Verify Both Tools

```bash
# Test with gog (native multi-account)
GOG_KEYRING_PASSWORD=$(cat ~/.openclaw/workspace/memory/gog_keyring_password.txt) \
  gog calendar list --account user@domain.com --client ${EMAIL_KEY}

# Test with gws (config dir switching)
GOOGLE_WORKSPACE_CLI_CONFIG_DIR=~/.config/gws-${SHORT_NAME} \
  gws calendar calendarList list --params '{"maxResults": 2}' --format table
```

---

## Current Accounts

| Account | GCP Project | Client Type | gog Client | Scopes | Token Expiry |
|---------|-------------|-------------|------------|--------|-------------|
| alexey@streamliner.one | streamliner-one | Desktop app | `alexey_streamliner_one` | Full read/write | Permanent (Internal) |
| alexey.prudkov@via.travel | ornate-hangar-203215 | Desktop app | `alexey_prudkov_via_travel` | Read-only | Permanent (Internal) |

---

## Common Mistakes to Avoid

1. **Creating a "Web application" client instead of "Desktop app"** — Web apps require explicitly registered redirect URIs. Desktop apps automatically allow `http://localhost`. Always use Desktop app.

2. **Using the nested Google JSON in gogcli/** — gog expects flat `{client_id, client_secret}`. The Google-downloaded JSON has `{installed: {client_id, ...}}`. Always flatten with jq.

3. **Mixing OAuth clients** — A refresh token is bound to the client_id that issued it. If you auth with Client A but try to refresh with Client B, it fails with `invalid_grant`. Keep per-account clients consistent across tools server and gog.

4. **Using `--account` flag with gog** — `--account <email>` does not reliably resolve to the correct client for all accounts. Always use `--client <clientName>` instead. Run `gog auth list` to see the mapping of email → client name.

5. **Using `gog gmail get <messageId>` instead of `thread get`** — `get` fetches a single message only. If the thread has replies, you'll miss them. Always use `gog gmail thread get <threadId> --client <client> --full` to read the entire thread.

6. **Using "External" consent screen for Workspace domains** — External = test mode = 7-day token expiry. Always use "Internal" for Workspace domains.

---

## Re-authentication

When a token expires or needs refresh:

1. Go to tools server dashboard → click "Re-authorize" on the account's OAuth card
2. Follow the same paste-URL flow as Step 4 above
3. Re-import the new token into gog keyring (Step 5)

Or via API: repeat Steps 4-5 with the same account.

---

## Troubleshooting

| Error | Cause | Fix |
|-------|-------|-----|
| `redirect_uri_mismatch` | Wrong client type (Web instead of Desktop) | Create Desktop app client in GCP |
| `invalid_grant` | Token was issued by a different client_id | Re-auth with the correct per-account client |
| `stored credentials.json is missing client_id` | gog client file is nested Google format | Flatten: `jq '{client_id: .installed.client_id, client_secret: .installed.client_secret}'` |
| Token expires after 7 days | OAuth consent screen is "External" (test mode) | Switch to "Internal" in GCP |
| `Integrity check failed` | Wrong gog keyring password | Read from `memory/gog_keyring_password.txt` |
| gws shows wrong account | `credentials.json` in config dir has wrong token | Check config dir — default `~/.config/gws/` is Streamliner; use `GOOGLE_WORKSPACE_CLI_CONFIG_DIR` for others |
| gws client_id mismatch | `client_secret.json` and `credentials.json` issued by different clients | Ensure both files in the same config dir use the same GCP project's client |
