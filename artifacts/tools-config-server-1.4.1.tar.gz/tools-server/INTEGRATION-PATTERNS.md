# Integration Patterns

Reference for package authors and agent integrators. Covers the non-obvious
behaviors of the request-rendering layer in `lib/usage.js` and the example/run
endpoint in `server.js`. The auto-generated `TOOLS-REFERENCE.md` describes the
*surface* (what each credential does); this file describes the *plumbing* (how
the server gets requests onto the wire).

Audience: anyone adding a new package, fixing an existing one, or wiring a fresh
agent (Mel, Hermes, future installs) to consume the server's `example/run` API.

---

## 1. Two diagnostic axes (validator vs example/run)

Every credential has two independent health signals:

| Axis | Endpoint | What it confirms | Cost |
|---|---|---|---|
| **Validator** | `POST /api/services/<id>/validate` | Auth is alive, upstream is reachable. | Cheap, runs twice a day per package's `validator.js`. The dashboard's "Test" button hits this. |
| **example/run** | `POST /api/credentials/<id>/example/run` | The full agent-facing call shape returns useful data with default params. | Whatever the upstream call costs (paid endpoints incur per-call cost). On-demand. |

Both are needed: validator catches token drift, `example/run` catches interface
fluidity drift (param shape changes, stale endpoint URLs, deprecated API versions,
type-coercion bugs). The smoke test at `scripts/smoke-test-credentials.sh` runs
both and reports a two-axis status per credential.

A credential can have `validator: true, run: 401` — that's not a credential
problem, that's an interface bug in the package definition (wrong endpoint,
wrong header, missing User-Agent, etc.). Fix the package, not the credential.

---

## 2. The render → run → direct progression

When an agent wants to call a credentialed service, three patterns are
available, in priority order:

### A. `POST /api/credentials/<id>/example/run` — server executes server-side

Server fills in creds, executes the upstream call, returns `{request, response}`.
Cleanest path: agent never holds the bare API key, the response comes back
JSON-parseable, and the 60-second server-side timeout is generous for LLM calls.

Body shape: `{"params": {"<key>": <value>, ...}}`. Pass the params envelope;
top-level keys outside `params` are ignored.

Use as the default for simple, single-endpoint integrations.

### B. `POST /api/credentials/<id>/example/render` — preview only, secrets redacted

Returns the templated request shape (`{rendered: {method, url, headers, body}}`)
with secrets in headers and known-sensitive body fields replaced by
`***redacted***`. Marked in the server source as "safe preview + copy curl"
because it's the dashboard's copy-curl-as-illustration endpoint.

Use this for inspection (what params does this take, what URL does it hit,
what's the body shape) before calling `run`. Do not try to execute the rendered
request directly — secrets are stripped.

### C. Direct upstream call — pull credential, call upstream yourself

For when the package's templated example doesn't cover your use case (different
model, streaming, non-default endpoint, multi-step OAuth dance, etc.). Pull the
key from `GET /api/credentials/<id>`, build the upstream request yourself.

Always use Pattern A first; reach for C only when A doesn't fit.

---

## 3. Patterns the rendering layer supports

Four behaviors that are easy to miss when authoring or reading packages:

### 3.1 OAuth token auto-substitution

Headers can contain the sentinel `OAUTH_AUTO_TOKEN` or `{{__OAUTH_TOKEN__}}`.
Before calling `renderRequest`, the example/run handler in `server.js` checks
each header for the sentinel; if present, it calls `resolveOAuthToken(id, cred)`
and substitutes the live token in.

Example (amadeus uses this today):

```javascript
amadeus: {
  ...
  request: {
    headers: { 'Authorization': 'Bearer {{__OAUTH_TOKEN__}}' }
  }
}
```

The server has the OAuth dance already implemented for amadeus
(`client_credentials` grant against `/v1/security/oauth2/token`); future
OAuth-flow packages just need to:
1. Use the sentinel in the request headers
2. Add their package's branch to `resolveOAuthToken` in `server.js`

### 3.2 Function defaults (time-sensitive params)

A param's `default` can be a function evaluated at request time:

```javascript
{ key: 'departureDate', type: 'date', required: true,
  default: () => new Date(Date.now() + 14 * 86400000).toISOString().slice(0,10) }
```

`mergeParams` in `lib/usage.js` calls the function on each request, so the
value stays fresh. Use this for any param that would otherwise rot:

- Future-dated travel queries (flight searches, hotel availability)
- Time-window queries (logs from the last hour, recent commits)
- Anything where a static literal would silently drift past validity

The function is called with no arguments. If you need access to the credential's
fields, use `key('fieldName')` instead — see 3.3.

### 3.3 Credential-field-backed defaults

A param's `default` can pull from the credential's stored fields via the
`key()` helper exposed inside `getExampleDefinition`:

```javascript
{ key: 'database_id', type: 'string', required: true,
  default: key('dbTodos', 'YOUR_DB_ID') }
```

`key('dbTodos', 'YOUR_DB_ID')` returns `fields.dbTodos.value` if set, otherwise
the fallback string. Evaluated when `getExampleDefinition` is called (each
request), so changes to the credential's fields are picked up without a restart.

Use this when the example needs a real ID that's stored on the credential
(database IDs, vault names, default workspace IDs, default project keys, etc.).
This is what makes Notion's example actually query a real database rather
than a placeholder.

### 3.4 Type-aware body substitution

Body params declared with `type: 'int' | 'integer' | 'number'` or `'bool' | 'boolean'`
keep their declared type through render. The substitution is per-leaf rather
than stringify-template-parse, so:

```javascript
notion: {
  params: [
    { key: 'page_size', type: 'int', required: false, default: 10 }
  ],
  request: {
    body: { page_size: '{{page_size}}' }   // template substitutes 10 (number), not "10" (string)
  }
}
```

Notion's API rejected `"page_size": "10"` with `"body.page_size should be a
number or undefined, instead was \"10\""`. The new substitution preserves the
type, so the body becomes `{"page_size": 10}` and the call succeeds.

Any future package with int/number/bool body params is automatically correct.
For string params the behavior is unchanged.

---

## 4. Per-credential gotchas worth documenting

Things that bite when an unfamiliar agent picks up the server:

### 4.1 CLI-shadowed credentials

Some integrations are deliberately "the server holds the auth, but the CLI does
the work":

| Credential | CLI | Reason |
|---|---|---|
| `1password` | `op` | The right pattern for agents is `export OP_SERVICE_ACCOUNT_TOKEN=$(curl .../api/credentials/1password-<ts> | jq -r '.fields.serviceAccountToken.value'); op read "op://<vault>/<item>/<field>"`. The credential's `usage.summary` documents this explicitly. |
| `google-workspace` | `gog` (gogcli) or `gws` (@googleworkspace/cli) | Similar: token is in the keyring, the CLI does the actual API calls. The credential's `usage.summary` says "Use gog CLI with keyring password from local file." |

For these, `example/run` will return canned/empty responses by design.
`usage.summary` and `usage.expected` are the authoritative guide.

### 4.2 Multi-sub-endpoint credentials

Some credentials cover several upstream endpoints with different auth shapes
or payloads. The package's example targets one canonical endpoint; the others
need direct upstream calls (Pattern C):

| Credential | Endpoints covered | example/run targets | Others via direct |
|---|---|---|---|
| `tavily` | `/search`, `/extract`, `/crawl`, `/map` | `/search` | `/extract`, `/crawl`, `/map` (different auth) |
| `agentmail` | several inbox/messages endpoints | one (per `usage`) | rest documented in `usage.additionalCalls` |

`usage.additionalCalls` documents these — the dashboard renders them as a list.
The smoke test marks them ⚠️ partial-by-design.

### 4.3 n8n-mediated credentials

Some credentials are stored on the server for **another service to consume**,
not for the agent to call directly. `oura` is the canonical example: its data
flow is Oura → n8n → agent. The credential exists so n8n can authenticate,
not so the agent can call Oura directly. Calling `example/run` on these will
fail (or return data shaped for n8n's consumer).

These should be flagged in `usage.summary` (e.g. "Oura OAuth2 configured (n8n)")
and agents should treat them as not-direct-callable.

### 4.4 Geo-split APIs

Some upstreams have parallel deployments with non-interchangeable keyspaces:

- Moonshot: `api.moonshot.ai` (international) vs `api.moonshot.cn` (China). A
  key issued for one geo will 401 on the other. Match the package's `request.url`
  to the geo your key is registered with.

When this kind of split exists, the package's `commonError` field should call
it out so future maintainers don't get tripped.

### 4.5 Required headers

A few APIs have non-obvious mandatory headers:

- **GitHub** requires a `User-Agent` on every request, otherwise responds with
  HTTP 403 *"Request forbidden by administrative rules"*.
- **NewsAPI** requires a `User-Agent`; otherwise HTTP 400 *"Anonymous requests
  are not allowed"*.

When in doubt, set `User-Agent: 'OpenClaw-Tools-Server/1.0'`.

### 4.6 API version drift

Some upstreams change endpoints on version bumps. When a `Notion-Version` or
`OpenAI-Version` header is involved, picking the wrong version can route
to a deprecated endpoint:

- Notion `2022-06-28` retains `/v1/databases/{id}/query`.
- Notion `2025-09-03` deprecated that path; queries now go to
  `/v1/data_sources/{id}/query` with different (data-source) IDs.

Pin a stable version in the package's `request.headers` and document the
constraint in `summary`. Avoid bleeding-edge versions unless the example
specifically tests new functionality.

---

## 5. Credential ids vs router provider names

The router file uses bare provider names (`tavily`, `1password`, `notion`).
Actual stored credentials may carry a timestamp suffix appended at creation
(`tavily-1773478046285`, `1password-1772377672167`). The server resolves both
forms — `GET /api/credentials/tavily` and `GET /api/credentials/tavily-<ts>`
both work — but be aware of the duality when scripting.

To list canonical IDs:

```bash
curl -s -b "$COOKIE" http://localhost:8080/api/credentials \
  | jq '.credentials | keys'
```

---

## 6. Smoke test as ongoing diagnostic

`scripts/smoke-test-credentials.sh` runs both axes (validator + example/run)
across every credential and writes `CREDENTIALS-SMOKE.md`. Re-runnable any
time. Hits the wire on each run, including paid endpoints (Perplexity, Tavily,
etc.) — that's deliberate, paid endpoints should be tested too.

Status legend (in CREDENTIALS-SMOKE.md):

- ✅ **both-pass**: validator ok, example/run ok
- 🪪 **cli-shadowed**: validator ok, by-design uses local CLI
- 🔧 **interface-bug**: validator ok, example/run fails — server-side or
  package-definition issue, **not a credential health problem**
- ⚠️ **partial**: validator ok, example/run partial (sub-endpoints, etc.)
- 🚫 **not-runnable**: no usage definition (agent-config credentials)
- 🔒 **credential-broken**: validator fails — fix in dashboard
- ❓ **no-validator**: no validator configured (degraded confidence)

The smoke test exits non-zero only on 🔒. Everything else is informational
(by design, fixable in package definition, or transient like rate limits).

When wiring a fresh agent install to this server, run the smoke test first
to know which credentials are usable and how. Treat the output as a contract:
"these are the credentials that will work for you, in the call shape documented."

---

## 7. Authoring checklist for new packages

When adding a new integration to `lib/usage.js`:

1. **`title`** — short human-friendly name.
2. **`summary`** — what this call does. If CLI-shadowed, n8n-mediated, or
   sub-endpoint-partial, say so explicitly here. The smoke test reads this.
3. **`allowedHosts`** — array of upstream hosts the request may target. Used
   as a guard in `renderRequest`.
4. **`params`** — declare types (`'string' | 'int' | 'number' | 'bool' | 'date'`).
   Defaults can be literal values, function returns, or `key('fieldName', fallback)`
   to pull from the credential's fields.
5. **`request`** — `{method, url, headers, body}`. Use `${key('apiKey')}` for
   credential interpolation, `{{paramName}}` for param substitution, and
   `OAUTH_AUTO_TOKEN` (or `{{__OAUTH_TOKEN__}}`) in headers for OAuth-flow auth.
6. **`expected`** — one-line description of the success-shape response.
7. **`commonError`** — common upstream errors and what they mean. Useful for
   the smoke test classifier and for human debugging.
8. **`docs`** — link to upstream API documentation.
9. **`additionalCalls`** (optional) — array of related sub-endpoints with their
   own params and curl templates, for multi-endpoint integrations.

After adding, add a `validator.js` to the package directory if the auth shape
isn't already covered by a generic validator, and wire it through the server's
`packageValidators` loader.

---

## 8. Recent fixes (2026-04-26)

These changes shipped in the session that produced this document. Useful to
know if you're reading old code or migrating from an older agent install:

- **`runRenderedRequest` timeout** bumped from 15s → 60s (LLM calls regularly
  exceed 15s; the 15s was too tight).
- **`OAUTH_AUTO_TOKEN` substitution** added to the example/run handler in
  `server.js` (was a known unresolved placeholder before; agents calling
  amadeus via example/run got 401).
- **Function defaults** added to `mergeParams` in `lib/usage.js`. Any param's
  `default` can now be a function evaluated at request time.
- **Type-aware body substitution** added to `renderRequest`. Body params with
  declared types `int|number|bool` keep their type through render.
- **Notion package**: default `database_id` switched from `dbHome` (a page,
  not a database) to `key('dbTodos', 'YOUR_DB_ID')`; `Notion-Version` pinned
  to `2022-06-28` (the `/v1/databases/{id}/query` endpoint was deprecated in
  `2025-09-03`).
- **Amadeus package**: `departureDate` is now a function default (today + 14
  days) so the example never goes stale.
- **NewsAPI package**: dropped `language` (not valid for `/v2/top-headlines`),
  added required `User-Agent` header.
- **GitHub package**: added required `User-Agent` header.
- **Moonshot package**: `api.moonshot.cn` → `api.moonshot.ai` to match the
  geo where Alex's key is registered.
- **NanoBanana package**: model name updated from
  `gemini-2.0-flash-preview-image-generation` → `gemini-2.5-flash-image`
  (the older preview was retired).

For history, see `CHANGELOG.md`.
