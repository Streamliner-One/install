# Tools Server Credentials Smoke Test

Generated: `2026-04-26 17:13:59 UTC` by `scripts/smoke-test-credentials.sh`

Two axes per credential:
  - **Validator** (dashboard Test button): is auth + upstream reachable?
  - **example/run**: does the templated agent call deliver useful data?

Statuses:
  - ✅ both-pass: validator ok, example/run ok
  - 🪪 cli-shadowed: validator ok, by-design uses local CLI (op, gog, gws)
  - 🔧 interface-bug: validator ok, example/run fails — server-side issue, do NOT touch credential
  - ⚠️ partial: validator ok, example/run returns partial (sub-endpoints, slow LLM, missing params)
  - 🚫 not-runnable: no usage definition (agent-config credentials)
  - 🔒 credential-broken: validator fails — fix in dashboard
  - ❓ no-validator: no validator configured (degraded confidence)

| Category | Credential | Validator | example/run | Status | Notes |
|---|---|---|---|---|---|
| logistics | `17track` | ✅ | ✅ | ✅ | —  |
| security | `1password-1772377672167` | ✅ | 🪪 | 🪪 | CLI-shadowed by design: List accessible vaults via op CLI. Not a direct API call — use op CLI.  |
| communication | `agentmail-1775661022286` | ✅ | ⚠️ | ⚠️ | Partial: 3 sub-endpoint(s) not covered by run  |
| travel | `amadeus` | ✅ | ✅ | ✅ | —  |
| ai | `anthropic` | ✅ | ✅ | ✅ | —  |
| travel | `aviationstack` | ✅ | ✅ | ✅ | —  |
| search | `brave` | ✅ | ⚠️ | 🔧 | Interface bug (validator passed): upstream HTTP 429  |
| travel | `duffel` | ✅ | ✅ | ✅ | —  |
| travel | `duffel-1775151120476` | ✅ | ✅ | ✅ | —  |
| voice | `elevenlabs` | ✅ | ✅ | ✅ | —  |
| dev | `github-1772381712551` | ✅ | ✅ | ✅ | —  |
| ai | `google` | ✅ | ✅ | ✅ | —  |
| productivity | `google-workspace` | ✅ | 🪪 | 🪪 | CLI-shadowed by design: Not a direct API call. Use gog CLI with keyring password from local file.  |
| productivity | `google-workspace-1774994448595` | ✅ | 🪪 | 🪪 | CLI-shadowed by design: Not a direct API call. Use gog CLI with keyring password from local file.  |
| location | `goplaces` | ✅ | ✅ | ✅ | —  |
| support | `groove-1773006512027` | ✅ | ✅ | ✅ | —  |
| productivity | `holidays-nager` | ✅ | ✅ | ✅ | —  |
| agent | `mel` | ✅ | ✅ | ✅ | —  |
| memory | `mem0-1772718450954` | ✅ | ✅ | ✅ | —  |
| ai | `moonshot` | ✅ | ✅ | ✅ | —  |
| automation | `n8n` | ✅ | ✅ | ✅ | —  |
| image | `nanoBanana` | ✅ | ✅ | ✅ | —  |
| news | `newsapi` | ✅ | ✅ | ✅ | —  |
| productivity | `notion` | ✅ | ✅ | ✅ | —  |
| knowledge | `obsidian-sync-1772811314474` | ✅ | ✅ | ✅ | —  |
| ai | `ollama-1775913038809` | ✅ | ✅ | ✅ | —  |
| ai | `openai` | ✅ | ✅ | ✅ | —  |
| finance | `openexchangerates` | ✅ | ✅ | ✅ | —  |
| ai | `openrouter-1773159277741` | ✅ | ✅ | ✅ | —  |
| travel | `osrm-1774428601390` | ✅ | ✅ | ✅ | —  |
| health | `oura` | ✅ | ⚠️ | 🔧 | Interface bug (validator passed): upstream HTTP 401  |
| ai | `perplexity` | ✅ | ✅ | ✅ | —  |
| vector-db | `pinecone` | ✅ | ✅ | ✅ | —  |
| knowledge | `readwise-1772811314235` | ✅ | ✅ | ✅ | —  |
| payment | `stripe-1772374510905` | ✅ | ✅ | ✅ | —  |
| search | `tavily-1773478046285` | ✅ | ⚠️ | ⚠️ | Partial: 2 sub-endpoint(s) not covered by run  |
| messaging | `telegram` | ✅ | ✅ | ✅ | —  |
| productivity | `todoist` | ✅ | ✅ | ✅ | —  |
| voice | `vapi` | ✅ | ✅ | ✅ | —  |
| lifestyle | `weather` | ✅ | ✅ | ✅ | —  |
| audio | `whisper` | ✅ | ✅ | ✅ | —  |

## Summary

- Total credentials: 41
- ✅ both-pass: 34
- 🪪 cli-shadowed (by design): 3
- 🔧 interface-bug (validator ok, server-side run issue): 2
- ⚠️ partial (sub-endpoints, slow LLMs, missing params): 2
- 🚫 not-runnable (agent-config): 0
- 🔒 credential-broken (fix in dashboard): 0
- ❓ no-validator (degraded confidence): 0

## What to act on

**Only 🔒 credential-broken entries require dashboard action.** All other
non-✅ states are informational: 🪪 is by design, 🔧 needs server-side fix
(not a credential change), ⚠️ is partial-by-design or known limit, 🚫 is
not meant to be called via example/run, ❓ means we couldn't classify.
