#!/bin/bash
# Two-axis smoke test for tools-server credentials.
#
# Axis 1 — VALIDATOR (the dashboard "Test" button):
#   Calls POST /api/services/<id>/validate. The per-package validator (or
#   schema-based validation) confirms the credential is authenticated and
#   the upstream is reachable. This is the authoritative "is this credential
#   ready" signal. Already runs twice a day server-side as part of /api/health.
#
# Axis 2 — EXAMPLE/RUN (the agent-facing call shape):
#   Calls POST /api/credentials/<id>/example/run with the package's documented
#   default params. Tests whether the templated request actually returns useful
#   data. Hits the wire on each run, including paid endpoints.
#
# Classification combines both axes:
#   - ✅ both-pass:        validator ok, example/run ok
#   - 🪪 cli-shadowed:    validator ok, run not applicable (use op/gog/gws)
#   - 🔧 interface-bug:   validator ok, example/run fails — server-side issue
#   - ⚠️ partial:          validator ok, run partial (sub-endpoints, timeouts, missing params)
#   - 🚫 not-runnable:     no usage definition (agent-config credentials like mel)
#   - 🔒 credential-broken: validator fails — real auth/config problem, fix in dashboard
#   - ❓ no-validator:     no validator configured AND example/run worked (degraded confidence)
#
# Result file: ~/.openclaw/workspace/tools-server/CREDENTIALS-SMOKE.md
#
# Re-run anytime credentials change. Hits the wire (paid endpoints incur cost).
# Exit 0: nothing unexpectedly broken.
# Exit 1: at least one credential is in 🔒 credential-broken state.

set -uo pipefail

BASE_URL="${BASE_URL:-http://localhost:8080}"
RUN_TIMEOUT="${RUN_TIMEOUT:-30}"
VALIDATE_TIMEOUT="${VALIDATE_TIMEOUT:-15}"
OUT="${1:-/home/alex/.openclaw/workspace/tools-server/CREDENTIALS-SMOKE.md}"

COOKIE=$(mktemp)
cleanup() { rm -f "$COOKIE"; }
trap cleanup EXIT

# ---- Login ----
LOGIN=$(curl -s --max-time 5 -c "$COOKIE" -X POST "$BASE_URL/api/login" \
  -H 'Content-Type: application/json' -d '{"password":"mel2026"}')
if ! echo "$LOGIN" | jq -e '.success == true' >/dev/null 2>&1; then
  echo "[smoke] Login to $BASE_URL failed: $LOGIN" >&2
  exit 2
fi

# ---- Fetch all credentials ----
ALL=$(curl -s -b "$COOKIE" "$BASE_URL/api/credentials")
if ! echo "$ALL" | jq -e '.credentials' >/dev/null 2>&1; then
  echo "[smoke] Could not fetch /api/credentials" >&2
  exit 2
fi

TIMESTAMP=$(date -u +"%Y-%m-%d %H:%M:%S UTC")
mkdir -p "$(dirname "$OUT")"

{
  echo "# Tools Server Credentials Smoke Test"
  echo
  echo "Generated: \`$TIMESTAMP\` by \`scripts/smoke-test-credentials.sh\`"
  echo
  echo "Two axes per credential:"
  echo "  - **Validator** (dashboard Test button): is auth + upstream reachable?"
  echo "  - **example/run**: does the templated agent call deliver useful data?"
  echo
  echo "Statuses:"
  echo "  - ✅ both-pass: validator ok, example/run ok"
  echo "  - 🪪 cli-shadowed: validator ok, by-design uses local CLI (op, gog, gws)"
  echo "  - 🔧 interface-bug: validator ok, example/run fails — server-side issue, do NOT touch credential"
  echo "  - ⚠️ partial: validator ok, example/run returns partial (sub-endpoints, slow LLM, missing params)"
  echo "  - 🚫 not-runnable: no usage definition (agent-config credentials)"
  echo "  - 🔒 credential-broken: validator fails — fix in dashboard"
  echo "  - ❓ no-validator: no validator configured (degraded confidence)"
  echo
  echo "| Category | Credential | Validator | example/run | Status | Notes |"
  echo "|---|---|---|---|---|---|"
} > "$OUT"

N_BOTH=0; N_CLI=0; N_IFACE=0; N_PARTIAL=0; N_NOTRUN=0; N_BROKEN=0; N_NOVAL=0; N_TOTAL=0

IDS=$(echo "$ALL" | jq -r '.credentials | keys[]' | sort)

for ID in $IDS; do
  N_TOTAL=$((N_TOTAL + 1))

  CRED=$(echo "$ALL" | jq -r --arg id "$ID" '.credentials[$id]')
  CATEGORY=$(echo "$CRED" | jq -r '.category // .primaryCategory // "—"')
  SUMMARY=$(echo "$CRED" | jq -r '.usage.summary // ""')
  HAS_USAGE=$(echo "$CRED" | jq -r 'if (.usage and (.usage | length > 0) and (.usage.params != null)) then "yes" else "no" end')
  ADDITIONAL=$(echo "$CRED" | jq -r '.usage.additionalCalls // [] | length')
  CLI_HINT=$(echo "$SUMMARY" | grep -iqE "use op cli|not a direct api call|use the.*cli|use gog cli|use gws cli" && echo "yes" || echo "no")

  # ---- Axis 1: validator ----
  VAL_RESP=$(curl -s --max-time "$VALIDATE_TIMEOUT" -b "$COOKIE" -X POST "$BASE_URL/api/services/$ID/validate")
  VAL_VALID=$(echo "$VAL_RESP" | jq -r '.valid' 2>/dev/null)   # true|false|null|missing
  VAL_MSG=$(echo "$VAL_RESP" | jq -r '.message // ""' 2>/dev/null | tr '\n' ' ')

  case "$VAL_VALID" in
    true)  VAL_CELL="✅" ;;
    false) VAL_CELL="❌" ;;
    null)  VAL_CELL="❓" ;;
    *)     VAL_CELL="❓" ;;
  esac

  # ---- Short-circuit: validator failed → credential broken, don't bother running ----
  if [ "$VAL_VALID" = "false" ]; then
    STATUS="🔒"
    NOTE="Credential broken: ${VAL_MSG:0:90}"
    N_BROKEN=$((N_BROKEN + 1))
    NOTE_SAFE=$(echo "$NOTE" | tr '\n' ' ' | sed 's/|/\\|/g')
    echo "| $CATEGORY | \`$ID\` | $VAL_CELL | — | $STATUS | $NOTE_SAFE |" >> "$OUT"
    printf "  [%-2s] %-30s validator=%-3s run=—  %s\n" "$STATUS" "$ID" "$VAL_VALID" "$NOTE_SAFE" >&2
    continue
  fi

  # ---- Axis 2: example/run (when applicable) ----
  RUN_CELL=""; STATUS=""; NOTE=""

  if [ "$HAS_USAGE" = "no" ]; then
    RUN_CELL="—"; STATUS="🚫"; NOTE="No usage example (agent-config or composite credential)"
    N_NOTRUN=$((N_NOTRUN + 1))
  elif [ "$CLI_HINT" = "yes" ]; then
    RUN_CELL="🪪"; STATUS="🪪"; NOTE="CLI-shadowed by design: ${SUMMARY:0:80}"
    N_CLI=$((N_CLI + 1))
  else
    # Pass empty params and let the server merge its own defaults (including
    # dynamic function defaults that don't serialize over the JSON wire).
    # If a required param truly has no resolvable default, the server will
    # throw "Missing required param: <key>" which we then classify below.
    RUN_RESP=$(curl -s --max-time "$RUN_TIMEOUT" -b "$COOKIE" -X POST \
      "$BASE_URL/api/credentials/$ID/example/run" \
      -H 'Content-Type: application/json' \
      -d '{"params":{}}' 2>&1)

    SERVER_ERR=$(echo "$RUN_RESP" | jq -r '.error // empty' 2>/dev/null)
    UPSTREAM_STATUS=$(echo "$RUN_RESP" | jq -r '.response.status // 0' 2>/dev/null)
    BODY_NONEMPTY=$(echo "$RUN_RESP" | jq -r 'if (.response.body | type) == "object" then (.response.body | length > 0) elif (.response.body | type) == "string" then (.response.body | length > 0) elif (.response.body | type) == "array" then (.response.body | length > 0) else false end' 2>/dev/null)

    if [ -n "$SERVER_ERR" ] || [ "$UPSTREAM_STATUS" = "0" ]; then
      RUN_CELL="❌"
      # "Missing required param" means the credential genuinely needs explicit
      # input (no static or dynamic default available). Classify as not-runnable
      # rather than interface-bug.
      if echo "$SERVER_ERR" | grep -qi "missing required param"; then
        STATUS="🚫"; NOTE="Needs explicit param: ${SERVER_ERR:0:90}"
        N_NOTRUN=$((N_NOTRUN + 1))
      elif [ "$VAL_VALID" = "true" ]; then
        STATUS="🔧"; NOTE="Interface bug (validator passed): ${SERVER_ERR:0:90}"
        N_IFACE=$((N_IFACE + 1))
      else
        STATUS="❓"; NOTE="No validator + run failed: ${SERVER_ERR:0:90}"
        N_NOVAL=$((N_NOVAL + 1))
      fi
    elif [ "$UPSTREAM_STATUS" -ge 400 ] 2>/dev/null && [ "$UPSTREAM_STATUS" -lt 500 ] 2>/dev/null; then
      RUN_CELL="⚠️"
      if [ "$VAL_VALID" = "true" ]; then
        STATUS="🔧"; NOTE="Interface bug (validator passed): upstream HTTP $UPSTREAM_STATUS"
        N_IFACE=$((N_IFACE + 1))
      else
        STATUS="❓"; NOTE="No validator + upstream HTTP $UPSTREAM_STATUS"
        N_NOVAL=$((N_NOVAL + 1))
      fi
    elif [ "$UPSTREAM_STATUS" -ge 500 ] 2>/dev/null; then
      RUN_CELL="❌"; STATUS="🔧"; NOTE="Upstream 5xx: HTTP $UPSTREAM_STATUS"
      N_IFACE=$((N_IFACE + 1))
    elif [ "$BODY_NONEMPTY" != "true" ]; then
      RUN_CELL="⚠️"; STATUS="⚠️"; NOTE="Empty response body"
      N_PARTIAL=$((N_PARTIAL + 1))
    elif [ "$ADDITIONAL" -gt 0 ]; then
      RUN_CELL="⚠️"; STATUS="⚠️"; NOTE="Partial: $ADDITIONAL sub-endpoint(s) not covered by run"
      N_PARTIAL=$((N_PARTIAL + 1))
    else
      RUN_CELL="✅"
      if [ "$VAL_VALID" = "true" ]; then
        STATUS="✅"; NOTE="—"
        N_BOTH=$((N_BOTH + 1))
      else
        STATUS="❓"; NOTE="example/run ok but no validator configured"
        N_NOVAL=$((N_NOVAL + 1))
      fi
    fi
  fi

  NOTE_SAFE=$(echo "$NOTE" | tr '\n' ' ' | sed 's/|/\\|/g')
  echo "| $CATEGORY | \`$ID\` | $VAL_CELL | $RUN_CELL | $STATUS | $NOTE_SAFE |" >> "$OUT"
  printf "  [%-2s] %-30s validator=%-3s run=%-3s %s\n" "$STATUS" "$ID" "$VAL_VALID" "$UPSTREAM_STATUS" "$NOTE_SAFE" >&2
done

{
  echo
  echo "## Summary"
  echo
  echo "- Total credentials: $N_TOTAL"
  echo "- ✅ both-pass: $N_BOTH"
  echo "- 🪪 cli-shadowed (by design): $N_CLI"
  echo "- 🔧 interface-bug (validator ok, server-side run issue): $N_IFACE"
  echo "- ⚠️ partial (sub-endpoints, slow LLMs, missing params): $N_PARTIAL"
  echo "- 🚫 not-runnable (agent-config): $N_NOTRUN"
  echo "- 🔒 credential-broken (fix in dashboard): $N_BROKEN"
  echo "- ❓ no-validator (degraded confidence): $N_NOVAL"
  echo
  echo "## What to act on"
  echo
  echo "**Only 🔒 credential-broken entries require dashboard action.** All other"
  echo "non-✅ states are informational: 🪪 is by design, 🔧 needs server-side fix"
  echo "(not a credential change), ⚠️ is partial-by-design or known limit, 🚫 is"
  echo "not meant to be called via example/run, ❓ means we couldn't classify."
} >> "$OUT"

echo "[smoke] Results: $OUT"
echo "[smoke] Summary: ✅ $N_BOTH  🪪 $N_CLI  🔧 $N_IFACE  ⚠️ $N_PARTIAL  🚫 $N_NOTRUN  🔒 $N_BROKEN  ❓ $N_NOVAL"

if [ "$N_BROKEN" -gt 0 ]; then
  exit 1
fi
exit 0
