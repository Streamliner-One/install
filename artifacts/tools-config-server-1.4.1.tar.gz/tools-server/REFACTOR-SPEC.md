# TOOLS.md Refactor Spec — lean bootstrap + on-demand detail

> **⚠️ Historical document — implemented in v1.3.1/v1.3.2.**
> Path references in this spec use the original proposed location (`TOOLS-REFERENCE.md` at workspace root).
> The actual implementation places the file at `reference/TOOLS-REFERENCE.md`.
> See `README.md` and `CHANGELOG.md` for current state.

**target:** tools-config-server **1.3.0**
**repo:** `Streamliner-One/tools-config-server` (working tree: `~/.openclaw/workspace/tools-server/`)
**status:** ✅ implemented (v1.3.1) — paths normalized to `reference/` in v1.3.2
**author:** Alex + Claude Opus 4.7 + Mel

---

## Why

`TOOLS.md` is 76 KB — 96 % of the file budget and 64 % of the total bootstrap.
Result: `HEARTBEAT.md`, `MEMORY.md`, and `USER.md` get heavily truncated.

Fix: split into two files so the agent bootstraps lean and fetches detail on demand.

```
Current:  generator.js → TOOLS.md (76 KB, all-in-one)

Target:   generator.js → TOOLS.md           (~15 KB, lean bootstrap, injected)
                      → TOOLS-REFERENCE.md  (~60 KB, full details, on disk)
          server.js   → GET /api/tools/describe/:id
                      → GET /api/tools/describe/model/:alias
                      → GET /api/tools/list
                      → GET /api/tools-reference
```

Net effect: bootstrap drops ~60 KB. No capability loss.

---

## Files to touch

| File | Action |
|------|--------|
| `lib/generator.js` | Split into bootstrap + reference renderers. Remove auto-bump telemetry. |
| `server.js` | Add 4 new endpoints. Update `/api/agent-guide` blurb. Replace all `generateToolsMd()` call sites → `generateAll()`. |
| `package.json` | Bump version to `1.3.0`. |
| `CHANGELOG.md` | New entry. |
| `README.md` | Update TOOLS.md generator row. |
| `API.md` | Document the 4 new endpoints. |

**Do NOT touch:** `schema.js`, `lib/usage.js`, `lib/registry.js`, `lib/packages.js`, any `packages/*` directory. The data model stays unchanged.

---

## Design

### A — `lib/generator.js`: two renderers + entry functions

#### New file constant

```js
const TOOLS_REFERENCE_PATH = path.join(
  process.env.HOME || '/home/alex',
  '.openclaw/workspace/TOOLS-REFERENCE.md'
);
```

#### Function shape

```js
function _partitionServices(services) { /* — extracted from current generator — */ }
function buildBootstrapMd(services, agentByPackage, infraServices, inactive, options) { /* lean */ }
function buildReferenceMd(services, agentByPackage, options) { /* full */ }
function generateToolsMd(options = {}) { /* bootstrap → TOOLS_MD_PATH */ }
function generateToolsReference(options = {}) { /* full → TOOLS_REFERENCE_PATH */ }
function generateAll(options = {}) { /* calls both, returns {toolsPath, refPath} */ }
function getServiceReferenceEntry(serviceId) { /* single-service md chunk */ }
function getModelReferenceEntry(alias) { /* single-model md block */ }

module.exports = {
  generateToolsMd,
  generateToolsReference,
  generateAll,
  getServiceReferenceEntry,
  getModelReferenceEntry,
  lintFieldReferences,
  TOOLS_MD_PATH,
  TOOLS_REFERENCE_PATH,
};
```

#### What stays in lean `TOOLS.md`
- Header (date + pointer to describe endpoint)
- `## ⚡ Quick Routing Index`
- `## 🏷️ Domains & Decision Tiers`
- `## 🧠 Model Knowledge Base` (table **only** — drop per-model detail blocks)
- `## Infrastructure (OpenClaw-managed)`
- `## Inactive`
- `## 🎯 Intent Rules` (must stay; fires on triggers)

#### What gets dropped from lean and moved to `TOOLS-REFERENCE.md`
- **Entire `## Agent-Callable APIs`** section → replaced with a pointer paragraph
- **Per-model detail blocks** (`### opus`, `### sonnet`, etc.)

#### Pointer replacement for "Agent-Callable APIs"

```
## Agent-Callable APIs

Full curl templates, parameters, common errors, and additional call examples live in `TOOLS-REFERENCE.md`.

Fetch one service at runtime via `GET /api/tools/describe/<service-id>`.
Service IDs use the schema/package id (lowercase kebab-case), e.g. `amadeus`, `duffel`, `agentmail`, `google-workspace`.
```

#### Pointer replacement under the Models table

Add a footer line: `Need full model details? Call `GET /api/tools/describe/model/<alias>`.`

#### Lean header

```js
# TOOLS.md, Tool Index

Auto-generated on ${new Date().toISOString().split('T')[0]}.
⚠️ Do NOT edit directly. Use tools server API at https://100.84.57.51:8443.
🔎 **Need full details for a service?** Call `GET /api/tools/describe/<service-id>` against the tools server.
```

#### Bootstrap budget rule (hard constraint)

The lean `TOOLS.md` **must** stay under 20 KB.
If it exceeds this after the initial split, reduce in this exact order:

1. Shorten "use when" cells in the Quick Routing Index (keep first trigger only).
2. Drop `Fallback` column from Quick Routing Index.
3. Drop `Params` column from Quick Routing Index (keep only Service + Use when).
4. Truncate long intent-rule notes (they are in bootstrap and must stay, but can lose verbose text).

**Never drop entire intent rules.**

### B — Common-error deduplication in `TOOLS-REFERENCE.md`

```js
const COMMON_ERRORS = [
  { pattern: /^401 invalid key;?$/i,         label: 'auth-401', text: '401: invalid API key' },
  { pattern: /^429 rate limit;?$/i,          label: 'rate-429', text: '429: rate limit hit' },
  { pattern: /^403.*restricted/i,            label: 'auth-403', text: '403: key restricted or missing scope' },
];
function classifyCommonError(s) {
  if (!s) return null;
  for (const { pattern, label } of COMMON_ERRORS) { if (pattern.test(s.trim())) return label; }
  return null;
}
```

In the reference file's per-service entries, replace a matched common error with:
`**Common error:** see `auth-401` in Common Errors above.`

At the top of `TOOLS-REFERENCE.md`, add a `## Common Errors` table listing each label → expansion.

### C — `TOOLS-REFERENCE.md` structure
- Header with date + back-pointer to `TOOLS.md`
- `## Common Errors` section
- `## Agent-Callable APIs` — full entries as current generator renders (description, accounts, use when, params, fallback, note, sandbox, multi-account, data policy, call template, call params, common error (or dedup ref), additional calls)
- `## 🧠 Models, Detail` — per-model blocks (`Strengths`, `Best for`, `Avoid for`, `Context`, `Notes`)

### D — Auto-bump logic (de-teeth)

Current block at lines 486-537 auto-bumps `bootstrapMaxChars` and pings Telegram.
Changes:
- Only bump if `actualSize > 30000` (was: `> currentLimit`).
- Replace Telegram alert with `console.warn`.
- **Remove any hardcoded bot token** (line 520 area).

---

## New endpoints in `server.js`

All require `requireAuth`.

### `GET /api/tools/list`

Flat JSON list of agent-callable services for discovery.
Each entry: `{ id, name, category, useWhen, params, fallback }`.

### `GET /api/tools/describe/:id`

Full markdown reference entry for one service.

- Default: `text/markdown` — returns the md chunk.
- `Accept: application/json` — returns `{ id, markdown, schema }`.
- `?format=json` — same as above (explicit query-parm fallback for curl/scripts).
- 404 if unknown service id or non-agent-callable.

### `GET /api/tools/describe/model/:alias`

Full markdown detail block for one model.

- `?format=json` — returns `{ alias, markdown }` when supplied.

### `GET /api/tools-reference`

Returns `{ content }` with full `TOOLS-REFERENCE.md`. Parallel to `/api/toolsmd`.

### Update `/api/agent-guide`

Change the TOOLS.md blurb to mention the split and the new describe endpoints.

---

## Call-site updates

Replace **every** `generateToolsMd()` call in `server.js` with `generateAll()`.

Grep finds these (verify line numbers in current source):
```
server.js:33    const { generateToolsMd } = require(...)
server.js:977   generateToolsMd()
server.js:987   generateToolsMd()
server.js:2253  /api/regenerate handler
server.js:2254  const { generateToolsMd, lintFieldReferences } = require(...)
server.js:2266  const path = generateToolsMd()
server.js:2698+ try { require('./lib/generator').generateToolsMd(); } catch ...
server.js:3226  generateToolsMd()
server.js:3575  generateToolsMd()
server.js:3591  generateToolsMd()
server.js:3607  generateToolsMd()
server.js:3679  generateToolsMd()
```

For `/api/regenerate`, return `{ success: true, toolsPath, refPath, lintWarnings }`.

---

## package.json / CHANGELOG / README / API.md

- **package.json:** version `1.2.0` → `1.3.0`.
- **CHANGELOG.md:** new top entry describing the split, new endpoints, common-error dedup, auto-bump changes.
- **README.md:** update "TOOLS.md generator" row.
- **API.md:** document the 4 new endpoints.

---

## Success criteria (hard gate)

Implement is **not done** until all are met:

| Criteria | Check |
|----------|-------|
| `TOOLS.md` < 20 KB | `wc -c` |
| `TOOLS-REFERENCE.md` exists, 50–80 KB | `wc -c` |
| `node -c lib/generator.js` & `server.js` exit clean | syntax check |
| `systemctl restart tools-config-server` + clean `journalctl` | service healthy |
| `/api/regenerate` returns both paths | HTTP check |
| `/api/tools/describe/duffel` returns markdown | HTTP check |
| `/api/tools/describe/duffel?format=json` returns JSON | HTTP check |
| `/api/tools/describe/model/sonnet` returns markdown | HTTP check |
| `/api/tools/describe/nonexistent` returns 404 | HTTP check |
| `/api/tools-reference` returns content | HTTP check |
| `openclaw doctor` — no TOOLS.md size warning | health check |
| `HEARTBEAT.md` / `MEMORY.md` no longer 100 % truncated | health check |
| Intent rules section intact in lean `TOOLS.md` | visual check |

---

## Rollback

1. Restore previous `TOOLS.md` from `.tools-md-backups/TOOLS.md.1`.
2. Roll back tarball to `1.2.0` via install script if needed.
3. Delete `TOOLS-REFERENCE.md` safely (regenerated on next call).

---

## Out of scope

- No changes to `schema.js`, `lib/usage.js`, `lib/registry.js`, `lib/packages.js`, `packages/*`.
- No dashboard UI changes.
- No changes to `router.json` or intent rules system.
- Do not register `tools.describe` as an agent-callable tool (follow-up).
- Keep `/api/toolsmd` for backward compatibility.
- **Do NOT deploy or release** — implement and validate only. Release is a separate step.

---

## Commit message

```
feat: split TOOLS.md into lean bootstrap + on-demand reference

TOOLS.md drops from ~76 KB to ~15 KB by moving full per-service curl
templates and per-model detail blocks to a new TOOLS-REFERENCE.md.
Agents fetch full detail on demand via new endpoints:

  GET /api/tools/list
  GET /api/tools/describe/:id
  GET /api/tools/describe/model/:alias
  GET /api/tools-reference

Common errors deduplicated in the reference via shared label section.
Removed hardcoded Telegram bot token from the auto-bump path.
All existing generateToolsMd() call sites now call generateAll().

Bumps version to 1.3.0.
```
