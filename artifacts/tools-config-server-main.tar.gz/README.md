# OpenClaw Tools Config Server

Web-based configuration manager for OpenClaw external integrations. 24 services supported.

## Quick Start

```bash
cd tools-server
npm install

# Development (localhost)
npm run dev

# Production (Tailscale only)
node server.js --bind 100.x.x.x:8443 --password "your-secure-password"

# Temporary public access (30 min auto-shutdown)
node server.js --temp 30 --bind 0.0.0.0:8443 --https --password "temp-password"
```

## Usage

| Flag | Description | Default |
|------|-------------|---------|
| `--bind HOST:PORT` | Bind address | `127.0.0.1:8080` |
| `--password PASS` | Access password | Auto-generated |
| `--temp MINUTES` | Auto-shutdown after N min | Disabled |
| `--https` | Enable HTTPS (self-signed) | Disabled |
| `--data-dir PATH` | Data directory | `~/.openclaw/workspace` |

## Files

| File | Purpose |
|------|---------|
| `tools-registry.json` | Machine-readable service configs |
| `TOOLS.md` | Auto-generated human reference |
| `schema.js` | Service definitions (fields, validation) |

## Architecture

```
┌─────────────┐     ┌──────────────┐     ┌─────────────────┐
│  Web UI     │────▶│  Express API │────▶│  Registry JSON  │
│  (Dark UI)  │     │  (Auth)      │     │  (Local FS)     │
└─────────────┘     └──────────────┘     └─────────────────┘
                             │
                             ▼
                      ┌──────────────┐
                      │  TOOLS.md    │
                      │  Generator   │
                      └──────────────┘
```

## Security

- Password protected (bcrypt)
- HTTP-only session cookies
- Helmet security headers
- Self-signed TLS option
- Temporal access mode (auto-kill)
- Bind to Tailscale recommended

## Adding New Services

1. Add schema to `schema.js`:
```javascript
myService: {
  id: 'myService',
  name: 'My Service',
  category: 'custom',
  icon: '🔧',
  fields: [
    { key: 'apiKey', label: 'API Key', type: 'password', required: true, sensitive: true }
  ]
}
```

2. Restart server

3. Configure via web UI

## CLI Helper (Optional)

Add to shell profile for quick access:
```bash
alias tools-config='node ~/.openclaw/workspace/tools-server/server.js'
```

## Agent Behavior & Rate Limit Resilience

Built-in resilience configuration for AI service outages and rate limits:

| Setting | Default | Purpose |
|---------|---------|---------|
| **Notify on rate limits** | `always` | Alert mode: always / after-3-retries / never |
| **Pause duration** | `30s` | Wait time before first retry |
| **Max retries** | `3` | Retry attempts with exponential backoff |
| **Backoff multiplier** | `2x` | Wait multiplier per retry (30s → 60s → 120s) |

**Why this matters:** When OpenAI, Anthropic, or any provider returns 429, the agent automatically:
1. Notifies you immediately (or after N retries)
2. Pauses for configured duration
3. Retries with exponential backoff
4. Escalates if all retries fail

No more silent failures or manually switching models during outages.

## Live Validation (Test Buttons)

Each service with a **🧪 Test** button performs live API validation:

| Service | Validation Method | Success Indicator |
|---------|-------------------|-------------------|
| Notion | `GET /v1/users/me` | Workspace name |
| Todoist | `GET /api/v1/projects` | "Connected to Todoist" |
| Telegram | `GET /bot<token>/getMe` | @username |
| OpenAI | `GET /v1/models` | Model count |
| Anthropic | `GET /v1/models` | "Connected" |
| Moonshot | `GET /v1/models` | "Connected" |
| ElevenLabs | `GET /v1/voices` | Voice count |
| Perplexity | `GET /models` | "Connected" |
| NewsAPI | `GET /v2/top-headlines` | "Connected" |
| Duffel | `POST /air/offer_requests` | "Connected (sandbox)" |
| Weather | N/A | "No key required" (Open-Meteo) |
| **n8n** | `GET /api/v1/workflows` | "Connected to n8n" |
| **17TRACK** | `POST /track/v2.2/gettrackinfo` | "Connected to 17TRACK" |
| **Aviationstack** | `GET /v1/flights` | "Connected to Aviationstack" |
| **Amadeus** | `POST /v1/security/oauth2/token` | "Connected to Amadeus (production)" |
| **Google Places** | `POST /v1/places:searchText` | "Connected to Google Places" |
| **Open Exchange Rates** | `GET /api/latest.json` | "Connected to Open Exchange Rates" |

Validation results show immediately — green for success, red for auth errors, yellow for warnings (like rate limits with valid keys).

## Field Features

Every form field has convenient actions:

| Field Type | Features |
|------------|----------|
| **Password fields** | 👁️ Reveal toggle (eye icon) — click to show/hide<br>📋 Copy button — copy to clipboard |
| **Text fields** | 📋 Copy button — copy to clipboard |

**Privacy Note:** This is YOUR server running locally. Keys are visible only to you — reveal, copy, and manage freely. No vault complexity, just direct access to your own credentials.

## Multi-Label Categories

Connectors can belong to multiple labels (not a single hard category), e.g. Perplexity = `ai + search + news`.
Dashboard filters and routing logic use labels.

## Intent Router (Lightweight Decision Engine)

`router.json` provides tiny intent->tool priority maps so agents don't guess and don't load bloated context.

Endpoints:
- `GET /api/router/intents`
- `GET /api/router?intent=hotel_search`

Behavior:
- returns ordered candidates
- filters to configured packages by default
- optional `healthyOnly=true` uses cached health snapshot (no live health pings)
- includes failure policy hints for fallback behavior

Health checks are cached (default 24h TTL) to avoid API-provider overload and request latency.
Override with env: `TOOLS_HEALTH_MAX_AGE_MS`.

Recommended cron (2x/day) using jittered refresh helper:

```bash
# 09:00 and 21:00 local time
0 9,21 * * * /opt/tools-config/tools-server/cron-health-refresh.sh >> /var/log/tools-health-refresh.log 2>&1
```

## Query Examples (New)

Credential APIs now include ready-to-use query snippets so agents/users can execute provider calls immediately without docs hunting.

- `GET /api/credentials` includes `usage` per credential
- `GET /api/credentials/:id` includes `usage`
- `GET /api/credentials/:id/usage` returns only usage block
- `GET /api/credentials/:id/example` returns parameter schema
- `POST /api/credentials/:id/example/render` returns rendered request + curl
- `POST /api/credentials/:id/example/run` executes request server-side
- `PUT /api/credentials/:id` merge-update credential fields
- `PUT /api/credentials/:id/fields` full-replace credential fields (agent maintenance mode)

`usage` payload includes:
- `title`, `summary`
- `curl` (copy/paste ready)
- `expected` response shape
- `commonError` quick troubleshooting hint
- `docs` link

## Version & Dashboard Updates

Dashboard now supports:
- Current server version display
- "Update Center" modal (version-first messaging)
- One-click update trigger for non-technical users
- Graceful reconnect UX during restart handoff (no noisy transient error spam)
- Action lock during update/restart window to prevent double-trigger

API endpoints:
- `GET /api/version`
- `GET /api/update/check`
- `POST /api/update/run`
- `GET /api/update/status`

UX notes:
- Update UI is intentionally non-technical: hides raw logs and commit-centric wording.
- On expected restart turbulence, UI shows neutral reconnect state and retries.
- Real errors still surface outside the restart handoff window.

## Updating Existing Installations

For installed servers (e.g. `/opt/tools-config/tools-server`):

```bash
cd /opt/tools-config/tools-server
./update.sh
```

What `update.sh` does:
- fetch + fast-forward pull
- install production dependencies
- restart `tools-config` systemd service (if present)
- fallback to manual process restart when no systemd service exists

For local dev workspace run:

```bash
cd ~/.openclaw/workspace/tools-server
./update.sh --local-dev
```

Agent startup helper:

```bash
~/.openclaw/workspace/tools-server/agent-tools-check.sh
```

## Future Enhancements

- [x] Live API validation (test buttons)
- [x] Rate limit resilience with exponential backoff
- [ ] 1Password CLI integration
- [ ] Environment variable sourcing
- [ ] Config encryption at rest
- [ ] Import/export encrypted backups
- [ ] Service dependencies/middleware
- [ ] OAuth flow support (interactive)
- [ ] Webhook testing endpoint
- [ ] Bulk import from .env files

## For Streamliner One Clients

This tool is part of the managed OpenClaw offering:

1. **Quick Setup** — Pre-installed on provisioned VPS instances
2. **Secure by Default** — Tailscale-only access, temporal public mode available
3. **Self-Service** — Clients configure their own keys without SSH/VNC
4. **Resilient** — Rate limit handling keeps automations running during outages
5. **Auditable** — TOOLS.md auto-generated for documentation compliance

## License

MIT — Part of OpenClaw ecosystem