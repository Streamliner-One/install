# Release Checklist (Internal)

Use this checklist for each public release.

## 1) Server repo (`Streamliner-One/tools-config-server`)
- [ ] Bump version in `package.json`
- [ ] Commit changelog-worthy fixes
- [ ] Push to `main`
- [ ] Create git tag (e.g. `v0.6.0`)
- [ ] Create GitHub release notes

## 2) Installer repo (`Streamliner-One/install`)
- [ ] Build fresh artifact tarball (`tools-config-server-main.tar.gz`)
- [ ] Replace `artifacts/tools-config-server-main.tar.gz`
- [ ] Update `versions.json` (`stable` + `latest`)
- [ ] Push to `main`
- [ ] Create matching GitHub release tag

## 3) Docs & metadata
- [ ] Update `README.md` (server/install/packages as needed)
- [ ] Update repo descriptions/topics
- [ ] Confirm install one-liner still valid: `curl https://install.streamliner.one | bash`

## 4) Safety checks
- [ ] Branch protection restored (if temporarily relaxed)
- [ ] `openclaw status` healthy after deployment
- [ ] OAuth re-auth flow tested end-to-end
- [ ] Health dashboard reflects current token expiry

## 5) Internal memory/docs
- [ ] Update `memory/YYYY-MM-DD.md`
- [ ] Add durable lessons to `MEMORY.md` when relevant
