# Changelog

## [1.4.0] — 2026-04-26

### Render-layer hardening + smoke-test diagnostic

Substantial fluidity work surfaced and fixed several rendering-layer behaviors
that affected how agents call `example/run`. None of these changed credential
health (validators were always green); they changed whether the templated agent
call actually delivered a useful response.

#### Render-layer changes (`lib/usage.js`, `server.js`)

- `runRenderedRequest` default timeout bumped 15s → 60s. The previous value was
  below typical LLM response times, causing perplexity / ollama / groove to
  time out at the server even though their upstreams were responding.
- `OAUTH_AUTO_TOKEN` (and `{{__OAUTH_TOKEN__}}`) sentinel substitution wired
  into the `/api/credentials/<id>/example/run` handler. The example/run path
  now resolves a live OAuth token via `resolveOAuthToken` before rendering, so
  amadeus (and any future OAuth client_credentials integration) works through
  example/run instead of returning 401.
- `mergeParams` now accepts function-valued defaults, evaluated at request
  time. Used for time-sensitive defaults like flight `departureDate` (today +
  N days) so packages don't go stale between maintenance windows.
- `renderRequest` body substitution rewritten as a per-leaf walk (`substituteBodyLeaf`)
  that respects param-declared types. Previously `body: { page_size: '{{page_size}}' }`
  collapsed `10` to `"10"` via JSON-stringify-template-parse; the new path
  preserves `int | number | bool` types through render.

#### Package fixes (`lib/usage.js` entries)

- **amadeus**: `departureDate` default is now a function returning `today + 14`
  days. Static `2026-04-01` had silently rotted past validity.
- **newsapi**: dropped invalid `language` param (only valid on
  `/v2/everything`, not `/v2/top-headlines`); added required `User-Agent`
  header (NewsAPI rejects anonymous requests with HTTP 400).
- **github**: added required `User-Agent` header (GitHub rejects without it).
- **moonshot**: `api.moonshot.cn` → `api.moonshot.ai` (geo-split keyspace; the
  configured key is for `.ai`).
- **nanoBanana**: model name updated `gemini-2.0-flash-preview-image-generation`
  → `gemini-2.5-flash-image`.
- **notion**: default `database_id` switched from `dbHome` (a page, not a
  database, so Notion rejected with `"is a page, not a database"`) to
  `key('dbTodos', 'YOUR_DB_ID')`. `Notion-Version` pinned to `2022-06-28`
  because `2025-09-03` deprecated `/v1/databases/{id}/query` in favor of
  `/v1/data_sources/{id}/query` with different IDs.

#### New diagnostic

- **`scripts/smoke-test-credentials.sh`** — two-axis (validator +
  `example/run`) test of every credential. Writes `CREDENTIALS-SMOKE.md` with
  a per-credential status table. Distinct from the existing twice-daily
  validator-based health check: validator confirms auth + reachability;
  smoke confirms agent-facing fluidity. Both useful, neither replaces the
  other. Re-runnable any time. Hits paid endpoints by design.

#### New documentation

- **`INTEGRATION-PATTERNS.md`** — reference for package authors and integrator
  agents covering OAuth substitution, function defaults, credential-field
  defaults, type-aware body substitution, CLI-shadowed credentials,
  multi-sub-endpoint patterns, n8n-mediated credentials, geo-split APIs,
  required headers, and API-version drift gotchas. Companion to the
  auto-generated `TOOLS-REFERENCE.md`.

#### Net effect on smoke-test scoreboard (this session)

```
Start: ✅ 27, 🔧 9 (interface bugs), 🔒 0
End:   ✅ 34, 🔧 2 (brave 429 transient, oura 401 by-design n8n-mediated),
       🔒 0
```

Zero credentials are broken; all 41 are either passing or in a documented
by-design state.

## [1.3.2] — 2026-04-22

### Path normalization + release cleanup

- Normalized remaining stale documentation references from root-level docs to the `reference/` layout, including `reference/HEARTBEAT.md` and `reference/TOOLS-REFERENCE.md`
- Updated API/help surface text so `/api/tools-reference` is described consistently as serving `reference/TOOLS-REFERENCE.md`
- Re-verified generated outputs, live endpoints, and restart behavior after regeneration
- Prepared release metadata and docs for a clean post-refactor release

## [1.3.1] — 2026-04-22

### Documentation + release hardening for the TOOLS.md split

- Added **TOOLS-REFERENCE.md** as the on-demand companion to lean bootstrap `TOOLS.md`
- Added and validated service/model discovery endpoints:
  - `GET /api/tools/list`
  - `GET /api/tools/describe/:id` with `?format=json|markdown`
  - `GET /api/tools/describe/model/:alias`
  - `GET /api/tools-reference` with markdown support
- Fixed service reference rendering to preserve critical linked rule notes in detail views, including the **Amadeus hotel 2-step flow** and `/by-keyword` safety warning
- Fixed lean `TOOLS.md` truncation pointers for behavior/reflexive rules to point at the correct endpoint: `GET /api/intent-rules/:id`
- Verified live behavior-rule lookup flow for `page_fetch_priority`, `credentials_lookup`, and `research_before_asserting`
- Verified canonical service ID normalization and common-error deduplication in live responses
- Updated docs so release/install surfaces reflect the split reference architecture and current supported services

## [1.3.0] — 2026-04-22

### TOOLS.md split — lean bootstrap + on-demand reference

- **TOOLS.md** drops from ~76 KB to ~15 KB by moving full per-service curl templates and per-model detail blocks to a new **TOOLS-REFERENCE.md** (~60 KB)
- Bootstrap keeps: Quick Routing Index, Domains & Tiers, Model table (summary only), Infrastructure, Inactive, Intent Rules
- Agent-Callable APIs section replaced with pointer to `GET /api/tools/describe/<service-id>`
- Per-model detail blocks replaced with pointer to `GET /api/tools/describe/model/<alias>`

### New endpoints

- `GET /api/tools/list` — flat JSON list of agent-callable services for discovery
- `GET /api/tools/describe/:id` — full markdown reference for one service (supports `?format=json`)
- `GET /api/tools/describe/model/:alias` — full markdown detail for one model
- `GET /api/tools-reference` — returns full TOOLS-REFERENCE.md content

### Common-error deduplication

- Shared error labels (`auth-401`, `rate-429`, `auth-403`) in TOOLS-REFERENCE.md Common Errors table
- Per-service entries reference labels instead of repeating identical error text

### Auto-bump de-teethed

- Only bumps `bootstrapMaxChars` if TOOLS.md exceeds 30 KB (was: any amount over current limit)
- Telegram alert replaced with `console.warn`
- Hardcoded bot token removed

### Call-site updates

- All `generateToolsMd()` calls in server.js replaced with `generateAll()` (generates both files)
- `/api/regenerate` returns `{ toolsPath, refPath, lintWarnings }`
- `/api/agent-guide` updated with new endpoints and split description

## [1.2.0] — 2026-04-19

### New packages

- **AgentMail** (`packages/agentmail`) — agent-native email inbox: send, receive, thread management, webhooks, and semantic search
- **Ollama Cloud** (`packages/ollama`) — OpenAI-compatible inference API for cloud models (GLM-5.1, Kimi K2.5, Qwen3, Gemma4, etc.)
- **OpenRouter** (`packages/openrouter`) — fully updated package with latest model routing

### Multi-account credentials

- Services with multiple credentials of the same type now show `(N accounts)` in TOOLS.md header
- One shared instruction set per credential type — no more duplicate entries per account
- `schema.js`: added `multiAccount` blocks for services supporting multiple credentials
- `generator.js`: renders multi-account headers and deduplicates instruction sections
- Reduces TOOLS.md size significantly for multi-account setups (e.g. Google Workspace)

### Google Workspace — dynamic per-credential CLI examples

- `usage.js`: converted `google-workspace` entry from a static object to an IIFE that reads `key('gogClient')` and `key('account')` from the credential's own stored fields
- Each credential now generates its own correct `gog` CLI commands in TOOLS.md — no more hardcoded account names shared across both entries
- `schema.js`: removed redundant `note: 'Use the gog CLI skill — not direct API calls.'` from Google Workspace skill definition (the Call block is self-documenting)
- `GOOGLE-WORKSPACE.md`: corrected "Which tool for What" table to show `--client` only (removed `--account` reference); added two new "Common Mistakes" entries: `--account` flag unreliability and `gmail get` vs `thread get` confusion
- Battle tested on both accounts (Streamliner + Via Travel): inbox search, full thread read, calendar list — all passing

## [1.1.0] — 2026-03-26

### OAuth auto-token (Option D) — Amadeus flow simplified

- Server asynchronously fetches and caches OAuth2 tokens on `GET /api/credentials/:id`
- `primaryKey` returns a live bearer token for OAuth services — agents never construct OAuth flows manually
- `GET /api/credentials/:id/token` endpoint for explicit token retrieval and debugging
- Amadeus is the only OAuth2 service; all others audited and confirmed static-key

### TOOLS.md generator lint — field reference validation

- New `lintFieldReferences()` in `generator.js`: cross-checks curl templates against package/schema field definitions
- Detects missing auth headers, unreferenced OAuth credentials, and template/schema mismatches
- Runs automatically on every `POST /api/regenerate`; warnings logged but don't block generation
- OAuth services with `auth: 'oauth2'` correctly skipped (server handles token via Option D)

### TOOLS.md generator v2 — size optimization

- Removed duplicate summary tables from rule sections (−5.8KB)
- Removed `Intents:` line from API entries (model routes on `Use when` text)
- Compacted Domains & Tiers section to inline table
- Reflexive behavior rules skip empty `Triggers:` line
- Result: 51,405 → 42,256 bytes (−17.8%), zero routing regressions

### Domains & Models APIs — configurable action categories

- `GET/POST/DELETE /api/domains` — CRUD for action domains (sensitivity, tier, examples)
- `GET/POST/DELETE /api/models` — CRUD for model knowledge base entries
- Domains rendered into TOOLS.md as "Domains & Decision Tiers" table
- Models rendered as "Model Knowledge Base" reference section
- Default domains seeded on first load (INFRA, COMMS, FINANCIAL, DATA_READ, DATA_WRITE, etc.)

### OSRM — new service package

- `packages/osrm/package.json`: Open Source Routing Machine for driving time/distance
- Free API, no key required — uses public demo server at `router.project-osrm.org`
- Validator added in `server.js`; probes a short route and checks for `code: 'Ok'`
- Usage template with `lng,lat` coordinate order documented

### Data policies — schema-level access controls

- Added `dataPolicy` blocks to `schema.js` for Notion, Todoist, Oura, and other services
- Specifies `allowedInputs`, `blockedInputs`, `requiresConfirmation`, `auditLevel`
- Rendered into TOOLS.md per-service entries as "Data policy" lines

### Dashboard improvements

- Tavily package: added `searchDepth` and `topic` fields
- Minor UI consistency fixes in public dashboard

## [1.0.2] — 2026-03-14

### Tavily — Auth split fix + crawl example corrected

- Fixed `/crawl` example curl in `usage.js` to use `Authorization: Bearer` header (not `api_key` in body)
- Updated `usage.js` summary to explicitly document auth split: `/search` + `/extract` use `api_key` in body; `/crawl` + `/map` use Bearer header
- Updated `package.json` note field with same auth split documentation + note about client-side SPAs returning empty
- Added `projects/tavily.md` — business use cases, tutorial links, lessons learned (Crawl2RAG, Chat Research, hybrid agent pattern)

## [1.0.1] — 2026-03-12

### Generator — Auto-bump bootstrapMaxChars

- After generating `TOOLS.md`, checks its byte size against `bootstrapMaxChars` in `openclaw.json`
- If the file exceeds the current limit, auto-bumps to the next 10k ceiling and saves `openclaw.json`
- Writes a `tools_md_bump` event to `system-health.json` so the agent sees it on next heartbeat/session
- Sends a Telegram alert with the old/new limits and a reminder to run `openclaw gateway restart`
- Gateway restart is never automated — always a manual user decision

## [1.0.0] — 2026-03-11

### Dashboard — Full visual redesign

- **Blue accent system:** Blue replaces green on all interactive elements (buttons, active filter chips, hover states); green reserved exclusively for health/status indicators (ON, HEALTHY, connected)
- **Search bar:** Filtering by name, tag, or account above the filter chips; instant client-side filter
- **Card anatomy standardised:**
  - Header: icon + service name + inline ghost 🔄 re-auth button (OAuth only) + ON/OFF status badge
  - Subtitle: masked email identifier (`ale***@via.travel`) with click-to-reveal; spacer when empty
  - Tags row: scrollable chip list, truncated past 2 lines
  - Action row: uniform `Edit · Test · Delete` outlined small buttons on every card
  - `exp` label replaces `expires` for compact expiry display
- **Expiry warnings:** Amber ⚠ badge on cards expiring within 7 days (e.g. "14 Mar")
- **Aviationstack rate-limit handling:** 429 responses → amber badge + "ratelimited" system status; excluded from Issues count; amber toast instead of error
- **Instant card load:** Cards render immediately from cache; version check runs in background (shows `...` then updates)
- **Pinned cards removed:** Google Workspace and Codex OAuth treated as regular grid cards; appear in Issues only when genuinely broken

### OpenClaw Sync — Push credentials from dashboard to runtime

- **Compare endpoint** (`GET /api/openclaw/auth/compare/:id`): Detects whether a credential's key is stored in `auth-profiles.json` or `models.json`; shows key preview + match status
- **Push endpoint** (`POST /api/credentials/:id/push/openclaw`): Routes write to correct file:
  - `auth-profiles.json` for standard providers (anthropic, openai, moonshot, google)
  - `models.json` for `models.json`-based providers (openrouter, custom)
- **`resolveOpenclawProvider`** rewritten: checks `models.json` directly (no CLI dependency); priority: profiles → models.json → env
- Fixed `authPath`/`backupPath` undefined reference in `usesModelsJson` branch (toast error on push)
- Gateway restart triggered automatically after push

### run.sh — Reliable restart

- Tracks PID in `/tmp/tools-server.pid`; falls back to `lsof` on port 8443
- Uses `nohup` to survive script exit; polls up to 10s for HTTP 200 before confirming ready
- Replaced over-broad `pkill -9 -f "node.*server"` (killed unrelated processes)

### OpenRouter package

- Added `packages/openrouter/package.json` with apiKey, defaultModel, siteUrl, siteName fields
- Validation via `GET https://openrouter.ai/api/v1/auth/key`
- Credential pre-created with Streamliner branding defaults

---

## [0.9.6] — 2026-03-10

### Changed — Dashboard health summary bar

- Replaced "Connector Types" stat (always equal to credentials count, not useful) with two actionable health tiles:
  - **Healthy** — count of credentials passing health checks (`✅ N`)
  - **Issues** — count of failing credentials (`⚠️ N` in orange when non-zero; `—` when all clear)
- Issues tile is clickable when non-zero — filters the grid to only show broken credentials
- Both tiles sourced from existing `/api/health/status` summary; no new endpoints needed
- "Total Credentials" label shortened to "Credentials"

---

## [0.9.5] — 2026-03-10

### Added — OpenRouter credential package

- `packages/openrouter/package.json`: New tool package for OpenRouter unified AI gateway
  - Fields: `apiKey` (required), `defaultModel` (optional, default: qwen/qwen3.5-plus), `siteUrl`, `siteName`
  - Declarative validation via `GET https://openrouter.ai/api/v1/auth/key` with Bearer token
  - Skill block: `useWhen` phrases for agent routing (openrouter, try qwen via openrouter, use openrouter model, etc.)
  - Usage template with curl example for `/v1/chat/completions` endpoint
  - Category: `ai`, icon: 🔀
- Pre-created credential entry `openrouter-1773159277741` with Streamliner branding defaults

---

## [0.9.4] - 2026-03-09

### Fixed
- Cache `/api/update/check` result for 5 minutes to prevent slow dashboard load on every page refresh (git fetch was taking ~1.3s, blocking UI render)

## [0.9.3] — 2026-03-09 (updated)

### Added — Intent Rules API (data-write triggers)

- `lib/registry.js`: Added `loadIntentRules`, `saveIntentRules`, `getIntentRule`, `upsertIntentRule`, `deleteIntentRule`
  - Rules stored in `registry.meta.intentRules` — no credentials or auth required
  - Schema: `{ id, intent, triggers[], entities[], action, target, confirmationTemplate, notes }`
- `server.js`: Four new endpoints:
  - `GET /api/intent-rules` — list all rules
  - `GET /api/intent-rules/:id` — get single rule
  - `POST /api/intent-rules` — create or update rule (upsert by id); auto-regenerates TOOLS.md
  - `DELETE /api/intent-rules/:id` — remove rule; auto-regenerates TOOLS.md
- `lib/generator.js`: New "Intent Rules (Data-Write Triggers)" section injected into TOOLS.md
  - Renders routing table + per-rule detail block
  - Marked **mandatory and non-optional** so agent cannot skip execution
  - Only appears if rules exist; section hidden when empty

### Initial rules seeded

- `flight_update` — triggers on flight change phrases → writes to `travel.json`
- `location_update` — triggers on location arrival phrases → writes to `LOCATION.md`

### Updated — Rule types: write vs behavior

- `lib/generator.js`: TOOLS.md now splits Intent Rules into two subsections:
  - **Data-Write Rules** — file updates, entities, targets, confirmation templates
  - **Behavior Rules** — response constraints, no file target needed
- `README.md`: Schema docs updated with both rule types and examples
- `heartbeat_ack` behavior rule seeded: silences heartbeat poll responses to `HEARTBEAT_OK` only

### Design rationale

Intent rules solve the "judgment lottery" problem: critical data updates (flights, contacts, location)
were being stored in Mem0 without updating canonical JSON files, causing stale data in scheduled
check-ins. Rules bypass agent judgment entirely — trigger phrase detected → file write → then respond.
Agent-writable via API, human-readable in TOOLS.md, server-persisted in registry.

---

## [0.9.2] — 2026-03-08

### Added — Groove HQ credential type (customer support / ticketing)

- `schema.js`: Groove schema with `apiToken` (Bearer, sensitive) + `baseUrl` (default `https://api.groovehq.com/v1/`)
  - `skill` block wired: `useWhen`, `intents` (ticket_list, ticket_create, ticket_reply, support_monitor), fallback
- `lib/usage.js`: Groove usage example — `GET /v1/tickets?status=open&per_page=25` with Bearer auth
  - `allowedHosts: ['api.groovehq.com']`, params with defaults, commonError, docs
- `server.js`: Groove live validator — probes `GET /v1/me`, returns `Connected as <name> (<email>)` on success
  - Handles 401/403 with specific messages

### Fixed — Credential field format normalization

- `lib/registry.js`: Added `normalizeFields()` — converts any incoming flat string `"value"` to wrapped `{value: "..."}` object
- Applied in both `createCredential()` and `updateCredential()` — consistent format guaranteed on all writes
- One-time migration: fixed existing flat-format fields in `google-workspace` and initial `groove` save
- All validators/usage examples use `fields.key?.value` pattern — now reliable for all credentials
- Exported `normalizeFields` for use in tests and migrations

---

## [0.9.1] — 2026-03-07

### Fixed — CONNECTORS.md: remove server-behavior bullets

- Removed 3 bullets from `scripts/agent-init.sh` generated `CONNECTORS.md` section:
  `primaryKey` field, package-name resolution, `usage.curl` pointer
- These document server behavior (can change), not environmental constraints (permanent)
- If they went stale, fresh installs would get confidently wrong agent instructions
- Rule: CONNECTORS.md contains only what the server *cannot* tell you

### Updated — Release checklist

- Force-push pattern for subtree divergence documented
- `versions.json` jq one-liner updates both `version` and `artifact_url`
- Install repo: clone-fresh + SSH remote switch (avoids HTTPS auth failure)
- tools-packages: API tag pattern, no clone needed
- Explicit patch release policy: batch doc-only fixes unless install behavior affected

---

## [0.9.0] — 2026-03-07

### ✨ Self-configuring intent router — agent ready on first session after install

The full intent→credential→execute chain is now zero-configuration. After install,
the agent reads TOOLS.md and knows exactly which endpoint to call, which auth header
to use, and what the common errors are — without reading any other documentation.

#### Added — Complete call templates in TOOLS.md

- `lib/usage.js`: full `getExampleDefinition()` for all 33 services
  - Every service: HTTP method, exact URL, auth header format, params+defaults, commonError, docs link
  - OAuth services (Amadeus): template directs agent to `/token` endpoint first
  - CLI-only services (gog, 1Password, Whisper): explicit "use CLI / tool X" instructions
  - Managed services (Telegram, Mem0): "use OpenClaw tool, not direct API" notes
- `lib/generator.js`: call templates now rendered into TOOLS.md per service
  - `curl` snippet (keys redacted), call params with defaults, common error hints
  - 24/24 agent-callable services covered; 0 stubs remaining
  - `buildUsageExample()` called per service block

#### Added — `generateToolsMd()` on every credential mutation

- `POST /api/credentials` (create), `PUT /api/credentials/:id` (update fields + rename),
  `DELETE /api/credentials/:id` — all trigger TOOLS.md regeneration
- TOOLS.md mtime is a reliable staleness signal: changed = credentials changed

#### Added — `scripts/agent-init.sh` — post-install agent configurator

- Writes `CONNECTORS.md` (2 permanent exceptions) with server URL/password baked in
- Patches `AGENTS.md` with the intent router section (marker-based, idempotent)
- Verifies: tools server reachable, TOOLS.md present, files written
- Called automatically from `install.sh` after server starts

#### Added — `install.sh`: `configure_agent()` step

- Detects OpenClaw workspace, calls `agent-init.sh` with correct URL + password
- Skips gracefully if workspace not found (prints manual-run hint)

#### Added — `resolvePrimaryKey()` in `server.js`

- Every `GET /api/credentials/:id` response now includes `primaryKey` field
- Normalized auth value regardless of internal field name (`apiKey`, `apiToken`, `token`, etc.)
- Agent never needs to know field name internals

#### Fixed — `getCredential()` resolves by package name

- `readwise` resolves to `readwise-1772811314235` automatically
- Agents never need to know timestamp-suffixed IDs

#### Updated — AGENTS.md

- Replaced credential notes/gotchas with clean 4-step flow:
  `check mtime → match intent → get primaryKey → execute`
- Two permanent exceptions only (web_fetch/private IP, gog CLI)
- All other guidance lives in TOOLS.md (generated) or the server

#### Updated — CONNECTORS.md

- Reduced to 37 lines: bootstrap curl pattern + gog CLI exception
- Tools server is the source of truth for everything else

### Fresh-install flow

```
bash install.sh
  → server starts, TOOLS.md generates
  → configure_agent() → agent-init.sh patches AGENTS.md + writes CONNECTORS.md
  → user fills credentials in dashboard
  → each save → validates + regenerates TOOLS.md with call templates
  → agent first session: reads TOOLS.md, checks mtime before calls, never guesses
```

---

## [0.8.7] — 2026-03-06

### Added — End-to-end integration verification

- New `verify-integrations.sh` script: tests full chain for every credential
  - Package schema + skill block check
  - Credential field validation
  - Intent router resolution
  - Usage example availability
  - Live API probe (actual HTTP calls to each service)
- Supports `--skip-live` (infrastructure-only check) and `--only <pkg>` (single service)
- 33 credentials verified, all green

### Added — Router intents for NanoBanana and Oura

- `image_generation`, `image_edit` → nanoBanana
- `sleep_data`, `health_metrics`, `readiness_check` → oura
- Previously these credentials existed but the intent router couldn't route to them

### Fixed — Todoist API v1 migration

- Todoist deprecated `rest/v2` (returns 410 Gone), migrated to `api/v1`
- Updated verify probe to use new endpoint

### Updated — Release checklist (steps 6–7)

- Added mandatory live API probe step after wiring a new credential
- Added agent delivery simulation step (full intent → router → credential → query → deliver chain)
- Documented the Readwise incident as canonical example of shipping without E2E verification
- Added note about timestamp-suffixed credential IDs for package-based credentials

## [0.8.6] — 2026-03-06

### Fixed — Package→TOOLS.md pipeline

- `generator.js` was reading stale `registry.services` instead of `credentials`
- Package-based credentials (Readwise, Obsidian-Sync) were invisible to TOOLS.md and routing
- `packages.js` now passes the `skill` block to schemas correctly

## [0.8.5] — 2026-03-06

### Fixed — Secret field safety

- Restored pre-fill for password/API-key fields on Edit (1Password-style reveal + compare)
- Added `data-original` guard: unchanged secrets are **not re-saved**, preventing silent truncation/corruption
- Confirmed no `maxlength` or server-side length limits on credential fields

## [0.8.4] — 2026-03-06

### Added — Obsidian Sync (Headless)

- New credential type: `obsidian-sync`
- OTP-only one-shot login flow from the dashboard (no terminal required)
- Optional server-managed vault paths with safe base directory
- Auto `ob sync-setup` after login when remote vault is selected
- Vault picker: remote vault list endpoint + dropdown on credential edit

### Added — Readwise API token support

- New credential type: `readwise`
- Validator confirms token via `GET /api/v2/auth/` and returns "Readwise token OK"

### Improved — Health + validation signal quality

- Clicking **Test** now invalidates cached health so refresh reflects the latest result
- Pinecone validator sends `X-Pinecone-API-Version: 2024-04` and surfaces auth rejection reason headers

### Safety

- Registry now keeps automatic versioned backups (`tools-registry-backups/`, newest 50)

## [0.8.3] — 2026-03-05

### Improved — Mem0 card UX and health feedback

- Mem0 labels simplified to `long-term-memory`
- After clicking **Test**, credential card health now updates immediately (`health: ok` / `health: fail`) without waiting for global refresh

## [0.8.2] — 2026-03-05

### Fixed — Mem0 credential validation signal quality

- Mem0 validator now probes `/v1/memories/` with optional `userId`
- Treats `400` context-required responses as **key valid** (warning) instead of ambiguous endpoint mismatch
- Keeps `401/403` as hard invalid key failures

## [0.8.1] — 2026-03-05

### Added — Mem0 as first-class credential type

- New service schema: `mem0` (Memory category)
- Dashboard fields: `apiKey`, `userId`, `orgId`, `projectId`, `mode`
- Live validator added for Mem0 API key connectivity
- Included in generated Tool Catalog routing metadata

## [0.8.0] — 2026-03-05

### Added — Gemini credential as first-class AI provider

- New infrastructure provider schema: `google` (Gemini API)
- Dedicated validator for Gemini API key (`/v1beta/models`)
- Supports separate dashboard setup/testing from Nano Banana

### Improved — OpenClaw compare/status source resolution

- `openclaw auth` compare now resolves provider source from effective OpenClaw auth state
- Supports both `profiles` and `env` origins instead of profile-file-only assumptions
- OpenAI now reports correctly when key is active via profile/env and avoids false "missing" state

## [0.7.9] — 2026-03-05

### Fixed — Update checker downgrade false-positive

- `/api/update/check` now treats update availability as **remote newer only** (semver-aware)
- Added response fields: `remoteIsNewer`, `versionComparison`, and refined `relation`
- Dashboard Update chip/modal now block downgrade prompts and correctly show "Local build is ahead" when applicable

## [0.7.8] — 2026-03-05

### Added — Dashboard push to OpenClaw auth profiles

- New status endpoint: `GET /api/openclaw/auth/status`
- New compare endpoint: `GET /api/openclaw/auth/compare/:credentialId`
- New push endpoint: `POST /api/credentials/:id/push/openclaw`
- Dashboard adds **OpenClaw** action on supported provider cards (`anthropic|openai|moonshot|google`)
- Push flow now backs up `auth-profiles.json`, writes `provider:default` API key profile, updates `lastGood`, and attempts gateway restart

### Safety gates

- Feature is disabled by default
- Enable with `TOOLS_CONFIG_OPENCLAW_PUSH=1`
- Optional overrides: `OPENCLAW_STATE_DIR`, `OPENCLAW_AGENT_ID`, `OPENCLAW_AUTH_PROFILES_PATH`, `OPENCLAW_RESTART_CMD`

## [0.7.7] — 2026-03-05

### Added — Agent discoverability

**`GET /api/agent-guide` (no auth required):**
New self-describing endpoint for AI agents. Returns: quickstart steps, all key endpoints with descriptions, intent router summary with supported intents, list of configured credential IDs, and agent tips. Available without authentication so agents can discover how to use the server before they have credentials.

**`/root/.tools-server-access` written on install:**
Installer now writes a JSON file with URL, password, version, install path, and agent-guide URL to `/root/.tools-server-access` (chmod 600). Agents and operators can always find server access details without scrolling through install logs.

## [0.7.6] — 2026-03-05

### Fixed — Pinecone integration

**Probe was a false positive:**
The health check was hitting `app.pinecone.io/actions/whoami`, which returns an HTML 200 regardless of API key validity. Any Pinecone credential always showed ✅ Connected even when the key was wrong or expired.

**Probe now hits the real data plane:**
`POST /describe_index_stats` on the actual index host. Returns vector count on success (`Connected to Pinecone • 1059 vectors in sop-docs`), and meaningful errors on failure (`403 — check API key or IP allowlist`).

**Index Host field now accepts full URLs:**
Pinecone's dashboard shows the host as `https://your-index.svc.aped-xxxx.pinecone.io`. Users can now paste this directly — the `https://` prefix is stripped automatically. No more "getaddrinfo EAI_AGAIN https" DNS errors.

**Schema updated:**
- Renamed `host` → `indexHost` (with updated placeholder showing full URL format)
- Added `indexName` field
- Removed stale `environment` field from required set

**Usage example added:**
`lib/usage.js` now includes a runnable Pinecone example (`describe_index_stats`) with correct headers, expected response shape, and common error guidance.

---

## [0.7.5] — 2026-03-01

- 1Password agent-callable (service account, skill block)
- Full VPS installer validated on fresh Hetzner VM
- Health dashboard with OAuth token expiry tracking


