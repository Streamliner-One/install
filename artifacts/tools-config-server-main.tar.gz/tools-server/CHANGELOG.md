# Changelog

## [0.7.6] — 2026-03-05

### Fixed — Pinecone integration

**Probe was a false positive:**
The health check was hitting `app.pinecone.io/actions/whoami`, which returns an HTML 200 regardless of API key validity. Any Pinecone credential always showed ✅ Connected even when the key was wrong or expired.

**Probe now hits the real data plane:**
`POST /describe_index_stats` on the actual index host. Returns vector count on success (`Connected to Pinecone • 1059 vectors in sop-docs`), and meaningful errors on failure (`403 — check API key or IP allowlist`).

**Index Host field now accepts full URLs:**
Pinecone's dashboard shows the host as `https://your-index.svc.aped-xxxx.pinecone.io`. Users can now paste this directly — the `https://` prefix is stripped automatically. No more "getaddrinfo EAI_AGAIN https" DNS errors.

**Schema updated:**
- Renamed `host` → `indexHost` (with updated placeholder showing full URL format)
- Added `indexName` field
- Removed stale `environment` field from required set

**Usage example added:**
`lib/usage.js` now includes a runnable Pinecone example (`describe_index_stats`) with correct headers, expected response shape, and common error guidance.

---

## [0.7.5] — 2026-03-01

- 1Password agent-callable (service account, skill block)
- Full VPS installer validated on fresh Hetzner VM
- Health dashboard with OAuth token expiry tracking
