// Service schemas - defines the form structure for each integration

const AGENT_SCHEMA = {
  id: 'mel',
  name: 'Mel (Agent Behavior)',
  category: 'agent',
  labels: ['agent', 'ops', 'reliability'],
  icon: '✨',
  description: 'Agent behavior and rate limit settings',
  fields: [
    { 
      key: 'rateLimitNotify', 
      label: 'Notify on rate limits (429)', 
      type: 'select', 
      required: true, 
      options: ['always', 'after-3-retries', 'never'],
      default: 'always',
      help: 'When to inform user about rate limit errors'
    },
    { 
      key: 'rateLimitPauseSeconds', 
      label: 'Pause duration (seconds)', 
      type: 'number', 
      required: false, 
      placeholder: '30',
      default: '30',
      help: 'How long to pause when hitting 429 before retrying'
    },
    { 
      key: 'rateLimitMaxRetries', 
      label: 'Max retries', 
      type: 'number', 
      required: false, 
      placeholder: '3',
      default: '3',
      help: 'Maximum retry attempts with exponential backoff'
    },
    {
      key: 'rateLimitBackoffMultiplier',
      label: 'Backoff multiplier',
      type: 'number',
      required: false,
      placeholder: '2',
      default: '2',
      help: 'Multiply wait time by this factor on each retry (1.5 = conservative, 2 = standard, 3 = aggressive)'
    }
  ]
};

const SERVICE_SCHEMAS = {
  '1password': {
    id: '1password',
    name: '1Password',
    category: 'security',
    labels: ['security', 'secrets', 'credentials', 'vault'],
    icon: '🔐',
    description: 'Service account for secret retrieval via op CLI',
    fields: [
      { key: 'serviceAccountToken', label: 'Service Account Token', type: 'password', required: true, sensitive: true, placeholder: 'ops_...' },
      { key: 'account', label: 'Account Name', type: 'text', required: false, placeholder: 'prudkov' },
      { key: 'vault', label: 'Default Vault', type: 'text', required: false, placeholder: 'Alex-Mel' }
    ]
  },

  notion: {
    id: 'notion',
    name: 'Notion',
    category: 'productivity',
    labels: ['productivity', 'notes', 'database', 'knowledge'],
    icon: '📋',
    description: 'Note-taking and databases',
    fields: [
      { key: 'apiKey', label: 'API Key', type: 'password', required: true, sensitive: true, help: 'From notion.so/my-integrations' },
      { key: 'dbHome', label: 'Home DB ID', type: 'text', required: false },
      { key: 'dbTodos', label: 'Todos DB ID', type: 'text', required: false },
      { key: 'dbSupplements', label: 'Supplements DB ID', type: 'text', required: false }
    ],
    validation: {
      endpoint: 'https://api.notion.com/v1/users/me',
      headers: { 'Notion-Version': '2022-06-28' }
    }
  },

  'notion-enhanced': {
    id: 'notion-enhanced',
    name: 'Notion (Enhanced)',
    category: 'productivity',
    labels: ['productivity', 'notes', 'database', 'knowledge', 'multi-db'],
    icon: '📋',
    description: 'Notion with unlimited custom database connections',
    fields: [
      { key: 'version', label: 'Version', type: 'text', required: false },
      { key: 'db1Name', label: 'DB1 Name', type: 'text', required: false },
      { key: 'db1Id', label: 'DB1 ID', type: 'text', required: false },
      { key: 'db2Name', label: 'DB2 Name', type: 'text', required: false },
      { key: 'db2Id', label: 'DB2 ID', type: 'text', required: false },
      { key: 'db3Name', label: 'DB3 Name', type: 'text', required: false },
      { key: 'db3Id', label: 'DB3 ID', type: 'text', required: false }
    ]
  },

  todoist: {
    id: 'todoist',
    name: 'Todoist',
    category: 'productivity',
    labels: ['productivity', 'tasks', 'todo', 'planning'],
    icon: '✅',
    description: 'Task management',
    fields: [
      { key: 'apiToken', label: 'API Token', type: 'password', required: true, sensitive: true, help: 'From todoist.com/app/settings/integrations' }
    ],
    validation: {
      endpoint: 'https://api.todoist.com/api/v1/projects',
      source: '1password',
      item: 'Todoist API',
      field: 'credential'
    }
  },

  n8n: {
    id: 'n8n',
    name: 'n8n',
    category: 'automation',
    labels: ['automation', 'workflow', 'integration', 'orchestration'],
    icon: '⚙️',
    description: 'Workflow automation',
    fields: [
      { key: 'apiKey', label: 'API Key', type: 'password', required: true, sensitive: true, source: '1password', item: 'n8n API', field: 'credential' },
      { key: 'hostUrl', label: 'Host URL', type: 'url', required: true, placeholder: 'https://n8n.example.com', source: '1password', item: 'n8n API', field: 'hostname' },
      { key: 'webhook17track', label: '17TRACK Webhook', type: 'url', required: false, placeholder: 'https://n8n.../webhook/17track-to-mel' }
    ]
  },

  oura: {
    id: 'oura',
    name: 'Oura',
    category: 'health',
    labels: ['health', 'sleep', 'wellness', 'biometrics'],
    icon: '💍',
    description: 'Sleep and health tracking',
    fields: [
      { key: 'clientId', label: 'Client ID', type: 'text', required: true, source: '1password', item: 'Oura API' },
      { key: 'clientSecret', label: 'Client Secret', type: 'password', required: true, sensitive: true, source: '1password', item: 'Oura API', field: 'credential' }
    ]
  },

  '17track': {
    id: '17track',
    name: '17TRACK',
    category: 'logistics',
    labels: ['logistics', 'tracking', 'shipping', 'ecommerce'],
    icon: '📦',
    description: 'Package tracking',
    fields: [
      { key: 'apiKey', label: 'API Key', type: 'password', required: true, sensitive: true, source: '1password', item: '17TRACK API', field: 'credential' }
    ]
  },

  amadeus: {
    id: 'amadeus',
    name: 'Amadeus',
    category: 'travel',
    labels: ['travel', 'flight', 'hotel', 'booking'],
    icon: '✈️',
    description: 'Flight search API',
    fields: [
      { key: 'clientId', label: 'Client ID', type: 'text', required: true, source: '1password', item: 'Amadeus API', field: 'credential' },
      { key: 'clientSecret', label: 'Client Secret', type: 'password', required: true, sensitive: true, source: '1password', item: 'Amadeus API', field: 'Private API key' },
      { key: 'environment', label: 'Environment', type: 'select', required: true, options: ['production', 'test'], default: 'production' }
    ]
  },

  telegram: {
    id: 'telegram',
    name: 'Telegram Bot',
    category: 'messaging',
    labels: ['messaging', 'chat', 'bot', 'notifications'],
    icon: '💬',
    description: 'Bot integration',
    fields: [
      { key: 'botToken', label: 'Bot Token', type: 'password', required: true, sensitive: true, help: 'From @BotFather' },
      { key: 'chatId', label: 'Chat ID', type: 'text', required: false, placeholder: '58748195' }
    ]
  },

  weather: {
    id: 'weather',
    name: 'Weather',
    category: 'lifestyle',
    labels: ['weather', 'lifestyle'],
    icon: '🌤️',
    description: 'Weather data (Open-Meteo, no key needed)',
    fields: [
      { key: 'provider', label: 'Provider', type: 'select', required: true, options: ['open-meteo', 'openweathermap'], default: 'open-meteo' },
      { key: 'apiKey', label: 'API Key (if OWM)', type: 'password', required: false, sensitive: true, help: 'Only needed for OpenWeatherMap' }
    ]
  },

  elevenlabs: {
    id: 'elevenlabs',
    name: 'ElevenLabs',
    category: 'voice',
    labels: ['voice', 'tts', 'audio', 'speech'],
    icon: '🗣️',
    description: 'Text-to-speech',
    fields: [
      { key: 'apiKey', label: 'API Key', type: 'password', required: true, sensitive: true, source: 'openclaw-skill', skill: 'sag' },
      { key: 'defaultVoiceId', label: 'Default Voice ID', type: 'text', required: false, placeholder: 'cgSgspJ2msm6clMCkdW9' }
    ]
  },

  perplexity: {
    id: 'perplexity',
    name: 'Perplexity',
    category: 'ai',
    labels: ['ai', 'search', 'news', 'research', 'fresh-data'],
    icon: '🔮',
    description: 'AI search',
    fields: [
      { key: 'apiKey', label: 'API Key', type: 'password', required: true, sensitive: true }
    ]
  },

  duffel: {
    id: 'duffel',
    name: 'Duffel',
    category: 'travel',
    labels: ['travel', 'flight', 'booking', 'airfare'],
    icon: '🎫',
    description: 'Flight search (sandbox)',
    fields: [
      { key: 'apiKey', label: 'API Key', type: 'password', required: true, sensitive: true }
    ]
  },

  aviationstack: {
    id: 'aviationstack',
    name: 'Aviationstack',
    category: 'travel',
    labels: ['travel', 'flight-status', 'aviation', 'operations'],
    icon: '🛫',
    description: 'Flight status API',
    fields: [
      { key: 'apiKey', label: 'API Key', type: 'password', required: true, sensitive: true }
    ]
  },

  'google-workspace': {
    id: 'google-workspace',
    name: 'Google Workspace',
    category: 'productivity',
    labels: ['productivity', 'calendar', 'email', 'drive', 'documents'],
    icon: '🔷',
    description: 'Gmail, Calendar, Drive',
    fields: [
      { key: 'oauthClientJson', label: 'OAuth Client JSON Path', type: 'text', required: true, placeholder: '~/.config/gog/client_secret_...json' },
      { key: 'keyringPassword', label: 'Keyring Password Source', type: 'select', required: true, options: ['1password', 'file', 'env'], default: '1password' }
    ]
  },

  goplaces: {
    id: 'goplaces',
    name: 'Google Places',
    category: 'location',
    labels: ['location', 'search', 'travel', 'maps'],
    icon: '📍',
    description: 'Places API (New)',
    fields: [
      { key: 'apiKey', label: 'API Key', type: 'password', required: true, sensitive: true }
    ]
  },

  newsapi: {
    id: 'newsapi',
    name: 'NewsAPI',
    category: 'news',
    labels: ['news', 'search', 'fresh-data'],
    icon: '📰',
    description: 'News headlines',
    fields: [
      { key: 'apiKey', label: 'API Key', type: 'password', required: true, sensitive: true }
    ]
  },

  openexchangerates: {
    id: 'openexchangerates',
    name: 'Open Exchange Rates',
    category: 'finance',
    labels: ['finance', 'currency', 'fx', 'rates'],
    icon: '💱',
    description: 'Currency conversion',
    fields: [
      { key: 'apiKey', label: 'API Key', type: 'password', required: true, sensitive: true }
    ]
  },

  openai: {
    id: 'openai',
    name: 'OpenAI',
    category: 'ai',
    labels: ['ai', 'llm', 'generation', 'reasoning'],
    icon: '🤖',
    description: 'GPT models',
    fields: [
      { key: 'apiKey', label: 'API Key', type: 'password', required: true, sensitive: true },
      { key: 'orgId', label: 'Organization ID', type: 'text', required: false }
    ]
  },

  anthropic: {
    id: 'anthropic',
    name: 'Anthropic',
    category: 'ai',
    labels: ['ai', 'llm', 'reasoning', 'analysis'],
    icon: '🧠',
    description: 'Claude models',
    fields: [
      { key: 'apiKey', label: 'API Key', type: 'password', required: true, sensitive: true }
    ]
  },

  moonshot: {
    id: 'moonshot',
    name: 'Moonshot',
    category: 'ai',
    labels: ['ai', 'llm', 'reasoning', 'chat'],
    icon: '🌙',
    description: 'Kimi models',
    fields: [
      { key: 'apiKey', label: 'API Key', type: 'password', required: true, sensitive: true }
    ]
  },

  nanoBanana: {
    id: 'nanoBanana',
    name: 'Nano Banana Pro',
    category: 'image',
    labels: ['image', 'generation', 'creative', 'design'],
    icon: '🖼️',
    description: 'Image generation',
    fields: [
      { key: 'apiKey', label: 'API Key', type: 'password', required: true, sensitive: true }
    ]
  },

  whisper: {
    id: 'whisper',
    name: 'OpenAI Whisper',
    category: 'audio',
    labels: ['audio', 'transcription', 'speech-to-text', 'voice'],
    icon: '🎙️',
    description: 'Speech-to-text',
    fields: [
      { key: 'apiKey', label: 'API Key', type: 'password', required: true, sensitive: true }
    ]
  },

  vapi: {
    id: 'vapi',
    name: 'VAPI',
    category: 'voice',
    labels: ['voice', 'telephony', 'agent', 'automation'],
    icon: '📞',
    description: 'Voice AI platform',
    fields: [
      { key: 'apiKey', label: 'API Key', type: 'password', required: true, sensitive: true },
      { key: 'assistantId', label: 'Assistant ID', type: 'text', required: false },
      { key: 'phoneNumberId', label: 'Phone Number ID', type: 'text', required: false }
    ]
  },

  hubspot: {
    id: 'hubspot',
    name: 'HubSpot',
    category: 'crm',
    labels: ['crm', 'sales', 'marketing', 'contacts'],
    icon: '🟠',
    description: 'CRM integration',
    fields: [
      { key: 'accessToken', label: 'Private Access Token', type: 'password', required: true, sensitive: true }
    ]
  },

  pinecone: {
    id: 'pinecone',
    name: 'Pinecone',
    category: 'vector-db',
    labels: ['vector-db', 'search', 'rag', 'embeddings', 'knowledge'],
    icon: '🌲',
    description: 'Vector database',
    fields: [
      { key: 'apiKey', label: 'API Key', type: 'password', required: true, sensitive: true },
      { key: 'host', label: 'Host', type: 'text', required: true, placeholder: 'app.pinecone.io', default: 'app.pinecone.io' },
      { key: 'environment', label: 'Environment', type: 'text', required: false, placeholder: 'us-east1-gcp' }
    ]
  },

  brave: {
    id: 'brave',
    name: 'Brave Search',
    category: 'search',
    labels: ['search', 'news', 'research', 'fresh-data'],
    icon: '🦁',
    description: 'Web search API',
    fields: [
      { key: 'apiKey', label: 'API Key', type: 'password', required: true, sensitive: true }
    ]
  }
};

module.exports = { SERVICE_SCHEMAS, AGENT_SCHEMA };