# Schema V2 — Domain Scoping, Risk Tiers & Privacy Routing

Design document for extending the tools server rule and integration schemas.

## Problem

Rules (SOUL.md, AGENTS.md, intent rules) are flat strings with **implicit scope**. The model must infer when a rule applies and when it doesn't. At 25 rules this causes misapplication (e.g., SEA protocol applied to `docker compose pull`). At 100+ rules it becomes unmanageable.

Similarly, integrations have no data policy — the model decides what data to send where based on general safety instincts, with no declarative controls.

## Design Goals

1. Every rule explicitly declares its domain, risk tier, and exclusions
2. Every integration declares what data types it may receive
3. A pre-flight check (in context, not code) prevents data/domain mismatches
4. The TOOLS.md generator renders all of this so the model sees it every session
5. Backward compatible — existing rules without new fields continue to work

---

## 1. Domain Taxonomy

Defined once, referenced everywhere. ~8 domains covering all agent actions:

```json
{
  "domains": {
    "INFRA":     { "label": "Infrastructure", "description": "SSH, Docker, packages, services, files, APIs on own systems", "sensitivity": "private" },
    "COMMS":     { "label": "Communications", "description": "Emails, messages, posts — anything sent to another person", "sensitivity": "controlled" },
    "FINANCIAL": { "label": "Financial", "description": "Payments, purchases, subscriptions, billing", "sensitivity": "controlled" },
    "DATA_CLIENT": { "label": "Client Data", "description": "Client PII, booking details, ticket contents, business records", "sensitivity": "confidential" },
    "DATA_PERSONAL": { "label": "Personal Data", "description": "Family info, health data, documents, passwords", "sensitivity": "confidential" },
    "DATA_INTERNAL": { "label": "Internal Data", "description": "Workspace files, configs, memory, tool outputs", "sensitivity": "private" },
    "RECALL":    { "label": "Recall", "description": "Names, dates, numbers, facts from memory — factual accuracy domain", "sensitivity": "n/a" },
    "DESIGN":    { "label": "Design", "description": "Architecture, system changes, new integrations, structural decisions", "sensitivity": "n/a" },
    "RESPONSE":  { "label": "Response Style", "description": "Tone, format, length, language, temporal phrasing", "sensitivity": "n/a" },
    "SAFETY":    { "label": "Safety", "description": "Security, privacy, external content trust, prompt injection", "sensitivity": "n/a" }
  }
}
```

### Sensitivity Levels

| Level | Meaning | Default behavior |
|-------|---------|-----------------|
| `confidential` | Must not leave the system without explicit user approval | Block egress, log attempt |
| `controlled` | Requires confirmation before external action | Confirm once, then proceed |
| `private` | Internal operations, no restrictions | Execute and report |
| `n/a` | Not a data domain — governs behavior | No data policy applies |

---

## 2. Risk Tiers

Replace binary "ask or don't" with three tiers. Every rule and every action gets a tier:

```json
{
  "tiers": {
    "1": { "label": "Execute & Report", "description": "Reversible, own systems, documented procedure", "behavior": "Do it, report result" },
    "2": { "label": "Confirm Once", "description": "Irreversible but private — deletions, schema changes, data migrations", "behavior": "State what will happen, get one confirmation, execute" },
    "3": { "label": "Align First", "description": "Public-facing, financial, contacts others, architectural decisions", "behavior": "SEA protocol — investigate, evaluate with options, implement after alignment" }
  }
}
```

### Tier Assignment Rules

| Domain | Default Tier | Override conditions |
|--------|-------------|-------------------|
| INFRA | 1 | Tier 2 if destructive (rm, drop, reset) |
| COMMS | 3 | — |
| FINANCIAL | 3 | — |
| DATA_CLIENT | 2 | Tier 3 if egressing outside system |
| DATA_PERSONAL | 2 | Tier 3 if egressing outside system |
| DATA_INTERNAL | 1 | Tier 2 if deletion |
| RECALL | 1 | — |
| DESIGN | 3 | Tier 1 for trivial config changes |
| RESPONSE | 1 | — |
| SAFETY | 3 | Universal, never overridden |

---

## 3. Extended Rule Schema

New fields added to intent/behavior rules:

```json
{
  "id": "external_action_caution",
  "intent": "external_action_caution",
  "type": "behavior",
  "description": "Ask before acting on public-facing or financial actions",
  "triggers": [],
  "domain": ["COMMS", "FINANCIAL"],
  "excludes": ["INFRA", "DATA_INTERNAL"],
  "tier": 3,
  "notes": "Emails, posts, payments, contacting third parties."
}
```

### New fields

| Field | Type | Required | Default | Description |
|-------|------|----------|---------|-------------|
| `domain` | `string[]` | No | `["*"]` (all) | Which domains this rule applies to |
| `excludes` | `string[]` | No | `[]` | Domains explicitly excluded |
| `tier` | `number` | No | Inferred from domain | Risk tier (1/2/3) |

### Backward compatibility

- Rules without `domain`/`excludes`/`tier` continue to work — they apply universally as today
- The generator renders scope info only when present, so existing rules generate identical TOOLS.md output
- Migration is incremental: add scope to rules as they cause issues, not all at once

---

## 4. Integration Data Policy

New `dataPolicy` field on integration schemas (in `schema.js` or `package.json`):

```json
{
  "id": "brave",
  "name": "Brave Search",
  "dataPolicy": {
    "allowedDomains": ["DATA_INTERNAL", "RECALL"],
    "blockedDomains": ["DATA_CLIENT", "DATA_PERSONAL", "FINANCIAL"],
    "requiresConfirmation": false,
    "auditLevel": "none"
  }
}
```

### Data policy fields

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `allowedDomains` | `string[]` | `["*"]` | Which data domains may be sent to this integration |
| `blockedDomains` | `string[]` | `[]` | Domains that must never reach this integration |
| `requiresConfirmation` | `boolean` | `false` | Whether to confirm before any call (regardless of domain) |
| `auditLevel` | `string` | `"none"` | `none` / `log` / `alert` — what to do when data policy is relevant |

### How it works in practice

The TOOLS.md generator renders a "Data Policy" line per integration:

```
### 🦁 Brave Search
- **Data policy:** Accepts queries and public info. Blocks client PII and personal data.
```

The model reads this in context and routes accordingly. No runtime middleware needed — the policy is **declarative context** that shapes the model's tool-call decisions, just like intent rules shape routing decisions today.

For high-sensitivity cases (COMMS, FINANCIAL), the tier system adds a second check — even if the data policy allows it, Tier 3 behavior still requires alignment.

---

## 5. Generator Changes

### TOOLS.md rendering additions

1. **Domain taxonomy header** — rendered once at the top of TOOLS.md, so the model sees the complete domain/tier system every session

2. **Per-rule scope line** — when `domain`/`tier` fields exist:
   ```
   #### `temporal_reference`
   - **Domain:** RESPONSE
   - **Tier:** 1 (execute & report)
   - **Triggers:** (none — reflexive)
   - **Notes:** ...
   ```

3. **Per-integration data policy line** — when `dataPolicy` exists:
   ```
   ### 🦁 Brave Search
   - **Data policy:** Allowed: queries, public info. Blocked: client PII, personal data.
   ```

4. **Pre-flight reference** — a short block after the domain taxonomy explaining the tier decision tree:
   ```
   ## Pre-flight Decision Tree
   1. Identify action domain (INFRA/COMMS/FINANCIAL/etc.)
   2. Check tier (1=do it, 2=confirm once, 3=align first)
   3. If calling an integration: check data policy — is this data type allowed?
   4. If blocked: refuse and explain. If controlled: confirm with user.
   ```

---

## 6. Migration Plan

### Phase 1 — Schema extension (this sprint)
- Add `domain`, `excludes`, `tier` to `upsertIntentRule()` validation in `registry.js`
- Add `dataPolicy` field support to `schema.js` service schemas
- Update `generator.js` to render domain taxonomy, per-rule scopes, per-integration data policies
- No existing rules break — fields are optional

### Phase 2 — Scope existing rules
- Add domain/tier to the 5-6 rules that have caused misapplication:
  - `composure_protocol` → domain: DESIGN, tier: 3
  - `research_before_theory` → domain: DESIGN, INFRA (excludes: RESPONSE, RECALL)
  - `temporal_reference` → domain: RESPONSE, tier: 1
  - `heartbeat_ack` → domain: INFRA, tier: 1
  - `streamliner_readonly` → domain: DATA_INTERNAL, tier: 2
- Test: verify TOOLS.md renders correctly with scoped rules

### Phase 3 — Data policies on integrations
- Add `dataPolicy` to integrations that handle external data:
  - Brave, Perplexity, Tavily → block DATA_CLIENT, DATA_PERSONAL
  - Groove → allow DATA_CLIENT (it's the source)
  - Google Workspace → controlled (COMMS domain, tier 3)
  - Amadeus → allow travel queries, block personal data
- Test: verify model respects policies in routing decisions

### Phase 4 — Audit & refinement
- Review rule-domain coverage: which rules still have no scope?
- Add audit logging for blocked data egress attempts
- Consider runtime middleware for Phase 5 (optional — context-based enforcement may be sufficient)

---

## 7. What This Does NOT Do (and why)

- **No runtime code enforcement** — NemoClaw intercepts at the network layer. We enforce via context. This is sufficient for a single-user system where the model is the only actor. If we add automated workflows running unsupervised, Phase 5 adds runtime checks.
- **No kernel sandboxing** — NemoClaw's OpenShell runs tools in isolated containers. Overkill for a personal system. Revisit if/when running untrusted code.
- **No policy engine** — NemoClaw has a declarative policy language. Our domain/tier system is simpler but covers the same ground for personal use.

---

## Files to Modify

| File | Changes |
|------|---------|
| `tools-server/lib/registry.js` | Accept `domain`, `excludes`, `tier` in `upsertIntentRule()` |
| `tools-server/schema.js` | Add `dataPolicy` field to service schemas |
| `tools-server/lib/generator.js` | Render domain taxonomy, per-rule scopes, data policies |
| `SOUL.md` | (Already done) Clarified "external" boundary definition |
| `AGENTS.md` | Reference domain taxonomy once implemented |

---

*Drafted 2026-03-18. Approved by: pending.*
