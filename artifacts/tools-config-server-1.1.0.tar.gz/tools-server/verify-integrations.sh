#!/usr/bin/env bash
# verify-integrations.sh — End-to-end integration verification
# Runs the full chain for every agent-callable credential:
#   1. Package schema loaded with skill block?
#   2. Credential has fields?
#   3. Router resolves at least one intent?
#   4. Usage example available?
#   5. Live API probe succeeds? (actual HTTP call)
#
# Usage: ./verify-integrations.sh [--skip-live] [--only <package-id>]

BASE_URL="${TOOLS_SERVER_URL:-https://mel.taile54a5b.ts.net:8443}"
PASSWORD="${TOOLS_SERVER_PASSWORD:-mel2026}"
COOKIE_FILE=$(mktemp)
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

PASS=0; FAIL=0; WARN=0; SKIP=0; TOTAL=0

# Parse args
ONLY=""; SKIP_LIVE=false
while [[ $# -gt 0 ]]; do
  case "$1" in
    --skip-live) SKIP_LIVE=true; shift ;;
    --only) ONLY="$2"; shift 2 ;;
    *) shift ;;
  esac
done

cleanup() { rm -f "$COOKIE_FILE" 2>/dev/null; }
trap cleanup EXIT

# Colors
R='\033[0;31m'; G='\033[0;32m'; Y='\033[0;33m'; C='\033[0;36m'; B='\033[1m'; N='\033[0m'
pass()   { echo -e "  ${G}✅ $1${N}"; ((PASS++)); }
fail()   { echo -e "  ${R}❌ $1${N}"; ((FAIL++)); }
warn()   { echo -e "  ${Y}⚠️  $1${N}"; ((WARN++)); }
skip_it(){ echo -e "  ${C}⏭️  $1${N}"; ((SKIP++)); }
header() { echo -e "\n${B}━━━ $1 ━━━${N}"; }

# ─── Login ───────────────────────────────────────────────────
echo -e "${B}🔐 Logging in to tools server...${N}"
LOGIN_RESP=$(curl -sk --max-time 10 -c "$COOKIE_FILE" -X POST "$BASE_URL/api/login" \
  -H 'Content-Type: application/json' \
  -d "{\"password\":\"$PASSWORD\"}" 2>/dev/null || echo '{}')

if ! echo "$LOGIN_RESP" | jq -e '.success' >/dev/null 2>&1; then
  echo -e "${R}❌ Login failed. Is the tools server running?${N}"
  exit 1
fi
echo -e "${G}✅ Authenticated${N}"

# ─── Helper: get credential field value ──────────────────────
get_field() {
  local cred_id="$1" field="$2"
  curl -sk -b "$COOKIE_FILE" "$BASE_URL/api/credentials/$cred_id" 2>/dev/null | \
    jq -r ".fields.${field}.value // .fields.${field} // empty" 2>/dev/null
}

# ─── Fetch credential list ───────────────────────────────────
CREDS_JSON=$(curl -sk --max-time 10 -b "$COOKIE_FILE" "$BASE_URL/api/credentials" 2>/dev/null)
mapfile -t CRED_IDS < <(echo "$CREDS_JSON" | jq -r '.credentials | keys[]' 2>/dev/null)
echo -e "📦 Found ${#CRED_IDS[@]} credentials"

# ─── Infrastructure packages (skip live probes) ──────────────
INFRA="mel telegram openai anthropic moonshot google brave pinecone mem0 1password github stripe holidays"

is_infra() {
  local pkg="$1"
  for i in $INFRA; do [[ "$pkg" == "$i" ]] && return 0; done
  return 1
}

# ─── Live probe functions ────────────────────────────────────
probe_weather() {
  curl -s --max-time 10 "https://api.open-meteo.com/v1/forecast?latitude=39.47&longitude=-0.38&current_weather=true" 2>/dev/null | \
    jq -e '.current_weather.temperature' >/dev/null 2>&1
}

probe_newsapi() {
  local key=$(get_field "newsapi" "apiKey")
  [[ -z "$key" ]] && return 1
  curl -s --max-time 10 "https://newsapi.org/v2/top-headlines?country=us&pageSize=1&apiKey=$key" 2>/dev/null | \
    jq -e '.status == "ok"' >/dev/null 2>&1
}

probe_openexchangerates() {
  local key=$(get_field "openexchangerates" "apiKey")
  [[ -z "$key" ]] && return 1
  curl -s --max-time 10 "https://openexchangerates.org/api/latest.json?app_id=$key&symbols=EUR" 2>/dev/null | \
    jq -e '.rates.EUR' >/dev/null 2>&1
}

probe_aviationstack() {
  local key=$(get_field "aviationstack" "apiKey")
  [[ -z "$key" ]] && return 1
  curl -s --max-time 10 "http://api.aviationstack.com/v1/flights?access_key=$key&limit=1" 2>/dev/null | \
    jq -e '.pagination // .data' >/dev/null 2>&1
}

probe_goplaces() {
  local key=$(get_field "goplaces" "apiKey")
  [[ -z "$key" ]] && return 1
  curl -s --max-time 10 \
    "https://places.googleapis.com/v1/places:searchText" \
    -H "Content-Type: application/json" \
    -H "X-Goog-Api-Key: $key" \
    -H "X-Goog-FieldMask: places.displayName" \
    -d '{"textQuery":"test","maxResultCount":1}' 2>/dev/null | \
    jq -e '.places' >/dev/null 2>&1
}

probe_todoist() {
  local key=$(get_field "todoist" "apiToken")
  [[ -z "$key" ]] && return 1
  # Todoist migrated to api/v1 (rest/v2 returns 410 since ~2026)
  local status=$(curl -s -o /dev/null -w "%{http_code}" --max-time 10 \
    "https://api.todoist.com/api/v1/projects" \
    -H "Authorization: Bearer $key" 2>/dev/null)
  [[ "$status" == "200" ]]
}

probe_oura() {
  # Oura uses OAuth2 (clientId + clientSecret), not a personal access token.
  # Can't do a lightweight probe without a user access token from the OAuth flow.
  # Just verify credential fields are present.
  local cid=$(get_field "oura" "clientId")
  local csec=$(get_field "oura" "clientSecret")
  [[ -n "$cid" && -n "$csec" ]]
}

probe_17track() {
  local key=$(get_field "17track" "apiKey")
  [[ -z "$key" ]] && return 1
  local status=$(curl -s -o /dev/null -w "%{http_code}" --max-time 10 \
    -X POST "https://api.17track.net/track/v2.2/gettrackinfo" \
    -H "Content-Type: application/json" \
    -H "17token: $key" \
    -d '[{"num":"TEST123"}]' 2>/dev/null)
  [[ "$status" == "200" || "$status" == "400" || "$status" == "401" ]]
}

probe_elevenlabs() {
  local key=$(get_field "elevenlabs" "apiKey")
  [[ -z "$key" ]] && return 1
  curl -s --max-time 10 "https://api.elevenlabs.io/v1/user" \
    -H "xi-api-key: $key" 2>/dev/null | \
    jq -e '.subscription' >/dev/null 2>&1
}

probe_perplexity() {
  local key=$(get_field "perplexity" "apiKey")
  [[ -z "$key" ]] && return 1
  local status=$(curl -s -o /dev/null -w "%{http_code}" --max-time 15 \
    -X POST "https://api.perplexity.ai/chat/completions" \
    -H "Authorization: Bearer $key" \
    -H "Content-Type: application/json" \
    -d '{"model":"sonar","messages":[{"role":"user","content":"ping"}],"max_tokens":1}' 2>/dev/null)
  [[ "$status" == "200" ]]
}

probe_amadeus() {
  local cid=$(get_field "amadeus" "clientId")
  local csec=$(get_field "amadeus" "clientSecret")
  [[ -z "$cid" || -z "$csec" ]] && return 1
  curl -s --max-time 10 -X POST "https://api.amadeus.com/v1/security/oauth2/token" \
    -H "Content-Type: application/x-www-form-urlencoded" \
    -d "grant_type=client_credentials&client_id=$cid&client_secret=$csec" 2>/dev/null | \
    jq -e '.access_token' >/dev/null 2>&1
}

probe_readwise() {
  # Find the actual credential ID (may have timestamp suffix)
  local cred_id=""
  for id in "${CRED_IDS[@]}"; do
    [[ "$id" == readwise* ]] && cred_id="$id" && break
  done
  [[ -z "$cred_id" ]] && return 1
  local key=$(get_field "$cred_id" "apiToken")
  [[ -z "$key" ]] && return 1
  curl -s --max-time 10 "https://readwise.io/api/v2/highlights/?page_size=1" \
    -H "Authorization: Token $key" 2>/dev/null | \
    jq -e '.count > 0' >/dev/null 2>&1
}

probe_notion() {
  local key=$(get_field "notion" "apiKey")
  [[ -z "$key" ]] && return 1
  local status=$(curl -s -o /dev/null -w "%{http_code}" --max-time 10 \
    "https://api.notion.com/v1/users/me" \
    -H "Authorization: Bearer $key" \
    -H "Notion-Version: 2022-06-28" 2>/dev/null)
  [[ "$status" == "200" ]]
}

probe_notion_enhanced() { probe_notion; }

probe_vapi() {
  local key=$(get_field "vapi" "apiKey")
  [[ -z "$key" ]] && return 1
  local status=$(curl -s -o /dev/null -w "%{http_code}" --max-time 10 \
    "https://api.vapi.ai/assistant" \
    -H "Authorization: Bearer $key" 2>/dev/null)
  [[ "$status" == "200" ]]
}

probe_n8n() {
  local url=$(get_field "n8n" "hostUrl")
  local key=$(get_field "n8n" "apiKey")
  [[ -z "$url" ]] && return 1
  local status=$(curl -sk -o /dev/null -w "%{http_code}" --max-time 10 \
    "$url/api/v1/workflows?limit=1" \
    -H "X-N8N-API-KEY: $key" 2>/dev/null)
  [[ "$status" == "200" ]]
}

probe_duffel() {
  local key=$(get_field "duffel" "apiKey")
  [[ -z "$key" ]] && return 1
  local status=$(curl -s -o /dev/null -w "%{http_code}" --max-time 10 \
    "https://api.duffel.com/air/airports?limit=1" \
    -H "Authorization: Bearer $key" \
    -H "Duffel-Version: v2" 2>/dev/null)
  [[ "$status" == "200" ]]
}

probe_whisper() {
  # Whisper needs an audio file; just verify the key format exists
  local key=$(get_field "whisper" "apiKey")
  [[ -n "$key" && "$key" == sk-* ]]
}

probe_google_workspace() {
  # OAuth-based, can't probe with a simple curl. Check config file exists.
  local path=$(get_field "google-workspace" "oauthClientJson")
  [[ -n "$path" && -f "$path" ]]
}

probe_nanoBanana() {
  # Gemini image gen — just verify key format
  local key=$(get_field "nanoBanana" "apiKey")
  [[ -n "$key" && "$key" == AIza* ]]
}

probe_obsidian_sync() {
  # Check vault path exists
  local cred_id=""
  for id in "${CRED_IDS[@]}"; do
    [[ "$id" == obsidian-sync* ]] && cred_id="$id" && break
  done
  [[ -z "$cred_id" ]] && return 1
  local path=$(get_field "$cred_id" "vaultPath")
  [[ -n "$path" && -d "$path" ]]
}

# ─── Main loop ───────────────────────────────────────────────
ROUTER_JSON=$(cat "$SCRIPT_DIR/router.json" 2>/dev/null || echo '{"routes":{}}')

for CRED_ID in "${CRED_IDS[@]}"; do
  CRED_DETAIL=$(curl -sk -b "$COOKIE_FILE" "$BASE_URL/api/credentials/$CRED_ID" 2>/dev/null)
  CRED_NAME=$(echo "$CRED_DETAIL" | jq -r '.name // .id' 2>/dev/null)
  PKG_ID=$(echo "$CRED_DETAIL" | jq -r '.packageId // empty' 2>/dev/null)
  [[ -z "$PKG_ID" ]] && PKG_ID="$CRED_ID"

  # Filter
  if [[ -n "$ONLY" && "$PKG_ID" != "$ONLY" && "$CRED_ID" != "$ONLY" ]]; then
    continue
  fi

  ((TOTAL++))
  header "$CRED_NAME ($CRED_ID) [pkg: $PKG_ID]"

  IS_INFRA=false
  is_infra "$PKG_ID" && IS_INFRA=true

  # ── Step 1: Package schema with skill block ──
  if [[ -d "$SCRIPT_DIR/packages/$PKG_ID" && -f "$SCRIPT_DIR/packages/$PKG_ID/package.json" ]]; then
    if jq -e '.skill' "$SCRIPT_DIR/packages/$PKG_ID/package.json" >/dev/null 2>&1; then
      pass "Package schema + skill block"
    elif $IS_INFRA; then
      skip_it "Package schema (infrastructure — no skill expected)"
    else
      fail "Package exists but NO skill block → invisible to intent router"
    fi
  else
    if $IS_INFRA; then
      skip_it "Package dir (infrastructure)"
    else
      warn "No package dir: packages/$PKG_ID"
    fi
  fi

  # ── Step 2: Credential has fields ──
  FIELD_COUNT=$(echo "$CRED_DETAIL" | jq '.fields | length' 2>/dev/null || echo 0)
  if [[ "$FIELD_COUNT" -gt 0 ]]; then
    pass "Credential has $FIELD_COUNT field(s)"
  else
    fail "Credential has no fields"
  fi

  # ── Step 3: Router resolves intent ──
  if $IS_INFRA; then
    skip_it "Router (infrastructure)"
  else
    MATCHED=$(echo "$ROUTER_JSON" | jq -r ".routes | to_entries[] | select(.value | index(\"$PKG_ID\")) | .key" 2>/dev/null | head -5)
    if [[ -n "$MATCHED" ]]; then
      INTENT_LIST=$(echo "$MATCHED" | tr '\n' ', ' | sed 's/,$//')
      pass "Router intents: $INTENT_LIST"
    else
      fail "No router intents for '$PKG_ID'"
    fi
  fi

  # ── Step 4: Usage example ──
  USAGE_STATUS=$(curl -sk -o /dev/null -w "%{http_code}" -b "$COOKIE_FILE" "$BASE_URL/api/credentials/$CRED_ID/usage" 2>/dev/null)
  if [[ "$USAGE_STATUS" == "200" ]]; then
    pass "Usage example available"
  elif $IS_INFRA; then
    skip_it "Usage (infrastructure)"
  else
    warn "No usage example (HTTP $USAGE_STATUS)"
  fi

  # ── Step 5: Live API probe ──
  if $SKIP_LIVE; then
    skip_it "Live probe (--skip-live)"
    continue
  fi
  if $IS_INFRA; then
    skip_it "Live probe (infrastructure)"
    continue
  fi

  # Normalize function name: replace - with _, handle suffixed IDs
  PROBE_NAME=$(echo "$PKG_ID" | tr '-' '_')
  PROBE_FN="probe_$PROBE_NAME"

  if type "$PROBE_FN" &>/dev/null; then
    if $PROBE_FN; then
      pass "Live API probe ✓"
    else
      fail "Live API probe FAILED"
    fi
  else
    warn "No probe defined for '$PKG_ID' — add $PROBE_FN()"
  fi
done

# ─── Summary ─────────────────────────────────────────────────
echo ""
echo -e "${B}═══════════════════════════════════════${N}"
echo -e "${B}  Integration Verification Summary${N}"
echo -e "${B}═══════════════════════════════════════${N}"
echo -e "  Credentials checked: ${B}$TOTAL${N}"
echo -e "  ${G}Passed:   $PASS${N}"
echo -e "  ${R}Failed:   $FAIL${N}"
echo -e "  ${Y}Warnings: $WARN${N}"
echo -e "  ${C}Skipped:  $SKIP${N}"
echo ""

if [[ $FAIL -gt 0 ]]; then
  echo -e "${R}${B}⚠️  $FAIL failure(s) detected. Fix before shipping.${N}"
  exit 1
else
  echo -e "${G}${B}✅ All integrations verified.${N}"
  exit 0
fi
