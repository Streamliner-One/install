#!/usr/bin/env node

const express = require('express');
const bcrypt = require('bcrypt');
const cookieParser = require('cookie-parser');
const helmet = require('helmet');
const https = require('https');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { execSync, spawn } = require('child_process');

const TOOLS_SERVER_VERSION = (() => {
  try { return require('./package.json').version; } catch { return '0.0.0'; }
})();

const { SERVICE_SCHEMAS, AGENT_SCHEMA } = require('./schema');

// Merge agent schema into service schemas
SERVICE_SCHEMAS[AGENT_SCHEMA.id] = AGENT_SCHEMA;

// Load tool packages (Phase 1: static JSON packages)
const { loadAllPackages, getPackageSchemas, getPackageValidators } = require('./lib/packages');
const loadedPackages = loadAllPackages();

// Merge package schemas into service schemas
const packageSchemas = getPackageSchemas();
for (const [id, schema] of Object.entries(packageSchemas)) {
  SERVICE_SCHEMAS[id] = schema;
}
const { loadRegistry, saveRegistry, getService, updateService, toggleService, listServices, getCredential, createCredential, updateCredential, deleteCredential, listCredentials, listCredentialsByPackage, loadIntentRules, upsertIntentRule, getIntentRule, deleteIntentRule, loadDomains, getDomain, upsertDomain, deleteDomain, loadModels, getModel, upsertModel, deleteModel, REGISTRY_PATH } = require('./lib/registry');
const { generateToolsMd } = require('./lib/generator');
const { buildUsageExample, getExampleDefinition, renderRequest, toCurl, runRenderedRequest, redactForDisplay } = require('./lib/usage');

const app = express();
const SESSION_COOKIE = 'tools_session';
const SESSIONS = new Map();

// Optional: allow the tools server to write into OpenClaw auth config (manual, user-initiated)
// Disabled by default for safety.
const OPENCLAW_PUSH_ENABLED = ['1', 'true', 'yes', 'on'].includes(String(process.env.TOOLS_CONFIG_OPENCLAW_PUSH || '').toLowerCase());

function maskSecret(s) {
  const str = (s == null) ? '' : String(s);
  if (!str) return '';
  if (str.length <= 16) return `${str.slice(0, 4)}…${str.slice(-2)}`;
  return `${str.slice(0, 10)}...${str.slice(-6)}`;
}

function getOpenclawStateDir() {
  return process.env.OPENCLAW_STATE_DIR || path.join(os.homedir(), '.openclaw');
}

function getOpenclawAgentId() {
  return process.env.OPENCLAW_AGENT_ID || 'main';
}

function getOpenclawAuthProfilesPath() {
  return process.env.OPENCLAW_AUTH_PROFILES_PATH
    || path.join(getOpenclawStateDir(), 'agents', getOpenclawAgentId(), 'agent', 'auth-profiles.json');
}

function readJsonFile(filePath) {
  return JSON.parse(fs.readFileSync(filePath, 'utf8'));
}

function writeJsonAtomic(filePath, data, { mode } = {}) {
  const dir = path.dirname(filePath);
  const tmp = path.join(dir, `.${path.basename(filePath)}.tmp.${process.pid}.${Date.now()}`);
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2) + '\n', 'utf8');
  if (mode) {
    try { fs.chmodSync(tmp, mode); } catch {}
  }
  fs.renameSync(tmp, filePath);
}

function loadOpenclawAuthProfilesSafe() {
  const authPath = getOpenclawAuthProfilesPath();
  if (!fs.existsSync(authPath)) {
    return { authPath, exists: false, data: { version: 1, profiles: {}, lastGood: {}, usageStats: {} } };
  }
  const st = fs.statSync(authPath);
  const data = readJsonFile(authPath);
  // Normalize minimal shape
  data.version = data.version || 1;
  data.profiles = data.profiles || {};
  data.lastGood = data.lastGood || {};
  data.usageStats = data.usageStats || {};
  return { authPath, exists: true, data, mode: st.mode & 0o777 };
}

function extractApiKeyValue(fields) {
  const flat = flattenFields(fields);
  const candidates = ['apiKey', 'key', 'token', 'accessToken', 'authToken'];
  for (const k of candidates) {
    const v = flat[k];
    if (typeof v === 'string' && v.trim()) return v.trim();
  }
  return null;
}

function getOpenclawModelsStatus() {
  try {
    const raw = execSync('openclaw models status --json', {
      stdio: ['ignore', 'pipe', 'pipe'],
      timeout: 12000,
      shell: '/bin/bash'
    }).toString();
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

function resolveOpenclawProvider(provider, authData) {
  const modelsJsonPath = path.join(process.env.HOME || '/home/alex', '.openclaw/agents/main/agent/models.json');
  let modelsJsonData = {};
  try { modelsJsonData = JSON.parse(fs.readFileSync(modelsJsonPath, 'utf8')); } catch {}

  // Check auth-profiles.json first
  const profileId = `${provider}:default`;
  const profile = (authData?.profiles || {})[profileId] || null;
  const profileKey = (profile && profile.type === 'api_key' && profile.key) ? String(profile.key) : null;

  // Check models.json (used by providers like openrouter that aren't in auth-profiles.json)
  const modelsJsonEntry = modelsJsonData?.providers?.[provider] || null;
  const modelsJsonRawKey = modelsJsonEntry?.apiKey || modelsJsonEntry?.key || null;
  const modelsJsonKey = (modelsJsonRawKey && modelsJsonRawKey !== '-') ? String(modelsJsonRawKey) : null;

  // Check env vars
  const fromEnv = (provider === 'openai' && process.env.OPENAI_API_KEY)
    || (provider === 'anthropic' && process.env.ANTHROPIC_API_KEY)
    || (provider === 'google' && process.env.GOOGLE_API_KEY)
    || (provider === 'moonshot' && process.env.MOONSHOT_API_KEY)
    || null;

  // Determine source priority: profiles > models.json > env > missing
  let source = 'missing';
  let key = null;
  let effectiveKind = null;
  let effectiveDetail = null;

  if (profileKey) {
    source = 'profiles';
    key = profileKey;
    effectiveKind = 'profiles';
  } else if (modelsJsonKey) {
    source = 'models.json';
    key = modelsJsonKey;
    effectiveKind = 'models.json';
    effectiveDetail = modelsJsonPath;
  } else if (fromEnv) {
    source = 'env';
    key = String(fromEnv);
    effectiveKind = 'env';
  }

  return {
    profileId: source === 'models.json' ? `models.json:${provider}` : profileId,
    source,
    key,
    keyPreview: key ? maskSecret(key) : null,
    hasProfile: !!(profile || modelsJsonEntry),
    hasKey: !!key,
    effectiveKind,
    effectiveDetail
  };
}

// OAuth re-auth bridge sessions (dashboard -> interactive CLI)
const OAUTH_SESSIONS = new Map();
const OAUTH_PROFILE_PATH = path.join(process.env.HOME || '/home/alex', '.openclaw/agents/main/agent/auth-profiles.json');

// Obsidian headless login bridge sessions (dashboard -> `ob login`)

function resolveObCmd() {
  const explicit = process.env.OB_CLI_PATH;
  if (explicit && fs.existsSync(explicit)) return explicit;

  try {
    const p = execSync('bash -lc "command -v ob 2>/dev/null || true"', {
      stdio: ['ignore', 'pipe', 'ignore'],
      timeout: 2000
    }).toString().trim().split(/\r?\n/)[0];
    if (p) return p;
  } catch {}

  const home = process.env.HOME || '/home/alex';
  const candidate = path.join(home, '.npm-global', 'bin', 'ob');
  if (fs.existsSync(candidate)) return candidate;

  return null;
}



function readAuthProfiles() {
  try {
    if (!fs.existsSync(OAUTH_PROFILE_PATH)) return null;
    return JSON.parse(fs.readFileSync(OAUTH_PROFILE_PATH, 'utf8'));
  } catch {
    return null;
  }
}

function getProviderAuthState(provider = 'openai-codex', profileName = 'default') {
  const profiles = readAuthProfiles();
  const id = `${provider}:${profileName}`;
  const profile = profiles?.profiles?.[id] || null;
  const expires = profile?.expires || null;
  const now = Date.now();
  const ttlMs = typeof expires === 'number' ? Math.max(0, expires - now) : null;
  return {
    profileId: id,
    exists: !!profile,
    type: profile?.type || null,
    expires,
    ttlMs,
    expiresAt: typeof expires === 'number' ? new Date(expires).toISOString() : null
  };
}

function redactOAuthLog(text) {
  if (!text) return '';
  return text
    .replace(/(access\s*[=:]\s*)([^\s]+)/ig, '$1[REDACTED]')
    .replace(/(refresh\s*[=:]\s*)([^\s]+)/ig, '$1[REDACTED]')
    .replace(/(bearer\s+)([a-z0-9._\-]+)/ig, '$1[REDACTED]');
}

// Parse arguments
function parseArgs() {
  const args = process.argv.slice(2);
  const config = {
    bind: '127.0.0.1:8080',
    password: null,
    temp: null,
    https: false,
    dataDir: path.join(process.env.HOME || '/tmp', '.openclaw/workspace')
  };

  for (let i = 0; i < args.length; i++) {
    switch (args[i]) {
      case '--bind':
        config.bind = args[++i];
        break;
      case '--password':
        config.password = args[++i];
        break;
      case '--temp':
        config.temp = parseInt(args[++i]) || 30;
        break;
      case '--https':
        config.https = true;
        break;
      case '--data-dir':
        config.dataDir = args[++i];
        break;
    }
  }

  if (!config.password) {
    config.password = crypto.randomBytes(16).toString('hex');
    console.log(`Generated password: ${config.password}`);
  }

  return config;
}

const CONFIG = parseArgs();

// Middleware
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'", "'unsafe-inline'"],
      scriptSrcAttr: ["'unsafe-inline'"],
      imgSrc: ["'self'", "data:"],
    }
  }
}));
app.use(express.json());
app.use(cookieParser());

// Prevent browser caching of all API responses
app.use('/api', (req, res, next) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
  res.set('Pragma', 'no-cache');
  res.set('Expires', '0');
  next();
});

// Auth middleware
function requireAuth(req, res, next) {
  const sessionId = req.cookies[SESSION_COOKIE];
  if (sessionId && SESSIONS.has(sessionId)) {
    const session = SESSIONS.get(sessionId);
    if (session.expires > Date.now()) {
      req.session = session;
      return next();
    }
    SESSIONS.delete(sessionId);
  }
  res.status(401).json({ error: 'Unauthorized' });
}

function requireAuthPage(req, res, next) {
  const sessionId = req.cookies[SESSION_COOKIE];
  if (sessionId && SESSIONS.has(sessionId)) {
    const session = SESSIONS.get(sessionId);
    if (session.expires > Date.now()) {
      req.session = session;
      return next();
    }
    SESSIONS.delete(sessionId);
  }
  res.redirect('/login.html');
}

// Routes
app.post('/api/login', async (req, res) => {
  const { password } = req.body;
  const hashed = await bcrypt.hash(CONFIG.password, 10);
  const match = await bcrypt.compare(password, hashed);
  
  if (password === CONFIG.password || match) {
    const sessionId = crypto.randomUUID();
    SESSIONS.set(sessionId, { 
      created: Date.now(),
      expires: Date.now() + (24 * 60 * 60 * 1000) // 24h
    });
    res.cookie(SESSION_COOKIE, sessionId, { httpOnly: true, secure: CONFIG.https, sameSite: 'lax' });
    res.json({ success: true });
  } else {
    res.status(401).json({ error: 'Invalid password' });
  }
});

app.post('/api/logout', (req, res) => {
  const sessionId = req.cookies[SESSION_COOKIE];
  if (sessionId) SESSIONS.delete(sessionId);
  res.clearCookie(SESSION_COOKIE);
  res.json({ success: true });
});

// OAuth re-auth status (OpenAI Codex default)
app.get('/api/oauth/status/:provider?', requireAuth, (req, res) => {
  const provider = req.params.provider || 'openai-codex';
  const sessions = Array.from(OAUTH_SESSIONS.values())
    .filter(s => s.provider === provider)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  const active = sessions.find(s => s.status === 'pending' || s.status === 'exchanging') || null;
  const latest = sessions[0] || null;
  const authState = getProviderAuthState(provider);

  const serialize = (s) => s ? {
    id: s.id,
    status: s.status,
    createdAt: s.createdAt,
    exitCode: s.exitCode,
    authUrl: s.authUrl || null,
    lastOutputAt: s.lastOutputAt || null,
    logTail: redactOAuthLog((s.log || '').slice(-3000))
  } : null;

  res.json({
    provider,
    auth: authState,
    activeSession: serialize(active),
    latestSession: serialize(latest)
  });
});

// Native PKCE OAuth flow for OpenAI Codex (no CLI dependency)
const CODEX_CLIENT_ID = 'app_EMoamEEZ73f0CkXaXp7hrann';
const CODEX_REDIRECT_URI = 'http://localhost:1455/auth/callback';
const CODEX_AUTH_BASE = 'https://auth.openai.com';
const CODEX_SCOPES = 'openid profile email offline_access';

function base64urlEncode(buf) {
  return buf.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
}

function generatePkce() {
  const verifier = base64urlEncode(crypto.randomBytes(32));
  const challenge = base64urlEncode(crypto.createHash('sha256').update(verifier).digest());
  return { verifier, challenge };
}

app.post('/api/oauth/start', requireAuth, (req, res) => {
  const provider = req.body?.provider || 'openai-codex';
  if (provider !== 'openai-codex') {
    return res.status(400).json({ error: 'Only openai-codex is supported' });
  }

  // Reuse if already pending
  const existing = Array.from(OAUTH_SESSIONS.values()).find(s => s.provider === provider && s.status === 'pending');
  if (existing) {
    return res.json({ success: true, reused: true, sessionId: existing.id, provider, authUrl: existing.authUrl });
  }

  const { verifier, challenge } = generatePkce();
  const state = base64urlEncode(crypto.randomBytes(16));
  const sessionId = crypto.randomUUID();

  const params = new URLSearchParams({
    response_type: 'code',
    client_id: CODEX_CLIENT_ID,
    redirect_uri: CODEX_REDIRECT_URI,
    scope: CODEX_SCOPES,
    code_challenge: challenge,
    code_challenge_method: 'S256',
    state,
    id_token_add_organizations: 'true',
    codex_cli_simplified_flow: 'true',
    originator: 'pi'
  });

  const authUrl = `${CODEX_AUTH_BASE}/oauth/authorize?${params.toString()}`;

  OAUTH_SESSIONS.set(sessionId, {
    id: sessionId,
    provider,
    createdAt: new Date().toISOString(),
    status: 'pending',
    authUrl,
    verifier,
    state,
    log: `Auth URL generated. Open it in your browser, sign in, then paste the redirect URL here.\n\nWaiting for callback…`,
    lastOutputAt: new Date().toISOString(),
    exitCode: null,
    before: getProviderAuthState(provider),
    after: null
  });

  res.json({ success: true, sessionId, provider, authUrl });
});

// Complete: user pastes the redirect URL → extract code → exchange → save token
app.post('/api/oauth/complete', requireAuth, async (req, res) => {
  const { sessionId, callbackUrlOrCode } = req.body || {};
  if (!sessionId || !callbackUrlOrCode) {
    return res.status(400).json({ error: 'sessionId and callbackUrlOrCode are required' });
  }

  const state = OAUTH_SESSIONS.get(sessionId);
  if (!state) return res.status(404).json({ error: 'OAuth session not found' });
  if (state.status !== 'pending') {
    return res.status(409).json({ error: `Session not pending (status=${state.status})` });
  }

  // Extract code from pasted URL or raw code
  let code = String(callbackUrlOrCode).trim();
  try {
    const u = new URL(code);
    code = u.searchParams.get('code') || code;
    // Optionally validate state param
    const returnedState = u.searchParams.get('state');
    if (returnedState && returnedState !== state.state) {
      state.status = 'failed';
      state.log += '\nState mismatch — possible CSRF. Please start a new session.';
      return res.status(400).json({ error: 'State mismatch' });
    }
  } catch {}

  state.status = 'exchanging';
  state.log += '\nExchanging code for token…';

  try {
    const body = new URLSearchParams({
      grant_type: 'authorization_code',
      code,
      code_verifier: state.verifier,
      redirect_uri: CODEX_REDIRECT_URI,
      client_id: CODEX_CLIENT_ID
    });

    const resp = await fetch(`${CODEX_AUTH_BASE}/oauth/token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: body.toString()
    });

    const data = await resp.json();

    if (!resp.ok || !data.access_token) {
      state.status = 'failed';
      state.log += `\nToken exchange failed: ${JSON.stringify(data)}`;
      return res.status(400).json({ error: data.error_description || data.error || 'Token exchange failed', detail: data });
    }

    // Decode access token to get accountId + authoritative exp from JWT
    let accountId = null;
    let jwtExp = null;
    let jwtIat = null;
    try {
      const payload = JSON.parse(Buffer.from(data.access_token.split('.')[1] + '==', 'base64').toString());
      accountId = payload?.['https://api.openai.com/auth']?.chatgpt_account_id || null;
      jwtExp = typeof payload?.exp === 'number' ? payload.exp : null;
      jwtIat = typeof payload?.iat === 'number' ? payload.iat : null;
    } catch {}

    // Prefer JWT exp (authoritative) over expires_in (can drift); fallback to expires_in
    const expiresMs = jwtExp ? (jwtExp * 1000) : Date.now() + ((data.expires_in || 900) * 1000);
    const newIat = jwtIat || Math.floor(Date.now() / 1000);

    // Stale-write guard: never overwrite a newer token with an older one
    const profiles = readAuthProfiles() || { version: 1, profiles: {}, lastGood: {}, usageStats: {} };
    const existing = profiles.profiles?.['openai-codex:default'];
    if (existing?.expires && existing.expires > expiresMs) {
      state.status = 'completed';
      state.after = getProviderAuthState('openai-codex');
      state.log += `\n⚠️ Stale token rejected — existing token expires later (${new Date(existing.expires).toISOString()} > ${new Date(expiresMs).toISOString()})`;
      return res.json({ success: true, skipped: true, reason: 'stale', expiresAt: state.after.expiresAt, ttlMs: state.after.ttlMs });
    }

    // Step 1: Notify OpenClaw runtime via paste-token FIRST so it adopts
    // the new access token + expires in memory. paste-token also rewrites
    // auth-profiles.json, but it does NOT know the refresh token.
    const expiresInSeconds = Math.max(1, Math.floor((expiresMs - Date.now()) / 1000));
    const { spawn } = require('child_process');
    const pasteExitCode = await new Promise((resolve) => {
      const pasteProc = spawn('openclaw', [
        'models', 'auth', 'paste-token',
        '--provider', 'openai-codex',
        '--profile-id', 'openai-codex:default',
        '--expires-in', `${expiresInSeconds}s`
      ], { stdio: ['pipe', 'pipe', 'pipe'] });
      pasteProc.stdin.write(data.access_token);
      pasteProc.stdin.end();
      pasteProc.on('close', resolve);
      pasteProc.on('error', () => resolve(1));
      // Safety timeout: don't hang forever
      setTimeout(() => { try { pasteProc.kill(); } catch {} resolve(99); }, 15000);
    });

    state.log += pasteExitCode === 0
      ? '\n✅ Runtime notified via paste-token'
      : `\n⚠️ paste-token exited ${pasteExitCode}`;

    // Step 2: Re-read the file (paste-token may have rewritten it) and
    // overlay our FULL profile including the refresh token.
    // This ensures the refresh token is never lost by paste-token's write.
    const freshProfiles = readAuthProfiles();
    freshProfiles.profiles = freshProfiles.profiles || {};
    freshProfiles.profiles['openai-codex:default'] = {
      ...(freshProfiles.profiles['openai-codex:default'] || {}),
      type: 'oauth',
      provider: 'openai-codex',
      access: data.access_token,
      refresh: data.refresh_token,
      expires: expiresMs,
      accountId
    };
    freshProfiles.lastGood = freshProfiles.lastGood || {};
    freshProfiles.lastGood['openai-codex'] = 'openai-codex:default';
    const tmpPath = OAUTH_PROFILE_PATH + '.tmp';
    fs.writeFileSync(tmpPath, JSON.stringify(freshProfiles, null, 2));
    fs.renameSync(tmpPath, OAUTH_PROFILE_PATH);

    state.status = 'completed';
    state.after = getProviderAuthState('openai-codex');
    state.log += `\n✅ Token saved (full profile with refresh). Expires: ${state.after.expiresAt}`;

    // Trigger background health cache refresh so dashboard reflects new token immediately
    runHealthCheckLive().then(writeHealthCache).catch(() => {});

    res.json({ success: true, expiresAt: state.after.expiresAt, ttlMs: state.after.ttlMs });
  } catch (err) {
    state.status = 'failed';
    state.log += `\nError: ${err.message}`;
    res.status(500).json({ error: err.message });
  }
});

// ─── Google Workspace OAuth Flow (multi-account) ───────────────────────────
const GWS_DIR = path.join(process.env.HOME || '/home/alex', '.config/gws');
const GWS_CLIENT_SECRET_PATH = path.join(GWS_DIR, 'client_secret.json');
const GWS_SCOPES = [
  'https://www.googleapis.com/auth/gmail.modify',
  'https://www.googleapis.com/auth/gmail.settings.basic',
  'https://www.googleapis.com/auth/calendar',
  'https://www.googleapis.com/auth/drive',
  'https://www.googleapis.com/auth/documents',
  'https://www.googleapis.com/auth/spreadsheets',
  'https://www.googleapis.com/auth/contacts',
  'https://www.googleapis.com/auth/contacts.other.readonly',
  'https://www.googleapis.com/auth/userinfo.email',
  'openid'
].join(' ');

// email → filesystem-safe key: "alexey@streamliner.one" → "alexey_streamliner_one"
function emailToKey(email) {
  return email.toLowerCase().replace(/[@.]/g, '_').replace(/[^a-z0-9_]/g, '');
}

// key → credentials file path
function gwsCredsPath(emailKey) {
  return path.join(GWS_DIR, `credentials-${emailKey}.json`);
}

// Scan ~/.config/gws/ for all credentials-*.json files, return array of accounts
function listGwsAccounts() {
  try {
    fs.mkdirSync(GWS_DIR, { recursive: true });
    const files = fs.readdirSync(GWS_DIR).filter(f => f.startsWith('credentials-') && f.endsWith('.json'));
    return files.map(f => {
      try {
        const creds = JSON.parse(fs.readFileSync(path.join(GWS_DIR, f), 'utf8'));
        return {
          file: f,
          account: creds.account || f.replace('credentials-', '').replace('.json', ''),
          hasRefreshToken: !!creds.refresh_token
        };
      } catch { return null; }
    }).filter(Boolean);
  } catch { return []; }
}

function readGwsClientSecret() {
  try {
    const raw = fs.readFileSync(GWS_CLIENT_SECRET_PATH, 'utf8');
    const parsed = JSON.parse(raw);
    return parsed.installed || parsed.web || null;
  } catch { return null; }
}

function getGwsRedirectUri(req) {
  const host = req.headers['x-forwarded-host'] || req.headers.host || 'localhost:8443';
  const proto = req.headers['x-forwarded-proto'] || 'https';
  return `${proto}://${host}/api/oauth/google/callback`;
}

// GET /api/oauth/google/status — list all connected accounts
app.get('/api/oauth/google/status', requireAuth, (req, res) => {
  const accounts = listGwsAccounts();
  res.json({
    accounts,
    hasClientSecret: !!readGwsClientSecret()
  });
});

// DELETE /api/oauth/google/account/:emailKey — remove a connected account
app.delete('/api/oauth/google/account/:emailKey', requireAuth, (req, res) => {
  const { emailKey } = req.params;
  // Sanitize: only allow safe key chars
  if (!/^[a-z0-9_]+$/.test(emailKey)) {
    return res.status(400).json({ error: 'Invalid account key' });
  }
  const filePath = gwsCredsPath(emailKey);
  if (!fs.existsSync(filePath)) {
    return res.status(404).json({ error: 'Account not found' });
  }
  fs.unlinkSync(filePath);
  res.json({ success: true, removed: emailKey });
});

// POST /api/oauth/google/start — kick off OAuth for a new account (paste-back flow)
app.post('/api/oauth/google/start', requireAuth, (req, res) => {
  const clientSecret = readGwsClientSecret();
  if (!clientSecret) {
    return res.status(400).json({ error: 'client_secret.json not found at ' + GWS_CLIENT_SECRET_PATH });
  }

  // Use http://localhost — the only redirect URI registered in gws's client_secret.json
  // User pastes back the full redirect URL (or just the code) — no local server needed
  const redirectUri = 'http://localhost';
  const state = base64urlEncode(crypto.randomBytes(16));
  const sessionId = crypto.randomUUID();

  OAUTH_SESSIONS.set(sessionId, {
    id: sessionId,
    provider: 'google-workspace',
    state,
    redirectUri,
    createdAt: new Date().toISOString(),
    status: 'pending'
  });

  const params = new URLSearchParams({
    response_type: 'code',
    client_id: clientSecret.client_id,
    redirect_uri: redirectUri,
    scope: GWS_SCOPES,
    access_type: 'offline',
    prompt: 'consent',
    state
  });

  const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`;
  res.json({ success: true, sessionId, authUrl, redirectUri });
});

// POST /api/oauth/google/complete — user pastes redirect URL → exchange code → save credentials
app.post('/api/oauth/google/complete', requireAuth, async (req, res) => {
  const { sessionId, callbackUrlOrCode } = req.body || {};
  if (!sessionId || !callbackUrlOrCode) {
    return res.status(400).json({ error: 'sessionId and callbackUrlOrCode required' });
  }

  const session = OAUTH_SESSIONS.get(sessionId);
  if (!session || session.provider !== 'google-workspace') {
    return res.status(404).json({ error: 'Session not found' });
  }
  if (session.status !== 'pending') {
    return res.status(409).json({ error: `Session not pending (status=${session.status})` });
  }

  // Extract code from pasted URL or raw code
  let code = String(callbackUrlOrCode).trim();
  try {
    const u = new URL(code);
    const returnedState = u.searchParams.get('state');
    if (returnedState && returnedState !== session.state) {
      session.status = 'failed';
      return res.status(400).json({ error: 'State mismatch — possible CSRF. Please start again.' });
    }
    code = u.searchParams.get('code') || code;
  } catch {}

  session.status = 'exchanging';

  const clientSecret = readGwsClientSecret();
  if (!clientSecret) {
    session.status = 'failed';
    return res.status(500).json({ error: 'Missing client_secret.json' });
  }

  try {
    // Exchange code for tokens
    const tokenResp = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        code,
        client_id: clientSecret.client_id,
        client_secret: clientSecret.client_secret,
        redirect_uri: session.redirectUri,
        grant_type: 'authorization_code'
      }).toString()
    });

    const tokenData = await tokenResp.json();
    if (!tokenResp.ok || !tokenData.refresh_token) {
      session.status = 'failed';
      return res.status(400).json({ error: tokenData.error_description || tokenData.error || 'Token exchange failed' });
    }

    // Get email from Google
    let account = null;
    try {
      const userResp = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
        headers: { Authorization: `Bearer ${tokenData.access_token}` }
      });
      const userInfo = await userResp.json();
      account = userInfo.email || null;
    } catch {}

    if (!account) {
      session.status = 'failed';
      return res.status(400).json({ error: 'Could not retrieve email from Google' });
    }

    // Save per-account credentials file
    const emailKey = emailToKey(account);
    const credsFile = gwsCredsPath(emailKey);
    fs.mkdirSync(GWS_DIR, { recursive: true });
    const credsData = {
      type: 'authorized_user',
      client_id: clientSecret.client_id,
      client_secret: clientSecret.client_secret,
      refresh_token: tokenData.refresh_token,
      token_type: 'Bearer',
      account
    };
    fs.writeFileSync(credsFile, JSON.stringify(credsData, null, 2));
    // Update default credentials.json to latest connected account
    fs.writeFileSync(path.join(GWS_DIR, 'credentials.json'), JSON.stringify(credsData, null, 2));

    session.status = 'completed';
    OAUTH_SESSIONS.delete(sessionId);
    runHealthCheckLive().then(writeHealthCache).catch(() => {});

    res.json({ success: true, account });

  } catch (err) {
    session.status = 'failed';
    res.status(500).json({ error: err.message });
  }
});

// GET /api/oauth/google/callback — Google redirects here after auth
app.get('/api/oauth/google/callback', async (req, res) => {
  const { code, state, error } = req.query;

  if (error) {
    return res.status(400).send(`<html><body style="font-family:sans-serif;max-width:500px;margin:80px auto;text-align:center"><h2>❌ Google OAuth Error</h2><p>${error}</p></body></html>`);
  }

  const sessionKey = 'google:' + state;
  const session = OAUTH_SESSIONS.get(sessionKey);
  if (!session || session.state !== state) {
    return res.status(400).send('<html><body style="font-family:sans-serif;max-width:500px;margin:80px auto;text-align:center"><h2>Invalid state</h2><p>OAuth state mismatch. Please try again from the dashboard.</p></body></html>');
  }

  const clientSecret = readGwsClientSecret();
  if (!clientSecret) {
    return res.status(500).send('<html><body><h2>Missing client_secret.json</h2></body></html>');
  }

  try {
    // Step 1: Exchange code for tokens
    const tokenResp = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        code,
        client_id: clientSecret.client_id,
        client_secret: clientSecret.client_secret,
        redirect_uri: session.redirectUri,
        grant_type: 'authorization_code'
      }).toString()
    });

    const tokenData = await tokenResp.json();
    if (!tokenResp.ok || !tokenData.refresh_token) {
      OAUTH_SESSIONS.delete(sessionKey);
      return res.status(400).send(`<html><body style="font-family:sans-serif;max-width:500px;margin:80px auto"><h2>Token exchange failed</h2><pre>${JSON.stringify(tokenData, null, 2)}</pre></body></html>`);
    }

    // Step 2: Get user email from Google
    let account = null;
    try {
      const userResp = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
        headers: { Authorization: `Bearer ${tokenData.access_token}` }
      });
      const userInfo = await userResp.json();
      account = userInfo.email || null;
    } catch {}

    if (!account) {
      OAUTH_SESSIONS.delete(sessionKey);
      return res.status(400).send('<html><body><h2>Could not retrieve account email from Google</h2></body></html>');
    }

    // Step 3: Save to per-account credentials file
    const emailKey = emailToKey(account);
    const credsFile = gwsCredsPath(emailKey);
    fs.mkdirSync(GWS_DIR, { recursive: true });
    fs.writeFileSync(credsFile, JSON.stringify({
      type: 'authorized_user',
      client_id: clientSecret.client_id,
      client_secret: clientSecret.client_secret,
      refresh_token: tokenData.refresh_token,
      token_type: 'Bearer',
      account
    }, null, 2));

    // Also write/update the default credentials.json to the first/latest account
    // so `gws` works without --account flag for the most recently connected account
    fs.writeFileSync(path.join(GWS_DIR, 'credentials.json'), JSON.stringify({
      type: 'authorized_user',
      client_id: clientSecret.client_id,
      client_secret: clientSecret.client_secret,
      refresh_token: tokenData.refresh_token,
      token_type: 'Bearer',
      account
    }, null, 2));

    OAUTH_SESSIONS.delete(sessionKey);
    runHealthCheckLive().then(writeHealthCache).catch(() => {});

    res.send(`
      <html><body style="font-family:sans-serif;max-width:500px;margin:80px auto;text-align:center;color:#e6edf3;background:#0d1117;padding:2rem;border-radius:12px">
        <div style="font-size:3rem">✅</div>
        <h2 style="margin:1rem 0 0.5rem">Google Workspace connected</h2>
        <p style="color:#8b949e;margin:0.5rem 0 1.5rem">${account}</p>
        <p style="color:#8b949e;font-size:0.85rem">Credentials saved. You can close this tab.</p>
        <script>setTimeout(() => window.close(), 3000)</script>
      </body></html>
    `);

  } catch (err) {
    OAUTH_SESSIONS.delete(sessionKey);
    res.status(500).send(`<html><body><h2>Error</h2><p>${err.message}</p></body></html>`);
  }
});
// ────────────────────────────────────────────────────────────────────────────

// Protected API routes
app.get('/api/services', requireAuth, (req, res) => {
  const registry = loadRegistry();
  const services = [];
  
  for (const [id, schema] of Object.entries(SERVICE_SCHEMAS)) {
    const configured = registry.services[id] || { enabled: false, fields: {} };
    services.push({
      id,
      ...schema,
      primaryCategory: schema.category || 'other',
      labels: Array.isArray(schema.labels) && schema.labels.length ? schema.labels : [schema.category || 'other'],
      enabled: configured.enabled || false,
      configuredFields: Object.keys(configured.fields || {})
    });
  }
  
  res.json({ services });
});

app.get('/api/services/:id', requireAuth, (req, res) => {
  const { id } = req.params;
  const schema = SERVICE_SCHEMAS[id];
  if (!schema) return res.status(404).json({ error: 'Service not found' });
  
  const service = getService(id);
  res.json({
    schema,
    config: service
  });
});

app.post('/api/services/:id', requireAuth, (req, res) => {
  const { id } = req.params;
  const { enabled, fields } = req.body;
  
  const schema = SERVICE_SCHEMAS[id];
  if (!schema) return res.status(404).json({ error: 'Service not found' });
  
  const update = {};
  if (typeof enabled === 'boolean') update.enabled = enabled;
  if (fields) update.fields = fields;
  
  const result = updateService(id, update);
  generateToolsMd();
  
  res.json({ success: true, service: result });
});

app.post('/api/services/:id/toggle', requireAuth, (req, res) => {
  const { id } = req.params;
  const { enabled } = req.body;
  
  const result = toggleService(id, enabled);
  generateToolsMd();
  
  res.json({ success: true, service: result });
});

// Live validation with test buttons
const VALIDATORS = {
  mel: async (fields) => {
    const hasSettings = [
      fields.rateLimitNotify?.value,
      fields.rateLimitPauseSeconds?.value,
      fields.rateLimitMaxRetries?.value,
      fields.rateLimitBackoffMultiplier?.value
    ].some(v => v !== undefined && v !== null && String(v).trim() !== '');

    return {
      valid: true,
      message: hasSettings ? 'Agent behavior config loaded' : 'Agent behavior defaults active'
    };
  },

  notion: async (fields) => {
    const apiKey = fields.apiKey?.value;
    if (!apiKey) return { valid: false, message: 'API Key required' };
    
    try {
      const https = require('https');
      const response = await new Promise((resolve, reject) => {
        const req = https.request('https://api.notion.com/v1/users/me', {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${apiKey}`,
            'Notion-Version': '2022-06-28'
          }
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode, data }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.end();
      });
      
      if (response.status === 200) {
        const json = JSON.parse(response.data);
        return { valid: true, message: `Connected as ${json.name || json.bot?.owner?.user?.name || 'Notion workspace'}` };
      } else if (response.status === 401) {
        return { valid: false, message: 'Invalid API key (401)' };
      } else {
        return { valid: false, message: `HTTP ${response.status}` };
      }
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },
  
  todoist: async (fields) => {
    const token = fields.apiToken?.value;
    if (!token) return { valid: false, message: 'API Token required' };
    
    try {
      const https = require('https');
      const response = await new Promise((resolve, reject) => {
        const req = https.request('https://api.todoist.com/api/v1/projects', {
          method: 'GET',
          headers: { 'Authorization': `Bearer ${token}` }
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.end();
      });
      
      if (response.status === 200) {
        return { valid: true, message: 'Connected to Todoist' };
      } else if (response.status === 401) {
        return { valid: false, message: 'Invalid token (401)' };
      } else {
        return { valid: false, message: `HTTP ${response.status}` };
      }
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },
  
  telegram: async (fields) => {
    const token = fields.botToken?.value;
    if (!token) return { valid: false, message: 'Bot Token required' };
    
    try {
      const https = require('https');
      const response = await new Promise((resolve, reject) => {
        const req = https.request(`https://api.telegram.org/bot${token}/getMe`, {
          method: 'GET'
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode, data }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.end();
      });
      
      if (response.status === 200) {
        const json = JSON.parse(response.data);
        if (json.ok) {
          return { valid: true, message: `@${json.result.username} (${json.result.first_name})` };
        }
        return { valid: false, message: json.description || 'Invalid token' };
      } else if (response.status === 401) {
        return { valid: false, message: 'Invalid bot token (401)' };
      } else {
        return { valid: false, message: `HTTP ${response.status}` };
      }
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },
  
  openai: async (fields) => {
    const apiKey = fields.apiKey?.value;
    if (!apiKey) return { valid: false, message: 'API Key required' };
    
    try {
      const https = require('https');
      const response = await new Promise((resolve, reject) => {
        const req = https.request('https://api.openai.com/v1/models', {
          method: 'GET',
          headers: { 'Authorization': `Bearer ${apiKey}` }
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode, data }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.end();
      });
      
      if (response.status === 200) {
        const json = JSON.parse(response.data);
        return { valid: true, message: `${json.data?.length || 0} models available` };
      } else if (response.status === 401) {
        return { valid: false, message: 'Invalid API key (401)' };
      } else if (response.status === 429) {
        return { valid: true, warning: true, message: 'Rate limited (429) - key valid but over quota' };
      } else {
        return { valid: false, message: `HTTP ${response.status}` };
      }
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },
  
  anthropic: async (fields) => {
    const apiKey = fields.apiKey?.value;
    if (!apiKey) return { valid: false, message: 'API Key required' };
    
    try {
      const https = require('https');
      const response = await new Promise((resolve, reject) => {
        const req = https.request('https://api.anthropic.com/v1/models', {
          method: 'GET',
          headers: { 
            'x-api-key': apiKey,
            'anthropic-version': '2023-06-01'
          }
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode, data }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.end();
      });
      
      if (response.status === 200) {
        return { valid: true, message: 'Connected to Anthropic' };
      } else if (response.status === 401) {
        return { valid: false, message: 'Invalid API key (401)' };
      } else {
        return { valid: false, message: `HTTP ${response.status}` };
      }
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },
  
  moonshot: async (fields) => {
    const apiKey = fields.apiKey?.value;
    if (!apiKey) return { valid: false, message: 'API Key required' };
    
    try {
      const https = require('https');
      const response = await new Promise((resolve, reject) => {
        const req = https.request('https://api.moonshot.ai/v1/models', {
          method: 'GET',
          headers: { 'Authorization': `Bearer ${apiKey}` }
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.end();
      });
      
      if (response.status === 200) {
        return { valid: true, message: 'Connected to Moonshot' };
      } else if (response.status === 401) {
        return { valid: false, message: 'Invalid API key (401)' };
      } else {
        return { valid: false, message: `HTTP ${response.status}` };
      }
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },

  mem0: async (fields) => {
    const apiKey = fields.apiKey?.value;
    if (!apiKey) return { valid: false, message: 'API Key required' };

    try {
      const https = require('https');
      const userId = String(fields.userId?.value || '').trim();
      const probeUrl = userId
        ? `https://api.mem0.ai/v1/memories/?user_id=${encodeURIComponent(userId)}&limit=1`
        : 'https://api.mem0.ai/v1/memories/';

      const response = await new Promise((resolve, reject) => {
        const req = https.request(probeUrl, {
          method: 'GET',
          headers: {
            'Authorization': `Token ${apiKey}`,
            'Accept': 'application/json'
          }
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode, data }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.end();
      });

      if (response.status === 200) {
        return { valid: true, message: 'Connected to Mem0 API' };
      }
      if (response.status === 401 || response.status === 403) {
        return { valid: false, message: `Invalid API key (${response.status})` };
      }

      // Mem0 may require query context (e.g., user_id) on memories reads.
      // A 400 here still confirms auth was accepted.
      if (response.status === 400) {
        let detail = '';
        try {
          const parsed = JSON.parse(response.data || '{}');
          detail = parsed?.detail || parsed?.message || '';
        } catch {}
        return {
          valid: true,
          warning: true,
          message: detail
            ? `Mem0 key valid; API requires request context (${detail})`
            : 'Mem0 key valid; API requires request context (e.g., user_id)'
        };
      }

      return { valid: false, message: `HTTP ${response.status}` };
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },
  
  elevenlabs: async (fields) => {
    const apiKey = fields.apiKey?.value;
    if (!apiKey) return { valid: false, message: 'API Key required' };
    
    try {
      const https = require('https');
      const response = await new Promise((resolve, reject) => {
        const req = https.request('https://api.elevenlabs.io/v1/voices', {
          method: 'GET',
          headers: { 'xi-api-key': apiKey }
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode, data }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.end();
      });
      
      if (response.status === 200) {
        const json = JSON.parse(response.data);
        const voiceCount = json.voices?.length || 0;
        return { valid: true, message: `${voiceCount} voices available` };
      } else if (response.status === 401) {
        return { valid: false, message: 'Invalid API key (401)' };
      } else {
        return { valid: false, message: `HTTP ${response.status}` };
      }
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },
  
  perplexity: async (fields) => {
    const apiKey = fields.apiKey?.value;
    if (!apiKey) return { valid: false, message: 'API Key required' };
    
    try {
      const https = require('https');
      const response = await new Promise((resolve, reject) => {
        const req = https.request('https://api.perplexity.ai/chat/completions', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${apiKey}`,
            'Content-Type': 'application/json'
          }
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode, data }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.write(JSON.stringify({
          model: 'sonar',
          messages: [{ role: 'user', content: 'Hello' }],
          max_tokens: 1
        }));
        req.end();
      });
      
      // 400 with empty message is OK (API is working, just needs valid prompt)
      if (response.status === 200 || response.status === 400) {
        return { valid: true, message: 'Connected to Perplexity' };
      } else if (response.status === 401) {
        return { valid: false, message: 'Invalid API key (401)' };
      } else {
        return { valid: false, message: `HTTP ${response.status}` };
      }
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },
  
  goplaces: async (fields) => {
    const apiKey = fields.apiKey?.value;
    if (!apiKey) return { valid: false, message: 'API Key required' };
    
    return { valid: null, message: 'Google Places validation requires POST request - configure and test via skill' };
  },
  
  newsapi: async (fields) => {
    const apiKey = fields.apiKey?.value;
    if (!apiKey) return { valid: false, message: 'API Key required' };
    
    try {
      const https = require('https');
      const response = await new Promise((resolve, reject) => {
        const req = https.request(`https://newsapi.org/v2/top-headlines?country=us&pageSize=1&apiKey=${apiKey}`, {
          method: 'GET',
          headers: {
            'User-Agent': 'OpenClawTools/1.0'
          }
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode, data }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.end();
      });
      
      if (response.status === 200) {
        return { valid: true, message: 'Connected to NewsAPI' };
      } else if (response.status === 401) {
        return { valid: false, message: 'Invalid API key (401)' };
      } else {
        const json = JSON.parse(response.data);
        return { valid: false, message: json.message || `HTTP ${response.status}` };
      }
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },
  
  duffel: async (fields) => {
    const apiKey = fields.apiKey?.value;
    if (!apiKey) return { valid: false, message: 'API Key required' };
    
    try {
      const https = require('https');
      const response = await new Promise((resolve, reject) => {
        const req = https.request('https://api.duffel.com/air/offer_requests', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${apiKey}`,
            'Duffel-Version': 'v2',
            'Content-Type': 'application/json'
          }
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.write(JSON.stringify({
          data: {
            slices: [],
            passengers: []
          }
        }));
        req.end();
      });
      
      // 422 is expected with empty slices (API is working)
      if (response.status === 422 || response.status === 200) {
        return { valid: true, message: 'Connected to Duffel (sandbox)' };
      } else if (response.status === 401) {
        return { valid: false, message: 'Invalid API key (401)' };
      } else {
        return { valid: false, message: `HTTP ${response.status}` };
      }
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },
  
  weather: async (fields) => {
    const provider = fields.provider?.value || 'open-meteo';
    if (provider === 'open-meteo') {
      return { valid: true, message: 'Open-Meteo requires no API key' };
    }
    return { valid: null, message: 'OpenWeatherMap validation not implemented' };
  },
  
  n8n: async (fields) => {
    const hostUrl = fields.hostUrl?.value;
    const apiKey = fields.apiKey?.value;
    
    if (!hostUrl) return { valid: false, message: 'Host URL required' };
    
    try {
      const https = require('https');
      const url = new URL(hostUrl);
      const response = await new Promise((resolve, reject) => {
        const req = https.request(`${hostUrl}/api/v1/workflows`, {
          method: 'GET',
          headers: apiKey ? { 'X-N8N-API-KEY': apiKey } : {}
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.end();
      });
      
      if (response.status === 200) {
        return { valid: true, message: 'Connected to n8n' };
      } else if (response.status === 401) {
        return { valid: false, message: 'Invalid API key (401)' };
      } else {
        return { valid: false, message: `HTTP ${response.status}` };
      }
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },
  
  '17track': async (fields) => {
    const apiKey = fields.apiKey?.value;
    if (!apiKey) return { valid: false, message: 'API Key required' };
    
    try {
      const https = require('https');
      const response = await new Promise((resolve, reject) => {
        const req = https.request('https://api.17track.net/track/v2.2/gettrackinfo', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            '17token': apiKey
          }
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode, data }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.write(JSON.stringify([{ number: 'TEST123456' }]));
        req.end();
      });
      
      // 401 = invalid key, 400/404 = key valid but tracking number not found
      if (response.status === 401) {
        return { valid: false, message: 'Invalid API key (401)' };
      }
      return { valid: true, message: 'Connected to 17TRACK' };
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },
  
  osrm: async (fields) => {
    try {
      const http = require('http');
      const baseUrl = fields.baseUrl?.value || 'http://router.project-osrm.org';
      const url = `${baseUrl}/route/v1/driving/7.4246,43.7384;7.4346,43.7484?overview=false`;
      const response = await new Promise((resolve, reject) => {
        http.get(url, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode, data }));
        }).on('error', reject);
      });
      if (response.status === 200) {
        const parsed = JSON.parse(response.data);
        if (parsed.code === 'Ok' && parsed.routes?.length > 0) {
          return { valid: true, message: 'OSRM reachable ✓' };
        }
        return { valid: false, message: `Unexpected response: ${parsed.code}` };
      }
      return { valid: false, message: `HTTP ${response.status}` };
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },

  aviationstack: async (fields) => {
    const apiKey = fields.apiKey?.value;
    if (!apiKey) return { valid: false, message: 'API Key required' };
    
    try {
      const https = require('https');
      const response = await new Promise((resolve, reject) => {
        const req = https.request(`https://api.aviationstack.com/v1/flights?access_key=${apiKey}&limit=1`, {
          method: 'GET'
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode, data }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.end();
      });
      
      if (response.status === 200) {
        const json = JSON.parse(response.data);
        if (json.error?.code === 'invalid_access_key') {
          return { valid: false, message: 'Invalid API key' };
        }
        return { valid: true, message: 'Connected to Aviationstack' };
      } else {
        return { valid: false, message: `HTTP ${response.status}` };
      }
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },
  
  amadeus: async (fields) => {
    const clientId = fields.clientId?.value;
    const clientSecret = fields.clientSecret?.value;
    const environment = fields.environment?.value || 'production';
    
    if (!clientId || !clientSecret) {
      return { valid: false, message: 'Client ID and Secret required' };
    }
    
    try {
      const https = require('https');
      const baseUrl = environment === 'production' ? 'api.amadeus.com' : 'api.amadeus.com'; // Same for OAuth endpoint
      
      const response = await new Promise((resolve, reject) => {
        const req = https.request(`https://${baseUrl}/v1/security/oauth2/token`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
          }
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode, data }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.write(`grant_type=client_credentials&client_id=${clientId}&client_secret=${clientSecret}`);
        req.end();
      });
      
      if (response.status === 200) {
        return { valid: true, message: `Connected to Amadeus (${environment})` };
      } else if (response.status === 401) {
        return { valid: false, message: 'Invalid credentials (401)' };
      } else {
        return { valid: false, message: `HTTP ${response.status}` };
      }
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },
  
  goplaces: async (fields) => {
    const apiKey = fields.apiKey?.value;
    if (!apiKey) return { valid: false, message: 'API Key required' };
    
    try {
      const https = require('https');
      const response = await new Promise((resolve, reject) => {
        const req = https.request('https://places.googleapis.com/v1/places:searchText', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-Goog-Api-Key': apiKey,
            'X-Goog-FieldMask': 'places.displayName'
          }
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode, data }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.write(JSON.stringify({ textQuery: 'test', maxResultCount: 1 }));
        req.end();
      });
      
      // 400 = valid key but bad request, 401/403 = invalid key
      if (response.status === 400) {
        return { valid: true, message: 'Connected to Google Places (New)' };
      } else if (response.status === 401 || response.status === 403) {
        return { valid: false, message: 'Invalid API key' };
      }
      return { valid: true, message: 'Connected to Google Places' };
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },
  
  openexchangerates: async (fields) => {
    const apiKey = fields.apiKey?.value;
    if (!apiKey) return { valid: false, message: 'API Key required' };
    
    try {
      const https = require('https');
      const response = await new Promise((resolve, reject) => {
        const req = https.request(`https://openexchangerates.org/api/latest.json?app_id=${apiKey}`, {
          method: 'GET'
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode, data }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.end();
      });
      
      if (response.status === 200) {
        return { valid: true, message: 'Connected to Open Exchange Rates' };
      } else if (response.status === 401) {
        const json = JSON.parse(response.data);
        return { valid: false, message: json.message || 'Invalid API key (401)' };
      } else {
        return { valid: false, message: `HTTP ${response.status}` };
      }
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },
  
  oura: async (fields) => {
    const clientId = fields.clientId?.value;
    const clientSecret = fields.clientSecret?.value;
    
    if (!clientId || !clientSecret) {
      return { valid: false, message: 'Client ID and Secret required' };
    }
    
    // Oura OAuth2 is managed by n8n. Validate via n8n webhook health-check workflow.
    try {
      const https = require('https');
      const response = await new Promise((resolve, reject) => {
        const req = https.request('https://n8n.streamliner.one/webhook/oura-health-check', {
          method: 'GET',
          headers: { 'Accept': 'application/json' }
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode, data }));
        });
        req.on('error', reject);
        req.setTimeout(15000, () => reject(new Error('Timeout')));
        req.end();
      });

      if (response.status === 200) {
        try {
          const json = JSON.parse(response.data);
          if (json.valid === true) {
            return { valid: true, message: json.message || 'Connected to Oura via n8n' };
          }
          return { valid: false, message: json.message || 'Oura validation failed' };
        } catch {
          return { valid: true, message: 'Oura n8n webhook responded OK' };
        }
      }
      // Webhook not registered yet — fall back to config-present check
      return { valid: true, message: 'Oura OAuth2 configured (n8n). Credentials stored.' };
    } catch (err) {
      // n8n unreachable — fall back gracefully
      return { valid: true, message: 'Oura OAuth2 configured (n8n). Webhook check unavailable.' };
    }
  },
  
  brave: async (fields) => {
    const apiKey = fields.apiKey?.value;
    if (!apiKey) return { valid: false, message: 'API Key required' };
    
    try {
      const https = require('https');
      const response = await new Promise((resolve, reject) => {
        const req = https.request('https://api.search.brave.com/res/v1/web/search?q=test&count=1', {
          method: 'GET',
          headers: {
            'Accept': 'application/json',
            'X-Subscription-Token': apiKey
          }
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode, data }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.end();
      });
      
      if (response.status === 200) {
        return { valid: true, message: 'Connected to Brave Search' };
      } else if (response.status === 401 || response.status === 403) {
        return { valid: false, message: 'Invalid API key' };
      } else {
        return { valid: false, message: `HTTP ${response.status}` };
      }
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },
  
  tavily: async (fields) => {
    const apiKey = fields.apiKey?.value;
    if (!apiKey) return { valid: false, message: 'API Key required' };

    try {
      const https = require('https');
      const body = JSON.stringify({ api_key: apiKey, query: 'test', max_results: 1 });
      const response = await new Promise((resolve, reject) => {
        const req = https.request('https://api.tavily.com/search', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) }
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode, data }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.write(body);
        req.end();
      });

      if (response.status === 200) {
        return { valid: true, message: 'Connected to Tavily ✓' };
      } else if (response.status === 401) {
        return { valid: false, message: 'Invalid API key (401)' };
      } else if (response.status === 429) {
        return { valid: true, message: 'Key valid but rate-limited (429)' };
      } else {
        return { valid: false, message: `HTTP ${response.status}` };
      }
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },

  'google-workspace': async (fields) => {
    const oauthClientJson = fields.oauthClientJson?.value;
    if (!oauthClientJson) {
      return { valid: false, message: 'OAuth Client JSON path required' };
    }
    
    const fs = require('fs');
    if (!fs.existsSync(oauthClientJson)) {
      return { valid: false, message: `OAuth JSON file not found: ${oauthClientJson}` };
    }
    
    return { valid: true, message: 'Google Workspace OAuth configured' };
  },

  google: async (fields) => {
    const apiKey = fields.apiKey?.value;
    if (!apiKey) return { valid: false, message: 'API Key required' };

    try {
      const https = require('https');
      const response = await new Promise((resolve, reject) => {
        const req = https.request(
          `https://generativelanguage.googleapis.com/v1beta/models?key=${encodeURIComponent(apiKey)}`,
          {
            method: 'GET',
            headers: {
              'User-Agent': 'OpenClawTools/1.0'
            }
          },
          (res) => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => resolve({ status: res.statusCode, data }));
          }
        );
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.end();
      });

      if (response.status === 200) {
        return { valid: true, message: 'Connected to Gemini API' };
      } else if (response.status === 401 || response.status === 403) {
        return { valid: false, message: 'Invalid API key' };
      }
      return { valid: false, message: `HTTP ${response.status}` };
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },
  
  nanoBanana: async (fields) => {
    const apiKey = fields.apiKey?.value;
    if (!apiKey) return { valid: false, message: 'API Key required' };

    // Validate Nano Banana key directly against Gemini backbone API
    // (treat as independent credential; do not infer from Gemini credential status)
    try {
      const https = require('https');
      const response = await new Promise((resolve, reject) => {
        const req = https.request(
          `https://generativelanguage.googleapis.com/v1beta/models?key=${encodeURIComponent(apiKey)}`,
          {
            method: 'GET',
            headers: {
              'User-Agent': 'OpenClawTools/1.0'
            }
          },
          (res) => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => resolve({ status: res.statusCode, data }));
          }
        );
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.end();
      });

      if (response.status === 200) {
        return { valid: true, message: 'Connected to Gemini backbone (Nano Banana key valid)' };
      } else if (response.status === 401 || response.status === 403) {
        return { valid: false, message: 'Invalid API key' };
      }
      return { valid: false, message: `HTTP ${response.status}` };
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },
  
  whisper: async (fields) => {
    const apiKey = fields.apiKey?.value;
    if (!apiKey) return { valid: false, message: 'API Key required' };
    
    // Same as OpenAI validation
    try {
      const https = require('https');
      const response = await new Promise((resolve, reject) => {
        const req = https.request('https://api.openai.com/v1/models', {
          method: 'GET',
          headers: { 'Authorization': `Bearer ${apiKey}` }
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.end();
      });
      
      if (response.status === 200) {
        return { valid: true, message: 'Connected to OpenAI (Whisper ready)' };
      } else if (response.status === 401) {
        return { valid: false, message: 'Invalid API key (401)' };
      } else {
        return { valid: false, message: `HTTP ${response.status}` };
      }
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },
  
  vapi: async (fields) => {
    const apiKey = fields.apiKey?.value;
    if (!apiKey) return { valid: false, message: 'API Key required' };
    
    try {
      const https = require('https');
      const response = await new Promise((resolve, reject) => {
        const req = https.request('https://api.vapi.ai/assistant', {
          method: 'GET',
          headers: { 'Authorization': `Bearer ${apiKey}` }
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.end();
      });
      
      if (response.status === 200) {
        return { valid: true, message: 'Connected to VAPI' };
      } else if (response.status === 401) {
        return { valid: false, message: 'Invalid API key (401)' };
      } else {
        return { valid: false, message: `HTTP ${response.status}` };
      }
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },
  
  pinecone: async (fields) => {
    const apiKey = fields.apiKey?.value;
    // Accept full URL (https://host) or bare hostname — strip protocol automatically
    const rawHost = fields.indexHost?.value || fields.host?.value || '';
    const host = rawHost.replace(/^https?:\/\//, '').trim();

    if (!apiKey) return { valid: false, message: 'API Key required' };
    if (!host) return { valid: false, message: 'Index Host required' };

    try {
      const https = require('https');
      const body = JSON.stringify({});
      const response = await new Promise((resolve, reject) => {
        const req = https.request(`https://${host}/describe_index_stats`, {
          method: 'POST',
          headers: {
            'Api-Key': apiKey,
            'Content-Type': 'application/json',
            'Content-Length': Buffer.byteLength(body),
            'X-Pinecone-API-Version': '2024-04'
          }
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode, headers: res.headers || {}, data }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.write(body);
        req.end();
      });

      if (response.status === 200) {
        try {
          const stats = JSON.parse(response.data);
          const vectorCount = stats.totalVectorCount ?? stats.total_vector_count ?? '?';
          const indexName = fields.indexName?.value || host.split('-').slice(0, 2).join('-');
          return { valid: true, message: `Connected to Pinecone • ${vectorCount} vectors in ${indexName}` };
        } catch {
          return { valid: true, message: 'Connected to Pinecone' };
        }
      } else if (response.status === 401) {
        return { valid: false, message: 'Invalid API key (401)' };
      } else if (response.status === 403) {
        const reason = response.headers?.['x-pinecone-auth-rejected-reason'] || response.headers?.['www-authenticate'] || null;
        return { valid: false, message: `Forbidden (403)${reason ? ` — ${reason}` : ''} — check API key / project / index host` };
      
      } else {
        return { valid: false, message: `HTTP ${response.status}` };
      }
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },
  
  stripe: async (fields) => {
    const secretKey = fields.secretKey?.value;
    if (!secretKey) return { valid: false, message: 'Secret Key required' };
    
    // Validate key format
    if (!secretKey.startsWith('sk_')) {
      return { valid: false, message: 'Invalid key format. Should start with sk_live_ or sk_test_' };
    }
    
    try {
      const https = require('https');
      const response = await new Promise((resolve, reject) => {
        const req = https.request('https://api.stripe.com/v1/account', {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${secretKey}`
          }
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => resolve({ status: res.statusCode, data }));
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.end();
      });
      
      if (response.status === 200) {
        const json = JSON.parse(response.data);
        const accountName = json.settings?.dashboard?.display_name || json.id;
        const mode = secretKey.includes('_live_') ? 'live' : 'test';
        return { valid: true, message: `Connected: ${accountName} (${mode} mode)` };
      } else if (response.status === 401) {
        return { valid: false, message: 'Invalid API key (401)' };
      } else {
        return { valid: false, message: `Stripe API error: ${response.status}` };
      }
    } catch (err) {
      return { valid: false, message: err.message };
    }
  },

  github: async (fields) => {
    const token = fields.token?.value;
    
    if (!token) return { valid: false, message: 'Personal Access Token required' };
    
    // Validate token format
    if (!token.startsWith('ghp_') && !token.startsWith('github_pat_')) {
      return { valid: false, message: 'Invalid token format. Should start with ghp_ or github_pat_' };
    }
    
    try {
      const response = await fetch('https://api.github.com/user', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Accept': 'application/vnd.github+json',
          'X-GitHub-Api-Version': '2022-11-28'
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        return { valid: true, message: `Connected as @${data.login}` };
      } else if (response.status === 401) {
        return { valid: false, message: 'Invalid or expired token (401)' };
      } else if (response.status === 403) {
        return { valid: false, message: 'Token lacks required permissions (403)' };
      } else {
        return { valid: false, message: `GitHub API error: ${response.status}` };
      }
    } catch (err) {
      return { valid: false, message: `Connection failed: ${err.message}` };
    }
  },

  groove: async (fields) => {
    const token = fields.apiToken?.value;
    if (!token) return { valid: false, message: 'API Token required' };

    try {
      const https = require('https');
      const response = await new Promise((resolve, reject) => {
        const req = https.request('https://api.groovehq.com/v1/me', {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        }, (res) => {
          let data = '';
          res.on('data', chunk => data += chunk);
          res.on('end', () => {
            try { resolve({ status: res.statusCode, body: JSON.parse(data) }); }
            catch { resolve({ status: res.statusCode, body: {} }); }
          });
        });
        req.on('error', reject);
        req.setTimeout(10000, () => reject(new Error('Timeout')));
        req.end();
      });

      if (response.status === 200 && response.body?.user) {
        const u = response.body.user;
        return { valid: true, message: `Connected as ${u.first_name} ${u.last_name} (${u.email})` };
      } else if (response.status === 401) {
        return { valid: false, message: 'Invalid or expired token (401)' };
      } else if (response.status === 403) {
        return { valid: false, message: 'Token lacks required permissions (403)' };
      } else {
        return { valid: false, message: `Groove API error: ${response.status}` };
      }
    } catch (err) {
      return { valid: false, message: `Connection failed: ${err.message}` };
    }
  }
};

// Merge package validators (loaded from packages/ directory)
const packageValidators = getPackageValidators();
for (const [id, validator] of Object.entries(packageValidators)) {
  VALIDATORS[id] = validator;
}

app.post('/api/services/:id/validate', requireAuth, async (req, res) => {
  const { id } = req.params;
  
  // First check if this is a credential ID (new system)
  const credential = getCredential(id);
  if (credential) {
    const packageId = credential._package;
    
    // Use live validator if available for the package type
    if (VALIDATORS[packageId]) {
      const result = await VALIDATORS[packageId](credential.fields || {});
      return res.json(result);
    }
    
    // Fall back to schema-based validation
    const schema = SERVICE_SCHEMAS[packageId];
    if (!schema || !schema.validation) {
      return res.json({ valid: null, message: 'No validation configured for this service type' });
    }
    
    return res.json({ 
      valid: null, 
      message: `Would test: ${schema.validation.endpoint}`,
      note: 'Live validation coming soon'
    });
  }
  
  // Legacy: check for service ID
  const service = getService(id);
  if (VALIDATORS[id]) {
    const result = await VALIDATORS[id](service?.fields || {});
    return res.json(result);
  }
  
  res.json({ valid: null, message: 'Service not found' });
});

app.post('/api/regenerate', requireAuth, (req, res) => {
  const { generateToolsMd, lintFieldReferences } = require('./lib/generator');
  const { listServices } = require('./lib/registry');

  // Run lint before generation
  let lintWarnings = [];
  try {
    const services = listServices();
    lintWarnings = lintFieldReferences(services);
  } catch (e) {
    lintWarnings = [`Lint check failed: ${e.message}`];
  }

  const path = generateToolsMd();
  res.json({ success: true, path, lintWarnings });
});

app.get('/api/toolsmd/backups', requireAuth, (req, res) => {
  try {
    const backupDir = path.join(process.env.HOME || '/home/alex', '.openclaw/workspace/.tools-md-backups');
    const backups = [];
    for (let i = 1; i <= 4; i++) {
      const backupPath = path.join(backupDir, `TOOLS.md.${i}`);
      if (fs.existsSync(backupPath)) {
        const stats = fs.statSync(backupPath);
        backups.push({
          version: i,
          date: stats.mtime.toISOString(),
          size: stats.size
        });
      }
    }
    res.json({ backups });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/toolsmd/restore/:version', requireAuth, (req, res) => {
  try {
    const version = parseInt(req.params.version);
    if (version < 1 || version > 4) {
      return res.status(400).json({ error: 'Invalid backup version (1-4)' });
    }
    
    const backupDir = path.join(process.env.HOME || '/home/alex', '.openclaw/workspace/.tools-md-backups');
    const backupPath = path.join(backupDir, `TOOLS.md.${version}`);
    const toolsMdPath = path.join(process.env.HOME || '/home/alex', '.openclaw/workspace/TOOLS.md');
    
    if (!fs.existsSync(backupPath)) {
      return res.status(404).json({ error: 'Backup not found' });
    }
    
    // Backup current before restoring
    const { backupToolsMd } = require('./lib/generator');
    backupToolsMd();
    
    // Restore
    fs.copyFileSync(backupPath, toolsMdPath);
    res.json({ success: true, message: `Restored from backup ${version}` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/toolsmd', requireAuth, (req, res) => {
  try {
    const fs = require('fs');
    const path = require('path');
    const toolsMdPath = path.join(process.env.HOME || '/home/alex', '.openclaw/workspace/TOOLS.md');
    
    if (fs.existsSync(toolsMdPath)) {
      const content = fs.readFileSync(toolsMdPath, 'utf8');
      res.json({ content });
    } else {
      res.json({ content: '# TOOLS.md not found\n\nClick "Regenerate TOOLS.md" to create it.' });
    }
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Health check - validate all credentials (cached by default)
const HEALTH_CACHE_PATH = path.join(__dirname, '.health-cache.json');
const DEFAULT_HEALTH_MAX_AGE_MS = parseInt(process.env.TOOLS_HEALTH_MAX_AGE_MS || `${24 * 60 * 60 * 1000}`, 10); // default 24h

function readHealthCache() {
  try {
    if (!fs.existsSync(HEALTH_CACHE_PATH)) return null;
    return JSON.parse(fs.readFileSync(HEALTH_CACHE_PATH, 'utf8'));
  } catch {
    return null;
  }
}

function writeHealthCache(payload) {
  const data = { ...payload, generatedAt: new Date().toISOString() };
  fs.writeFileSync(HEALTH_CACHE_PATH, JSON.stringify(data, null, 2));
  return data;
}

async function runHealthCheckLive() {
  const credentials = listCredentials();
  const results = [];
  let passed = 0;
  let failed = 0;
  let unknown = 0;

  for (const [id, cred] of Object.entries(credentials)) {
    const validator = VALIDATORS[cred._package];
    let status = 'unknown';
    let message = 'No validation configured';

    if (validator) {
      try {
        const result = await validator(cred.fields || {});
        if (result.valid === true) {
          status = 'pass';
          message = result.message;
          passed++;
        } else if (result.valid === false) {
          status = 'fail';
          message = result.message;
          failed++;
        } else {
          status = 'unknown';
          message = result.message || 'Validation returned null';
          unknown++;
        }
      } catch (err) {
        status = 'fail';
        message = err.message;
        failed++;
      }
    } else {
      unknown++;
    }

    results.push({ id, name: cred._name, packageId: cred._package, status, message });
  }

  const total = results.length;
  const allSystemsGo = failed === 0;

  // Include OAuth token health snapshot for dashboard UX
  const oauth = {};
  const profiles = readAuthProfiles()?.profiles || {};
  const oauthProfileIds = Object.keys(profiles).filter((id) => {
    const p = profiles[id];
    return p && (p.type === 'oauth' || (typeof p.expires === 'number' && p.expires > 0));
  });

  for (const profileId of oauthProfileIds) {
    const [provider] = profileId.split(':');
    const state = getProviderAuthState(provider, profileId.split(':')[1] || 'default');
    oauth[provider] = {
      profileId: state.profileId,
      exists: state.exists,
      expires: state.expires,
      expiresAt: state.expiresAt,
      ttlMs: state.ttlMs,
      status: !state.exists ? 'missing' : ((state.ttlMs || 0) <= 0 ? 'expired' : ((state.ttlMs || 0) <= 24 * 60 * 60 * 1000 ? 'expiring' : 'ok'))
    };
  }

  return {
    summary: {
      total,
      passed,
      failed,
      unknown,
      allSystemsGo,
      status: allSystemsGo ? 'ALL_SYSTEMS_GO' : 'ISSUES_DETECTED'
    },
    oauth,
    results
  };
}

// Obsidian headless login bridge (stateless)
app.post('/api/obsidian/login', requireAuth, async (req, res) => {
  const credentialId = req.body?.credentialId;
  const otp = req.body?.otp;

  if (!credentialId) {
    return res.status(400).json({ error: 'credentialId is required' });
  }

  const cred = getCredential(String(credentialId));
  if (!cred || cred._package !== 'obsidian-sync') {
    return res.status(400).json({ error: 'Valid obsidian-sync credential required' });
  }

  const e = cred.fields?.accountEmail?.value;
  const p = cred.fields?.accountPassword?.value;
  const remoteVault = cred.fields?.remoteVault?.value;
  let vaultPath = cred.fields?.vaultPath?.value;
  const e2ePassword = cred.fields?.e2ePassword?.value;
  const deviceName = cred.fields?.deviceName?.value || 'tools-server';

  if (!e || !p) {
    return res.status(400).json({ error: 'Selected credential is missing accountEmail or accountPassword' });
  }

  const obCmd = resolveObCmd();
  if (!obCmd) {
    return res.status(400).json({ error: 'Cannot find `ob` CLI. Install obsidian-headless.' });
  }

  // Vault path handling:
  // - If vaultPath is blank, auto-manage it under a safe base directory.
  // - If vaultPath is provided, restrict it to the base dir unless explicitly allowed.
  const path = require('path');
  const fs = require('fs');
  const baseDir = process.env.OBSIDIAN_VAULTS_BASE || path.join(__dirname, 'data', 'obsidian-vaults');
  fs.mkdirSync(baseDir, { recursive: true });

  const allowCustomPaths = String(process.env.OBSIDIAN_ALLOW_CUSTOM_PATHS || 'false') === 'true';
  const effectiveVaultPath = vaultPath ? String(vaultPath) : path.join(baseDir, String(credentialId));
  const resolvedBase = path.resolve(baseDir);
  const resolvedVault = path.resolve(effectiveVaultPath);

  if (!allowCustomPaths && !resolvedVault.startsWith(resolvedBase + path.sep)) {
    return res.status(400).json({
      error: `vaultPath must be within ${resolvedBase} (custom paths disabled)`
    });
  }

  // Persist auto-managed vaultPath back into the credential so validation/background jobs know where to find it
  if (!vaultPath) {
    try {
      updateCredential(String(credentialId), {
        fields: { vaultPath: { value: resolvedVault } }
      });
      vaultPath = resolvedVault;
    } catch {}
  }

  let log = `Executing \`ob login\` ...\n`;

  // Redact password from output just in case
  const redact = (text) => text.replace(new RegExp(String(p).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g'), '[REDACTED_PASSWORD]');

  const runCommand = (cmd, args) => {
    return new Promise((resolve) => {
      const child = spawn(cmd, args);
      child.stdout.on('data', (buf) => log += redact(buf.toString('utf8')));
      child.stderr.on('data', (buf) => log += redact(buf.toString('utf8')));
      
      child.on('close', (code) => {
        log += `\n[process exited: ${code}]\n`;
        resolve(code);
      });
      setTimeout(() => {
        try { child.kill('SIGKILL'); } catch {}
        log += '\n[timeout killed]\n';
        resolve(-1);
      }, 30000);
    });
  };

  const loginArgs = ['login', '--email', String(e), '--password', String(p)];
  if (otp) loginArgs.push('--mfa', String(otp));

  const loginCode = await runCommand(obCmd, loginArgs);
  const logLower = log.toLowerCase();
  let success = (logLower.includes('logged in as') || logLower.includes('login successful')) || (!logLower.includes('login failed') && !logLower.includes('error') && !logLower.includes('failed'));

  // If login succeeded, AND we have a remoteVault selected, automatically do sync-setup
  if (success && remoteVault) {
    log += `\nLogin successful. Auto-configuring vault sync...\n`;
    
    // Ensure directory exists
    const mkdirArgs = ['-p', String(vaultPath)];
    await runCommand('mkdir', mkdirArgs);

    const setupArgs = [
      'sync-setup',
      '--vault', String(remoteVault),
      '--path', String(vaultPath),
      '--device-name', String(deviceName)
    ];
    
    if (e2ePassword) {
      setupArgs.push('--password', String(e2ePassword));
    }

    log += `Executing \`ob sync-setup --vault "${remoteVault}" --path "${vaultPath}"\` ...\n`;
    const setupCode = await runCommand(obCmd, setupArgs);
    if (setupCode !== 0 && !log.includes('already configured')) {
       success = false;
       log += `\n⚠️ sync-setup failed. You may need to run it manually.\n`;
    } else {
       log += `\n✅ Vault successfully linked!\n`;
    }
  }

  res.json({ success, logTail: log });
});

// Obsidian: list remote vaults (for UI dropdown)
app.get('/api/obsidian/vaults', requireAuth, (req, res) => {
  const obCmd = resolveObCmd();
  if (!obCmd) return res.status(400).json({ error: 'Cannot find `ob` CLI. Install obsidian-headless or set OB_CLI_PATH.' });

  const { spawnSync } = require('child_process');
  const out = spawnSync(obCmd, ['sync-list-remote'], { encoding: 'utf8', timeout: 20000, env: process.env });
  const stdout = out.stdout || '';
  const stderr = out.stderr || '';

  if (out.status !== 0) {
    return res.status(400).json({
      error: 'Failed to list remote vaults. Are you logged in?',
      details: (stderr || stdout).trim().slice(0, 2000)
    });
  }

  const combined = `${stdout}\n${stderr}`;
  const lines = combined.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
  const vaults = [];

  for (const line of lines) {
    // Example: 8a7fe... "LexTalks vault" (North America)
    const m = line.match(/([0-9a-f]{32})\s+"([^"]+)"\s+\(([^)]+)\)/i);
    if (m) {
      vaults.push({ id: m[1], name: m[2], region: m[3], line });
      continue;
    }

    // Fallback: <id> <name> (<region>)
    const m2 = line.match(/([0-9a-f]{32})\s+(.+?)\s+\(([^)]+)\)/i);
    if (m2) {
      vaults.push({ id: m2[1], name: m2[2].replace(/^"|"$/g, ''), region: m2[3], line });
    }
  }

  res.json({ vaults, raw: lines.slice(0, 50) });
});

app.get('/api/health', requireAuth, async (req, res) => {
  try {
    const refresh = String(req.query.refresh || 'false') === 'true';
    const maxAgeMs = Math.max(60_000, parseInt(req.query.maxAgeMs || `${DEFAULT_HEALTH_MAX_AGE_MS}`, 10));
    const cached = readHealthCache();

    if (!refresh && cached?.generatedAt) {
      const age = Date.now() - new Date(cached.generatedAt).getTime();
      if (age >= 0 && age <= maxAgeMs) {
        // Always overlay oauth section with fresh live read (local file only, no network cost)
        // This ensures re-auth token expiry is reflected immediately without cache busting
        const liveOauth = {};
        const profiles = readAuthProfiles()?.profiles || {};
        for (const profileId of Object.keys(profiles).filter(id => {
          const p = profiles[id];
          return p && (p.type === 'oauth' || (typeof p.expires === 'number' && p.expires > 0));
        })) {
          const [provider] = profileId.split(':');
          const s = getProviderAuthState(provider, profileId.split(':')[1] || 'default');
          liveOauth[provider] = {
            profileId: s.profileId,
            exists: s.exists,
            expires: s.expires,
            expiresAt: s.expiresAt,
            ttlMs: s.ttlMs,
            status: !s.exists ? 'missing' : ((s.ttlMs || 0) <= 0 ? 'expired' : ((s.ttlMs || 0) <= 24 * 60 * 60 * 1000 ? 'expiring' : 'ok'))
          };
        }
        return res.json({ ...cached, oauth: liveOauth, cache: { used: true, ageMs: age, maxAgeMs } });
      }
    }

    const live = await runHealthCheckLive();
    const saved = writeHealthCache(live);
    res.json({ ...saved, cache: { used: false, ageMs: 0, maxAgeMs } });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/health/refresh', requireAuth, async (req, res) => {
  try {
    const live = await runHealthCheckLive();
    const saved = writeHealthCache(live);
    res.json({ success: true, ...saved, cache: { used: false, ageMs: 0 } });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/health/status', requireAuth, (req, res) => {
  const cached = readHealthCache();
  if (!cached?.generatedAt) {
    return res.json({
      hasCache: false,
      generatedAt: null,
      ageMs: null,
      summary: null
    });
  }

  const ageMs = Date.now() - new Date(cached.generatedAt).getTime();
  res.json({
    hasCache: true,
    generatedAt: cached.generatedAt,
    ageMs,
    summary: cached.summary || null
  });
});

app.get('/api/registry/path', requireAuth, (req, res) => {
  res.json({ path: REGISTRY_PATH });
});

// ─── Domains API ──────────────────────────────────────────────────────────────
// Domains stored in registry.meta.domains — configurable action categories.
// GET    /api/domains          → list all domains
// GET    /api/domains/:id      → get single domain
// POST   /api/domains          → create or update a domain (upsert by id)
// DELETE /api/domains/:id      → remove a domain

app.get('/api/domains', requireAuth, (req, res) => {
  try {
    const domains = loadDomains();
    res.json({ domains });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/domains/:id', requireAuth, (req, res) => {
  try {
    const domain = getDomain(req.params.id.toUpperCase());
    if (!domain) return res.status(404).json({ error: 'Domain not found' });
    res.json(domain);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/domains', requireAuth, (req, res) => {
  try {
    const domain = req.body;
    if (!domain || !domain.id) return res.status(400).json({ error: 'Domain body with id required' });
    const saved = upsertDomain(domain);
    // Regenerate TOOLS.md so domains table is updated
    try { require('./lib/generator').generateToolsMd(); } catch (e) { /* non-fatal */ }
    res.json({ success: true, domain: saved });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.delete('/api/domains/:id', requireAuth, (req, res) => {
  try {
    const deleted = deleteDomain(req.params.id.toUpperCase());
    if (!deleted) return res.status(404).json({ error: 'Domain not found' });
    try { require('./lib/generator').generateToolsMd(); } catch (e) { /* non-fatal */ }
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── Model Knowledge Base API ─────────────────────────────────────────────────
// Models stored in registry.meta.models — knowledge base for model selection.
// GET    /api/models          → list all models
// GET    /api/models/:id      → get single model (by id or alias)
// POST   /api/models          → create or update a model (upsert by id)
// DELETE /api/models/:id      → remove a model

app.get('/api/models', requireAuth, (req, res) => {
  try {
    const models = loadModels();
    res.json({ models });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/models/:id', requireAuth, (req, res) => {
  try {
    const model = getModel(req.params.id);
    if (!model) return res.status(404).json({ error: 'Model not found' });
    res.json(model);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/models', requireAuth, (req, res) => {
  try {
    const model = req.body;
    if (!model || !model.id) return res.status(400).json({ error: 'Model body with id required' });
    const saved = upsertModel(model);
    try { require('./lib/generator').generateToolsMd(); } catch (e) { /* non-fatal */ }
    res.json({ success: true, model: saved });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.delete('/api/models/:id', requireAuth, (req, res) => {
  try {
    const deleted = deleteModel(req.params.id);
    if (!deleted) return res.status(404).json({ error: 'Model not found' });
    try { require('./lib/generator').generateToolsMd(); } catch (e) { /* non-fatal */ }
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── Intent Rules API ─────────────────────────────────────────────────────────
// Rules stored in registry.meta.intentRules — no credentials needed.
// GET    /api/intent-rules          → list all rules
// GET    /api/intent-rules/:id      → get single rule
// POST   /api/intent-rules          → create or update a rule (upsert by id)
// DELETE /api/intent-rules/:id      → remove a rule
// POST   /api/intent-rules/regenerate → regenerate TOOLS.md after rule changes

app.get('/api/intent-rules', requireAuth, (req, res) => {
  try {
    const rules = loadIntentRules();
    res.json({ rules });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/intent-rules/:id', requireAuth, (req, res) => {
  try {
    const rule = getIntentRule(req.params.id);
    if (!rule) return res.status(404).json({ error: 'Rule not found' });
    res.json(rule);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/intent-rules', requireAuth, (req, res) => {
  try {
    const rule = req.body;
    if (!rule || !rule.id) return res.status(400).json({ error: 'Rule body with id required' });
    const saved = upsertIntentRule(rule);
    // Regenerate TOOLS.md so rules are immediately visible to the agent
    try { require('./lib/generator').generateToolsMd(); } catch (e) { /* non-fatal */ }
    res.json({ success: true, rule: saved });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

app.delete('/api/intent-rules/:id', requireAuth, (req, res) => {
  try {
    const deleted = deleteIntentRule(req.params.id);
    if (!deleted) return res.status(404).json({ error: 'Rule not found' });
    try { require('./lib/generator').generateToolsMd(); } catch (e) { /* non-fatal */ }
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

function loadRouterConfig() {
  const routerPath = path.join(__dirname, 'router.json');
  if (!fs.existsSync(routerPath)) return { routes: { default: ['brave'] }, failurePolicy: {} };
  try {
    return JSON.parse(fs.readFileSync(routerPath, 'utf8'));
  } catch {
    return { routes: { default: ['brave'] }, failurePolicy: {} };
  }
}

app.get('/api/router/intents', requireAuth, (req, res) => {
  const router = loadRouterConfig();
  res.json({ intents: Object.keys(router.routes || {}) });
});

app.get('/api/router', requireAuth, (req, res) => {
  const intent = (req.query.intent || 'default').toString();
  const includeUnavailable = String(req.query.includeUnavailable || 'false') === 'true';
  const healthyOnly = String(req.query.healthyOnly || 'false') === 'true';
  const router = loadRouterConfig();
  const credentials = listCredentials();
  const availablePackages = new Set(Object.values(credentials).map(c => c._package));

  const healthCache = readHealthCache();
  const packageHealth = new Map();
  if (healthCache?.results) {
    for (const r of healthCache.results) {
      if (!packageHealth.has(r.packageId)) packageHealth.set(r.packageId, []);
      packageHealth.get(r.packageId).push(r.status);
    }
  }

  const route = (router.routes && (router.routes[intent] || router.routes.default)) || ['brave'];
  const candidates = route.map((packageId, index) => {
    const statuses = packageHealth.get(packageId) || [];
    const healthy = statuses.length === 0 ? null : statuses.every(s => s !== 'fail');
    return {
      packageId,
      priority: index + 1,
      available: availablePackages.has(packageId),
      healthy
    };
  });

  let filtered = includeUnavailable ? candidates : candidates.filter(c => c.available);
  if (healthyOnly) {
    filtered = filtered.filter(c => c.healthy !== false);
  }

  res.json({
    intent,
    candidates: filtered,
    allCandidates: candidates,
    failurePolicy: router.failurePolicy || {},
    healthCacheGeneratedAt: healthCache?.generatedAt || null
  });
});

function getVersionInfo() {
  const packageJsonPath = path.join(__dirname, 'package.json');
  const pkg = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8'));
  let gitSha = null;
  let branch = null;

  try { gitSha = execSync('git rev-parse --short HEAD', { cwd: __dirname }).toString().trim(); } catch {}
  try { branch = execSync('git rev-parse --abbrev-ref HEAD', { cwd: __dirname }).toString().trim(); } catch {}

  return {
    name: pkg.name,
    version: pkg.version,
    gitSha,
    branch
  };
}

app.get('/api/version', requireAuth, (req, res) => {
  try {
    res.json({ current: getVersionInfo(), update: readUpdateState() });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Agent bootstrap guide — compact self-description for AI agents
// Also available without auth so agents can discover it before they have credentials
app.get('/api/agent-guide', (req, res) => {
  const version = getVersionInfo();
  const routerConfig = loadRouterConfig();
  const intents = Object.keys(routerConfig.routes || {}).filter(k => k !== 'default');
  const credentialIds = Object.keys(listCredentials());

  res.json({
    name: 'OpenClaw Tools Config Server',
    version: version.version || 'unknown',
    description: 'Self-hosted credential vault, health dashboard, intent router, and query runner for AI agent infrastructure.',

    quickstart: {
      step1: 'POST /api/login with {"password": "<your-password>"} — sets session cookie',
      step2: 'GET /api/health — check which services are configured and healthy',
      step3: 'GET /api/credentials/:id — get credential fields for a specific service',
      step4: 'GET /api/router?intent=<intent> — find the right service for a task',
      step5: 'GET /api/credentials/:id/usage — get a ready-to-run curl example'
    },

    key_endpoints: [
      { method: 'POST', path: '/api/login',                     auth: false, description: 'Authenticate — returns session cookie' },
      { method: 'GET',  path: '/api/health',                    auth: true,  description: 'All services status + vector count / connection details' },
      { method: 'GET',  path: '/api/credentials',               auth: true,  description: 'List all configured credentials with usage examples' },
      { method: 'GET',  path: '/api/credentials/:id',           auth: true,  description: 'Single credential — fields, schema, usage example' },
      { method: 'GET',  path: '/api/credentials/:id/usage',     auth: true,  description: 'Ready-to-run curl example for a service' },
      { method: 'POST', path: '/api/credentials/:id/example/run', auth: true, description: 'Execute a service API call server-side and return response' },
      { method: 'GET',  path: '/api/router?intent=<intent>',    auth: true,  description: 'Ordered service candidates for an intent (e.g. hotel_search)' },
      { method: 'GET',  path: '/api/router/intents',            auth: true,  description: 'List all supported routing intents' },
      { method: 'GET',  path: '/api/services',                  auth: true,  description: 'All available service schemas (fields, labels, icons)' },
      { method: 'GET',  path: '/api/toolsmd',                   auth: true,  description: 'Auto-generated TOOLS.md — human/agent reference for all services' },
      { method: 'GET',  path: '/api/version',                   auth: true,  description: 'Server version + update status' },
      { method: 'POST', path: '/api/update/run',                auth: true,  description: 'Trigger server update (pulls latest, restarts)' }
    ],

    intent_router: {
      description: 'Maps task intents to ordered service candidates based on what is configured.',
      supported_intents: intents,
      example: 'GET /api/router?intent=hotel_search → [{packageId:"amadeus",...},{packageId:"duffel",...}]',
      failure_policy: routerConfig.failurePolicy || {}
    },

    configured_credentials: credentialIds.length,
    credential_ids: credentialIds,

    agent_tips: [
      'Always call /api/health first to see what is available before attempting to use a service',
      'Use /api/router to find the right service for a task instead of hardcoding service names',
      'Use /api/credentials/:id/usage for copy-paste ready curl commands',
      'Use /api/credentials/:id/example/run to execute API calls server-side without leaving this server',
      'TOOLS.md at /api/toolsmd is the most compact agent-readable summary of all services',
      'Access file at /root/.tools-server-access contains URL + password for agent discovery'
    ],

    docs: 'https://github.com/Streamliner-One/tools'
  });
});

function compareSemver(a, b) {
  const clean = (v) => String(v || '').trim().replace(/^v/i, '');
  const pa = clean(a).split('.').map(n => parseInt(n, 10));
  const pb = clean(b).split('.').map(n => parseInt(n, 10));
  if (pa.some(Number.isNaN) || pb.some(Number.isNaN)) return null;
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const ai = pa[i] || 0;
    const bi = pb[i] || 0;
    if (ai > bi) return 1;
    if (ai < bi) return -1;
  }
  return 0;
}

let _updateCheckCache = null;
let _updateCheckCacheAt = 0;
const UPDATE_CHECK_TTL_MS = 5 * 60 * 1000; // 5 minutes

app.get('/api/update/check', requireAuth, (req, res) => {
  if (_updateCheckCache && (Date.now() - _updateCheckCacheAt) < UPDATE_CHECK_TTL_MS) {
    return res.json(_updateCheckCache);
  }
  try {
    const current = getVersionInfo();
    const branch = current.branch || 'main';

    execSync('git fetch origin', { cwd: __dirname, stdio: 'ignore' });
    const localSha = execSync('git rev-parse HEAD', { cwd: __dirname }).toString().trim();
    const remoteSha = execSync(`git rev-parse origin/${branch}`, { cwd: __dirname }).toString().trim();

    let commitsBehind = 0;
    try {
      commitsBehind = parseInt(execSync(`git rev-list --count ${localSha}..${remoteSha}`, { cwd: __dirname }).toString().trim(), 10) || 0;
    } catch {}

    let remoteVersion = null;
    try {
      let remotePkg = '';
      try {
        remotePkg = execSync(`git show origin/${branch}:package.json`, { cwd: __dirname }).toString();
      } catch {
        remotePkg = execSync(`git show origin/${branch}:tools-server/package.json`, { cwd: __dirname }).toString();
      }
      remoteVersion = JSON.parse(remotePkg).version || null;
    } catch {}

    const versionCmp = compareSemver(remoteVersion, current.version);
    const remoteIsNewer = versionCmp === 1;
    const updateAvailable = remoteIsNewer || (commitsBehind > 0 && versionCmp !== -1);
    const relation = localSha === remoteSha
      ? 'equal'
      : (commitsBehind > 0 ? 'behind' : 'ahead_or_diverged');

    const result = {
      current,
      remote: { sha: remoteSha, branch, version: remoteVersion },
      updateAvailable,
      commitsBehind,
      relation,
      remoteIsNewer,
      versionComparison: versionCmp
    };
    _updateCheckCache = result;
    _updateCheckCacheAt = Date.now();
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

const UPDATE_LOG_PATH = path.join(__dirname, 'update-run.log');
const UPDATE_PID_PATH = path.join(__dirname, '.update.pid');
const UPDATE_STATE_PATH = path.join(__dirname, '.update-state.json');

function readUpdateState() {
  if (!fs.existsSync(UPDATE_STATE_PATH)) {
    return { lastRunAt: null, lastSuccessAt: null, lastFailureAt: null, lastTargetSha: null, lastExitCode: null };
  }
  try {
    return JSON.parse(fs.readFileSync(UPDATE_STATE_PATH, 'utf8'));
  } catch {
    return { lastRunAt: null, lastSuccessAt: null, lastFailureAt: null, lastTargetSha: null, lastExitCode: null };
  }
}

function writeUpdateState(patch = {}) {
  const state = { ...readUpdateState(), ...patch };
  fs.writeFileSync(UPDATE_STATE_PATH, JSON.stringify(state, null, 2));
  return state;
}

function readUpdateStatus() {
  let running = false;
  let pid = null;
  let startedAt = null;

  if (fs.existsSync(UPDATE_PID_PATH)) {
    const raw = fs.readFileSync(UPDATE_PID_PATH, 'utf8').trim();
    const [pidStr, started] = raw.split(',');
    pid = parseInt(pidStr, 10);
    startedAt = started || null;
    if (pid && Number.isFinite(pid)) {
      try {
        process.kill(pid, 0);
        running = true;
      } catch {
        running = false;
      }
    }

    // Cleanup stale PID and mark unknown completion as failed to avoid "stuck running" UX
    if (!running) {
      try { fs.unlinkSync(UPDATE_PID_PATH); } catch {}
      const state = readUpdateState();
      if (state.lastExitCode === null || state.lastExitCode === undefined) {
        writeUpdateState({ lastExitCode: 1, lastFailureAt: new Date().toISOString() });
        try {
          fs.appendFileSync(UPDATE_LOG_PATH, `[update] finished code=1 at ${new Date().toISOString()} (detected stale pid)\n`);
        } catch {}
      }
      pid = null;
    }
  }

  return { ...readUpdateState(), running, pid, startedAt, logPath: UPDATE_LOG_PATH };
}

app.get('/api/update/status', requireAuth, (req, res) => {
  try {
    res.json(readUpdateStatus());
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/update/log', requireAuth, (req, res) => {
  try {
    const from = parseInt(req.query.from || '0', 10);
    if (!fs.existsSync(UPDATE_LOG_PATH)) {
      return res.json({ from: 0, to: 0, text: '', done: true });
    }
    const content = fs.readFileSync(UPDATE_LOG_PATH, 'utf8');
    const to = content.length;
    const text = content.slice(Math.max(0, from));
    const { running } = readUpdateStatus();
    res.json({ from: Math.max(0, from), to, text, done: !running });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/update/run', requireAuth, (req, res) => {
  try {
    const scriptPath = path.join(__dirname, 'update.sh');
    if (!fs.existsSync(scriptPath)) {
      return res.status(404).json({ error: 'update.sh not found' });
    }

    const status = readUpdateStatus();
    if (status.running) {
      return res.status(409).json({ error: 'Update already running', pid: status.pid });
    }

    const startedAt = new Date().toISOString();
    const targetSha = (() => { try { return execSync('git rev-parse --short origin/$(git rev-parse --abbrev-ref HEAD)', { cwd: __dirname, shell: '/bin/bash' }).toString().trim(); } catch { return null; } })();

    fs.writeFileSync(UPDATE_LOG_PATH, `[update] started ${startedAt}\n`);
    writeUpdateState({ lastRunAt: startedAt, lastTargetSha: targetSha, lastExitCode: null });

    const outFd = fs.openSync(UPDATE_LOG_PATH, 'a');
    const localDev = __dirname.includes('/.openclaw/workspace/');
    const args = localDev ? [scriptPath, '--local-dev'] : [scriptPath];

    const child = spawn('bash', args, {
      cwd: __dirname,
      detached: true,
      stdio: ['ignore', outFd, outFd]
    });

    child.on('exit', (code) => {
      try {
        fs.appendFileSync(UPDATE_LOG_PATH, `[update] finished code=${code ?? 1} at ${new Date().toISOString()}\n`);
      } catch {}
      const prev = readUpdateState();
      writeUpdateState({
        lastRunAt: startedAt,
        lastSuccessAt: (code === 0) ? new Date().toISOString() : (prev.lastSuccessAt || null),
        lastFailureAt: (code === 0) ? (prev.lastFailureAt || null) : new Date().toISOString(),
        lastTargetSha: targetSha,
        lastExitCode: code === 0 ? 0 : 1
      });
      try { fs.unlinkSync(UPDATE_PID_PATH); } catch {}
      try { fs.closeSync(outFd); } catch {}
    });
    fs.writeFileSync(UPDATE_PID_PATH, `${child.pid},${startedAt}`);
    child.unref();

    res.json({ success: true, message: 'Update started in background', pid: child.pid, targetSha });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ============================================
// CREDENTIAL API (n8n-style multiple instances)
// ============================================

// List all credentials
app.get('/api/credentials', requireAuth, (req, res) => {
  const credentials = listCredentials();
  const result = {};
  
  for (const [id, cred] of Object.entries(credentials)) {
    const schema = SERVICE_SCHEMAS[cred._package];
    result[id] = {
      id,
      name: cred._name,
      packageId: cred._package,
      packageName: schema?.name || cred._package,
      category: schema?.category || cred._primaryCategory || 'custom',
      primaryCategory: cred._primaryCategory || schema?.category || 'custom',
      labels: Array.isArray(cred._labels) && cred._labels.length
        ? cred._labels
        : (Array.isArray(schema?.labels) && schema.labels.length ? schema.labels : [schema?.category || 'custom']),
      icon: schema?.icon || '⚙️',
      fields: cred.fields,
      usage: buildUsageExample(cred._package, cred.fields),
      createdAt: cred.createdAt,
      updatedAt: cred.updatedAt
    };
  }
  
  res.json({ credentials: result });
});

// List credentials by package type
app.get('/api/credentials/package/:packageId', requireAuth, (req, res) => {
  const { packageId } = req.params;
  const credentials = listCredentialsByPackage(packageId);
  res.json({ credentials });
});

// Create new credential
app.post('/api/credentials', requireAuth, (req, res) => {
  try {
    const { packageId, name, fields } = req.body;
    
    if (!packageId || !name) {
      return res.status(400).json({ error: 'packageId and name required' });
    }
    
    const schema = SERVICE_SCHEMAS[packageId];
    if (!schema) {
      return res.status(404).json({ error: 'Package not found' });
    }
    
    // Generate unique ID
    const credentialId = `${packageId}-${Date.now()}`;
    
    const credential = createCredential(credentialId, {
      packageId,
      name,
      primaryCategory: schema.category || 'other',
      labels: Array.isArray(schema.labels) && schema.labels.length ? schema.labels : [schema.category || 'other'],
      fields: fields || {}
    });

    generateToolsMd();
    
    res.json({ 
      success: true, 
      credential: {
        id: credentialId,
        name: credential._name,
        packageId: credential._package
      }
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get single credential
// Helper: flatten fields { key: { value: "..." } } → { key: "..." }
// Returns the primary authentication value regardless of field name
// Priority: apiKey → apiToken → token → secretKey → clientId → first field
const PRIMARY_KEY_FIELDS = ['apiKey', 'apiToken', 'token', 'secretKey', 'serviceAccountToken', 'clientId'];
function resolvePrimaryKey(packageId, fields) {
  const flat = flattenFields(fields);
  for (const k of PRIMARY_KEY_FIELDS) {
    if (flat[k]) return flat[k];
  }
  // Return first non-empty field value as fallback
  const first = Object.values(flat).find(v => v);
  return first || null;
}

function flattenFields(fields) {
  const flat = {};
  for (const [k, v] of Object.entries(fields || {})) {
    flat[k] = (v && typeof v === 'object' && 'value' in v) ? v.value : v;
  }
  return flat;
}

// =========================
// OpenClaw Key Sync (manual)
// =========================

app.get('/api/openclaw/auth/status', requireAuth, (req, res) => {
  try {
    const { authPath, exists, data } = loadOpenclawAuthProfilesSafe();
    const providers = {};
    const supported = ['anthropic', 'openai', 'moonshot', 'google'];
    for (const provider of supported) {
      const resolved = resolveOpenclawProvider(provider, data);
      providers[provider] = {
        profileId: resolved.profileId,
        source: resolved.source,
        hasProfile: resolved.hasProfile,
        hasKey: resolved.hasKey,
        keyPreview: resolved.keyPreview,
        effectiveKind: resolved.effectiveKind,
        effectiveDetail: resolved.effectiveDetail
      };
    }

    res.json({
      ok: true,
      allowPush: OPENCLAW_PUSH_ENABLED,
      stateDir: getOpenclawStateDir(),
      agentId: getOpenclawAgentId(),
      authProfilesPath: authPath,
      authProfilesExists: exists,
      lastGood: data.lastGood || {},
      providers
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message, allowPush: OPENCLAW_PUSH_ENABLED });
  }
});

app.get('/api/openclaw/auth/compare/:credentialId', requireAuth, (req, res) => {
  try {
    const credentialId = req.params.credentialId;
    const credential = getCredential(credentialId);
    if (!credential) return res.status(404).json({ error: 'Credential not found' });

    const provider = credential._package;
    const storedKey = extractApiKeyValue(credential.fields);
    const storedPreview = storedKey ? maskSecret(storedKey) : null;

    const { data } = loadOpenclawAuthProfilesSafe();
    const resolved = resolveOpenclawProvider(provider, data);
    const profileId = resolved.profileId;
    const openclawKey = resolved.key;

    const match = !!(storedKey && openclawKey && storedKey === openclawKey);

    res.json({
      allowPush: OPENCLAW_PUSH_ENABLED,
      credentialId,
      provider,
      profileId,
      stored: {
        hasKey: !!storedKey,
        keyPreview: storedPreview
      },
      openclaw: {
        source: resolved.source,
        hasProfile: resolved.hasProfile,
        hasKey: resolved.hasKey,
        keyPreview: resolved.keyPreview,
        effectiveKind: resolved.effectiveKind,
        effectiveDetail: resolved.effectiveDetail
      },
      match
    });
  } catch (err) {
    res.status(500).json({ error: err.message, allowPush: OPENCLAW_PUSH_ENABLED });
  }
});

app.post('/api/credentials/:id/push/openclaw', requireAuth, (req, res) => {
  if (!OPENCLAW_PUSH_ENABLED) {
    return res.status(403).json({ error: 'OpenClaw push is disabled on this server. Set TOOLS_CONFIG_OPENCLAW_PUSH=1 and restart.' });
  }

  try {
    const credentialId = req.params.id;
    const credential = getCredential(credentialId);
    if (!credential) return res.status(404).json({ error: 'Credential not found' });

    const provider = credential._package;
    const apiKey = extractApiKeyValue(credential.fields);
    if (!apiKey) {
      return res.status(400).json({ error: `No API key/token field found on credential (${provider}). Expected one of: apiKey/key/token/accessToken/authToken` });
    }

    // Check where OpenClaw stores this provider's key (models.json vs auth-profiles.json)
    const modelsStatus = getOpenclawModelsStatus();
    const providerStatus = modelsStatus?.auth?.providers?.find?.(p => p.provider === provider);
    const effectiveKind = providerStatus?.effective?.kind || null;
    const usesModelsJson = effectiveKind === 'models.json';

    if (usesModelsJson) {
      // Write to models.json (e.g. openrouter, custom providers defined in openclaw.json)
      const modelsJsonPath = path.join(process.env.HOME || '/home/alex', '.openclaw/agents/main/agent/models.json');
      let modelsData = {};
      try { modelsData = JSON.parse(fs.readFileSync(modelsJsonPath, 'utf8')); } catch {}
      const backupPath = `${modelsJsonPath}.bak.${new Date().toISOString().replace(/[:.]/g, '-')}`;
      try {
        if (fs.existsSync(modelsJsonPath)) fs.copyFileSync(modelsJsonPath, backupPath);
      } catch (e) {
        return res.status(500).json({ error: `Failed to create backup: ${e.message}` });
      }
      modelsData.providers = modelsData.providers || {};
      modelsData.providers[provider] = modelsData.providers[provider] || {};
      modelsData.providers[provider].apiKey = apiKey;
      writeJsonAtomic(modelsJsonPath, modelsData, { mode: 0o600 });
    } else {
      // Write to auth-profiles.json (anthropic, openai, moonshot, google)
      const loaded = loadOpenclawAuthProfilesSafe();
      const authPath = loaded.authPath;
      const before = loaded.data;
      const mode = loaded.mode || 0o600;

      const backupPath = `${authPath}.bak.${new Date().toISOString().replace(/[:.]/g, '-')}`;
      try {
        if (fs.existsSync(authPath)) fs.copyFileSync(authPath, backupPath);
        else fs.writeFileSync(backupPath, JSON.stringify(before, null, 2) + '\n', 'utf8');
        try { fs.chmodSync(backupPath, mode); } catch {}
      } catch (e) {
        return res.status(500).json({ error: `Failed to create backup: ${e.message}` });
      }

      const profileId = `${provider}:default`;
      before.profiles = before.profiles || {};
      before.lastGood = before.lastGood || {};
      before.profiles[profileId] = { type: 'api_key', provider, key: apiKey };
      before.lastGood[provider] = profileId;
      writeJsonAtomic(authPath, before, { mode });
    }

    const profileId = usesModelsJson ? `models.json:${provider}` : `${provider}:default`;

    // Restart gateway so the running agent picks up the new key deterministically.
    // Prefer OpenClaw CLI if available; fall back to systemd (common in server environments).
    let restart = { ok: false, attempts: [] };
    const restartCmds = [
      process.env.OPENCLAW_RESTART_CMD,
      'openclaw gateway restart',
      'systemctl --user restart openclaw-gateway.service',
      'systemctl restart openclaw-gateway.service'
    ].filter(Boolean);

    for (const cmd of restartCmds) {
      try {
        const out = execSync(cmd, { stdio: ['ignore', 'pipe', 'pipe'], timeout: 60000, shell: '/bin/bash' });
        restart = { ok: true, cmd, output: out.toString().slice(-2000) };
        break;
      } catch (e) {
        restart.attempts.push({ cmd, error: String(e?.message || e) });
      }
    }

    if (!restart.ok) {
      restart.hint = 'Restart the OpenClaw gateway so it picks up the new auth profile (e.g. openclaw gateway restart)';
    }

    res.json({
      success: true,
      provider,
      profileId,
      ...(typeof authPath !== 'undefined' ? { authProfilesPath: authPath } : {}),
      ...(typeof backupPath !== 'undefined' ? { backupPath } : {}),
      pushedKeyPreview: maskSecret(apiKey),
      restart
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/credentials/:id', requireAuth, async (req, res) => {
  const credential = getCredential(req.params.id);
  if (!credential) {
    return res.status(404).json({ error: 'Credential not found' });
  }
  
  const schema = SERVICE_SCHEMAS[credential._package];

  // Option D: For OAuth services, auto-resolve a live bearer token as primaryKey
  // Agent sees no difference between OAuth and static-key services
  let primaryKey = resolvePrimaryKey(credential._package, credential.fields);
  let authNote;
  if (schema?.auth === 'oauth2') {
    try {
      const token = await resolveOAuthToken(req.params.id, credential);
      if (token) {
        primaryKey = token.token;
        authNote = { type: 'oauth2', cached: token.cached, expiresAt: token.expiresAt };
      }
    } catch (err) {
      authNote = { type: 'oauth2', error: err.message };
      // Fall through — primaryKey stays as static field value (clientId etc.)
    }
  }

  const response = {
    id: req.params.id,
    name: credential._name,
    packageId: credential._package,
    primaryCategory: credential._primaryCategory || schema?.category || 'custom',
    labels: Array.isArray(credential._labels) && credential._labels.length
      ? credential._labels
      : (Array.isArray(schema?.labels) && schema.labels.length ? schema.labels : [schema?.category || 'custom']),
    schema,
    fields: credential.fields,
    flatFields: flattenFields(credential.fields),
    primaryKey,
    usage: buildUsageExample(credential._package, credential.fields)
  };
  if (authNote) response.auth = authNote;
  res.json(response);
});

// Usage example for a credential
app.get('/api/credentials/:id/usage', requireAuth, (req, res) => {
  const credential = getCredential(req.params.id);
  if (!credential) {
    return res.status(404).json({ error: 'Credential not found' });
  }

  res.json({
    id: req.params.id,
    packageId: credential._package,
    usage: buildUsageExample(credential._package, credential.fields)
  });
});

// Example definition with parameter schema
app.get('/api/credentials/:id/example', requireAuth, (req, res) => {
  const credential = getCredential(req.params.id);
  if (!credential) {
    return res.status(404).json({ error: 'Credential not found' });
  }

  const def = getExampleDefinition(credential._package, credential.fields);
  res.json({
    id: req.params.id,
    packageId: credential._package,
    example: {
      title: def.title,
      summary: def.summary,
      params: def.params,
      expected: def.expected,
      commonError: def.commonError,
      docs: def.docs
    }
  });
});

// Render example (safe preview + copy curl)
app.post('/api/credentials/:id/example/render', requireAuth, (req, res) => {
  try {
    const credential = getCredential(req.params.id);
    if (!credential) {
      return res.status(404).json({ error: 'Credential not found' });
    }

    const def = getExampleDefinition(credential._package, credential.fields);
    const rendered = renderRequest(def, req.body?.params || {});
    res.json({
      id: req.params.id,
      packageId: credential._package,
      rendered: redactForDisplay(rendered),
      curl: toCurl(redactForDisplay(rendered))
    });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Run example server-side (fast path)
app.post('/api/credentials/:id/example/run', requireAuth, async (req, res) => {
  try {
    const credential = getCredential(req.params.id);
    if (!credential) {
      return res.status(404).json({ error: 'Credential not found' });
    }

    const def = getExampleDefinition(credential._package, credential.fields);
    const rendered = renderRequest(def, req.body?.params || {});
    const result = await runRenderedRequest(rendered, 15000);

    res.json({
      id: req.params.id,
      packageId: credential._package,
      request: {
        method: rendered.method,
        url: rendered.url,
        headers: redactForDisplay(rendered).headers
      },
      response: result
    });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Update credential (fields or name, merge mode)
app.put('/api/credentials/:id', requireAuth, (req, res) => {
  try {
    const { name, fields, labels } = req.body;
    const credential = updateCredential(req.params.id, { name, fields, labels, replaceFields: false });
    generateToolsMd();
    res.json({ success: true, credential });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Replace all fields for a credential (full edit mode)
app.put('/api/credentials/:id/fields', requireAuth, (req, res) => {
  try {
    const { fields } = req.body;
    if (!fields || typeof fields !== 'object') {
      return res.status(400).json({ error: 'fields object required' });
    }

    const credential = updateCredential(req.params.id, { fields, replaceFields: true });
    generateToolsMd();
    res.json({ success: true, credential });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Rename credential
app.put('/api/credentials/:id/rename', requireAuth, (req, res) => {
  try {
    const { name } = req.body;
    if (!name) {
      return res.status(400).json({ error: 'name required' });
    }
    
    const credential = updateCredential(req.params.id, { name });
    generateToolsMd();
    res.json({ success: true, credential });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ─── OAuth Token Resolution ────────────────────────────────────────────────
// Shared token cache + resolver used by both GET /credentials/:id (Option D)
// and GET /credentials/:id/token (explicit).
// Cache: tokens cached in memory until 60s before expiry.
const _tokenCache = {};

/**
 * Resolve an OAuth bearer token for a credential.
 * Returns { token, expiresAt (ISO), cached (bool) } or throws on failure.
 * Currently supports: amadeus (client_credentials grant).
 * Add new OAuth services here as needed.
 */
async function resolveOAuthToken(credentialId, credential) {
  const pkg = credential._package;
  const f = flattenFields(credential.fields);

  // Return cached token if still valid (60s buffer)
  const cached = _tokenCache[credentialId];
  if (cached && cached.expiresAt > Date.now() + 60000) {
    return { token: cached.token, expiresAt: new Date(cached.expiresAt).toISOString(), cached: true };
  }

  // ── Amadeus: client_credentials grant ──
  if (pkg === 'amadeus') {
    const base = f.environment === 'production'
      ? 'https://api.amadeus.com'
      : 'https://test.api.amadeus.com';
    const body = `grant_type=client_credentials&client_id=${encodeURIComponent(f.clientId)}&client_secret=${encodeURIComponent(f.clientSecret)}`;
    const resp = await fetch(`${base}/v1/security/oauth2/token`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body
    });
    const data = await resp.json();
    if (!data.access_token) {
      throw new Error(`Token exchange failed: ${JSON.stringify(data)}`);
    }
    const expiresAt = Date.now() + (data.expires_in || 1799) * 1000;
    _tokenCache[credentialId] = { token: data.access_token, expiresAt };
    return { token: data.access_token, expiresAt: new Date(expiresAt).toISOString(), cached: false };
  }

  // Add more OAuth providers here:
  // if (pkg === 'some_other_service') { ... }

  throw new Error(`OAuth token exchange not implemented for package: ${pkg}`);
}

// Explicit /token endpoint — still available for manual/debug use
app.get('/api/credentials/:id/token', requireAuth, async (req, res) => {
  const credential = getCredential(req.params.id);
  if (!credential) return res.status(404).json({ error: 'Credential not found' });

  try {
    const result = await resolveOAuthToken(req.params.id, credential);
    res.json({ ...result, tokenType: 'Bearer' });
  } catch (err) {
    res.status(err.message.includes('not implemented') ? 400 : 502).json({ error: err.message });
  }
});

// Delete credential
app.delete('/api/credentials/:id', requireAuth, (req, res) => {
  const success = deleteCredential(req.params.id);
  if (success) {
    generateToolsMd();
    res.json({ success: true, message: 'Credential deleted' });
  } else {
    res.status(404).json({ error: 'Credential not found' });
  }
});

// Validate credential
app.post('/api/credentials/:id/validate', requireAuth, async (req, res) => {
  const credential = getCredential(req.params.id);
  if (!credential) {
    return res.status(404).json({ error: 'Credential not found' });
  }
  
  const validator = VALIDATORS[credential._package];
  if (!validator) {
    return res.json({ valid: null, message: 'No validation configured' });
  }
  
  try {
    const result = await validator(credential.fields);
    // Invalidate cached health so the dashboard reflects the latest test result on refresh.
    try { if (fs.existsSync(HEALTH_CACHE_PATH)) fs.unlinkSync(HEALTH_CACHE_PATH); } catch {}
    res.json(result);
  } catch (err) {
    try { if (fs.existsSync(HEALTH_CACHE_PATH)) fs.unlinkSync(HEALTH_CACHE_PATH); } catch {}
    res.json({ valid: false, message: err.message });
  }
});

// Protected pages
app.get('/', requireAuthPage, (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/service/:id', requireAuthPage, (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Static files (after protected routes, only for non-protected assets)
// Explicitly serve login.html without auth
app.get('/login.html', (req, res) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

// Start server
function startServer() {
  const [host, portStr] = CONFIG.bind.split(':');
  const port = parseInt(portStr) || 8080;
  
  const serverCallback = () => {
    console.log(`
╔══════════════════════════════════════════════════════════╗
║  OpenClaw Tools Config Server v${TOOLS_SERVER_VERSION}                     ║
╠══════════════════════════════════════════════════════════╣
║  URL:      http${CONFIG.https ? 's' : ''}://${host}:${port}                    ║
║  Password: ${CONFIG.password.padEnd(42)} ║
${CONFIG.temp ? `║  Temp mode: Server stops in ${CONFIG.temp} minutes${' '.repeat(17 - CONFIG.temp.toString().length)} ║\n` : ''}╚══════════════════════════════════════════════════════════╝

Registry: ${REGISTRY_PATH}
    `);
    
    if (CONFIG.temp) {
      setTimeout(() => {
        console.log('\n⏰ Temp time expired. Shutting down...');
        process.exit(0);
      }, CONFIG.temp * 60 * 1000);
    }
  };
  
  if (CONFIG.https) {
    // Use Tailscale cert if available, otherwise generate self-signed
    const tailscaleCertDir = path.join(require('os').homedir(), '.openclaw', 'certs');
    const tailscaleHostname = require('os').hostname();
    const tailscaleKeyPath = path.join(tailscaleCertDir, `${tailscaleHostname}.taile54a5b.ts.net.key`);
    const tailscaleCertPath = path.join(tailscaleCertDir, `${tailscaleHostname}.taile54a5b.ts.net.crt`);

    let keyPath, certPath;
    if (fs.existsSync(tailscaleKeyPath) && fs.existsSync(tailscaleCertPath)) {
      console.log('Using Tailscale certificate for trusted HTTPS...');
      keyPath = tailscaleKeyPath;
      certPath = tailscaleCertPath;
    } else {
      // Fall back to self-signed cert
      const certDir = path.join(__dirname, '.certs');
      if (!fs.existsSync(certDir)) fs.mkdirSync(certDir, { recursive: true });
      keyPath = path.join(certDir, 'key.pem');
      certPath = path.join(certDir, 'cert.pem');
      if (!fs.existsSync(keyPath) || !fs.existsSync(certPath)) {
        console.log('Generating self-signed certificate (valid for 1 year)...');
        const { execSync } = require('child_process');
        execSync(`openssl req -x509 -newkey rsa:2048 -keyout ${keyPath} -out ${certPath} -days 365 -nodes -subj "/CN=localhost" 2>/dev/null`);
      }
    }

    https.createServer({
      key: fs.readFileSync(keyPath),
      cert: fs.readFileSync(certPath)
    }, app).listen(port, host, serverCallback);

    // Also bind a plain HTTP listener on localhost for agent use.
    // No TLS needed — traffic never leaves the machine.
    const LOCAL_AGENT_PORT = parseInt(process.env.TOOLS_AGENT_PORT || '8080');
    require('http').createServer(app).listen(LOCAL_AGENT_PORT, '127.0.0.1', () => {
      console.log(`Agent HTTP endpoint: http://127.0.0.1:${LOCAL_AGENT_PORT} (local only, no TLS)`);
    });
  } else {
    app.listen(port, host, serverCallback);
  }
}

startServer();