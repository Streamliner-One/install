#!/usr/bin/env bash
set -euo pipefail

# OpenClaw Tools Config Server updater
# - Pulls latest code
# - Installs production deps
# - Restarts service/process

INSTALL_DIR="${TOOLS_INSTALL_DIR:-/opt/tools-config}"
APP_DIR="$INSTALL_DIR/tools-server"
SERVICE_NAME="tools-config"

if [[ "${1:-}" == "--local-dev" ]]; then
  APP_DIR="$(cd "$(dirname "$0")" && pwd)"
fi

log() { printf "[update] %s\n" "$*"; }
warn() { printf "[warn] %s\n" "$*"; }

if [[ ! -d "$APP_DIR" ]]; then
  echo "App directory not found: $APP_DIR"
  echo "Tip: set TOOLS_INSTALL_DIR or run with --local-dev"
  exit 1
fi

cd "$APP_DIR"

BRANCH="$(git rev-parse --abbrev-ref HEAD || echo main)"
log "Updating in $APP_DIR (branch: $BRANCH)"

git fetch origin
LOCAL_SHA="$(git rev-parse HEAD)"
REMOTE_SHA="$(git rev-parse origin/$BRANCH)"

if [[ "$LOCAL_SHA" == "$REMOTE_SHA" ]]; then
  log "Already up to date."
else
  log "Pulling latest changes..."
  git pull --ff-only origin "$BRANCH"
fi

if command -v npm >/dev/null 2>&1; then
  if [[ -f package-lock.json ]]; then
    log "Installing dependencies (npm ci --omit=dev)..."
    npm ci --omit=dev
  else
    log "Installing dependencies (npm install --production)..."
    npm install --production
  fi
fi

if command -v systemctl >/dev/null 2>&1 && systemctl list-unit-files | grep -q "^${SERVICE_NAME}\.service"; then
  log "Restarting systemd service: $SERVICE_NAME"
  sudo systemctl restart "$SERVICE_NAME"
  sudo systemctl --no-pager --full status "$SERVICE_NAME" | sed -n '1,12p'
else
  warn "No systemd service found. Trying manual process restart."
  BIND_ADDR="${TOOLS_BIND:-mel.taile54a5b.ts.net:8443}"
  pkill -f "server.js --bind" || true
  nohup node server.js --bind "$BIND_ADDR" --https --password "${TOOLS_PASSWORD:-mel2026}" >/tmp/tools-config.log 2>&1 &
  sleep 1
  pgrep -af "server.js --bind" | head -1 || true
fi

log "Update complete."
