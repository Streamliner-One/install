# Scope & Privacy Extension — Design Spec

**Status:** Draft
**Date:** 2026-03-18
**Author:** Mel + Alex

---

## Problem

Rules in SOUL.md, AGENTS.md, and the tools server are flat strings with implicit scope. The model infers applicability, leading to:
- Over-confirmation on routine infrastructure ops (SSH, docker, packages)
- Under-caution on novel external actions
- No declarative privacy controls on data flowing to external APIs
- Scaling problem: at 50+ rules, implicit scope becomes unmanageable

## Design Principles

1. **Domains are configurable** — different users have different action categories
2. **Tiers are fixed** — three levels map to fundamental human decision patterns
3. **Privacy is declarative** — per-integration data policies, not runtime inference
4. **Backward compatible** — existing rules without domain/tier continue to work (default to universal scope, tier 2)
5. **Single source of truth** — tools server stores everything, TOOLS.md renders it

---

## 1. Domains

### Schema

Stored in `registry.meta.domains` (same pattern as `registry.meta.intentRules`).

```json
{
  "id": "INFRA",
  "name": "Infrastructure",
  "description": "SSH, docker, packages, services, files, APIs on own systems",
  "sensitivity": "private",
  "defaultTier": 1,
  "examples": ["ssh into server", "docker compose pull", "apt update", "restart service"],
  "createdAt": "2026-03-18T15:00:00Z",
  "updatedAt": "2026-03-18T15:00:00Z"
}
```

### Fields

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `id` | string | yes | Uppercase identifier, used in rule references |
| `name` | string | yes | Human-readable label |
| `description` | string | yes | What actions belong here |
| `sensitivity` | enum | yes | `public` / `private` / `controlled` / `confidential` |
| `defaultTier` | 1-3 | yes | Default decision tier for actions in this domain |
| `examples` | string[] | no | Example phrases/actions for this domain |

### Sensitivity Levels

| Level | Meaning | Data handling |
|-------|---------|---------------|
| `public` | No restrictions | Can be sent to any registered integration |
| `private` | Internal only | Can be sent to registered integrations, not logged externally |
| `controlled` | Requires confirmation | Agent must confirm before sending to external APIs |
| `confidential` | Never egress without explicit approval | Blocked from external APIs unless user explicitly approves per-instance |

### Default Domains (shipped with system)

```json
[
  {
    "id": "INFRA",
    "name": "Infrastructure",
    "description": "SSH, docker, packages, services, files, own-system APIs",
    "sensitivity": "private",
    "defaultTier": 1,
    "examples": ["ssh into server", "docker compose", "systemctl restart", "apt update"]
  },
  {
    "id": "COMMS",
    "name": "Communications",
    "description": "Emails, messages to others, posts, anything seen by another person",
    "sensitivity": "controlled",
    "defaultTier": 3,
    "examples": ["send email", "post tweet", "message someone", "reply to client"]
  },
  {
    "id": "FINANCIAL",
    "name": "Financial",
    "description": "Payments, purchases, subscriptions, billing actions",
    "sensitivity": "confidential",
    "defaultTier": 3,
    "examples": ["charge card", "subscribe", "make payment", "refund"]
  },
  {
    "id": "DATA_READ",
    "name": "Data Read",
    "description": "Reading from datastores, APIs, files — no state change",
    "sensitivity": "private",
    "defaultTier": 1,
    "examples": ["query database", "fetch API", "read file", "search"]
  },
  {
    "id": "DATA_WRITE",
    "name": "Data Write",
    "description": "Writing to datastores, files, configs — state changes",
    "sensitivity": "private",
    "defaultTier": 2,
    "examples": ["update config", "write file", "create record", "delete entry"]
  },
  {
    "id": "RECALL",
    "name": "Recall",
    "description": "Retrieving facts from memory — names, dates, numbers, past decisions",
    "sensitivity": "private",
    "defaultTier": 1,
    "examples": ["what was the date", "who said", "what did we decide"]
  },
  {
    "id": "DESIGN",
    "name": "Design & Architecture",
    "description": "System design, new integrations, architectural decisions",
    "sensitivity": "private",
    "defaultTier": 3,
    "examples": ["redesign the schema", "add new integration", "change architecture"]
  },
  {
    "id": "RESPONSE",
    "name": "Response Style",
    "description": "Tone, format, language, structure of agent replies",
    "sensitivity": "public",
    "defaultTier": 1,
    "examples": ["be more concise", "use bullet points", "switch to formal tone"]
  },
  {
    "id": "SAFETY",
    "name": "Safety & Security",
    "description": "Security operations, credential handling, trust boundaries",
    "sensitivity": "confidential",
    "defaultTier": 2,
    "examples": ["rotate key", "check permissions", "review access"]
  }
]
```

### API

```
GET    /api/domains          → { domains: [...] }
POST   /api/domains          → upsert domain (by id)
DELETE  /api/domains/:id      → delete domain
```

---

## 2. Tiers (Fixed)

Not configurable. Hardcoded in generator, rendered into TOOLS.md.

| Tier | Name | Behavior | When |
|------|------|----------|------|
| **1** | Execute & Report | Do it, tell user what you did | Reversible, own systems, documented procedures |
| **2** | Confirm Once | State intent, get one OK, then execute | Irreversible but private (delete files, schema changes, credential rotation) |
| **3** | Always Align | Present findings + recommendation, act only after explicit go-ahead | Public-facing, financial, contacts others, architectural decisions |

### Tier override logic

1. If a rule specifies `tier` explicitly → use that
2. Else if a rule specifies `domain` → use `domain.defaultTier`
3. Else → default to tier 2 (confirm once)

This means existing rules without domain/tier behave conservatively (tier 2) until explicitly scoped.

---

## 3. Rule Schema Extension

### New optional fields on intent rules

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `domain` | string[] | `[]` (universal) | Which domains this rule applies to |
| `excludes` | string[] | `[]` | Which domains this rule explicitly does NOT apply to |
| `tier` | 1-3 | null (inherit from domain) | Override decision tier |

### Example: existing rule with scope added

**Before:**
```json
{
  "id": "composure_protocol",
  "type": "behavior",
  "triggers": ["fix this", "this is broken", ...],
  "notes": "MANDATORY: Apply SEA..."
}
```

**After:**
```json
{
  "id": "composure_protocol",
  "type": "behavior",
  "triggers": ["fix this", "this is broken", ...],
  "domain": ["DESIGN", "COMMS", "FINANCIAL"],
  "excludes": ["INFRA", "DATA_READ", "RESPONSE"],
  "tier": 3,
  "notes": "MANDATORY: Apply SEA..."
}
```

Now the model knows: SEA applies to design and external actions, not to infrastructure ops or data reads.

### Backward compatibility

- `domain: []` or missing → universal (applies to all domains)
- `excludes: []` or missing → no exclusions
- `tier: null` or missing → inherit from domain default, or tier 2 if no domain

---

## 4. Data Policy (Per-Integration Privacy)

### Schema

Added to service schemas in `schema.js` and/or stored per-credential in the registry.

```json
{
  "dataPolicy": {
    "allowedInputs": ["queries", "dates", "public_info", "location"],
    "blockedInputs": ["client_pii", "passport_data", "financial_records", "credentials"],
    "requiresConfirmation": false,
    "auditLevel": "standard"
  }
}
```

### Fields

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `allowedInputs` | string[] | `["*"]` | Data types this integration may receive |
| `blockedInputs` | string[] | `[]` | Data types that must never be sent to this integration |
| `requiresConfirmation` | boolean | false | Always confirm before sending data, regardless of tier |
| `auditLevel` | enum | `"standard"` | `none` / `standard` / `full` — logging verbosity |

### Data type taxonomy

Predefined categories the model recognizes:

| Type | Description | Examples |
|------|-------------|---------|
| `queries` | Search queries, questions | "best hotel in Zurich" |
| `dates` | Dates, schedules | "2026-04-01" |
| `public_info` | Publicly available information | Company names, city names |
| `location` | Geographic data | Coordinates, city names |
| `client_pii` | Client personal information | Names, emails, phone numbers |
| `passport_data` | Identity documents | Passport numbers, ID numbers, expiry dates |
| `financial_records` | Financial data | Account numbers, transactions, revenue |
| `credentials` | Secrets | API keys, passwords, tokens |
| `business_internal` | Internal business data | Ticket contents, commissions, margins |
| `health_data` | Health/biometric data | Sleep scores, HRV, medical info |

### Default policies per integration

| Integration | Allowed | Blocked | Confirm |
|-------------|---------|---------|---------|
| Brave Search | queries, dates, public_info, location | client_pii, passport_data, financial_records, credentials | no |
| Perplexity | queries, dates, public_info | client_pii, passport_data, credentials | no |
| Amadeus | dates, location, public_info | passport_data, credentials | no |
| Groove | client_pii, business_internal, dates | credentials | no |
| Google Workspace | client_pii, business_internal, dates, queries | credentials | yes (for sends) |
| Tavily | queries, dates, public_info, location | client_pii, passport_data, credentials | no |
| Todoist | queries, dates, public_info | client_pii, passport_data, credentials | no |
| ElevenLabs | queries, public_info | client_pii, passport_data, credentials | no |
| NewsAPI | queries, dates, public_info | client_pii, credentials | no |
| Oura | dates, health_data | credentials | no |

---

## 5. Generator Output

### New sections in TOOLS.md

**After the Quick Routing Index, before Agent-Callable APIs:**

```markdown
## 🏷️ Domains

| Domain | Sensitivity | Default Tier | Description |
|--------|-------------|--------------|-------------|
| INFRA | private | 1 — Execute & Report | SSH, docker, packages, own-system APIs |
| COMMS | controlled | 3 — Always Align | Emails, messages, posts to others |
| ... | ... | ... | ... |

## 🔒 Decision Tiers

| Tier | Action | When |
|------|--------|------|
| 1 | Execute & Report | Reversible, own systems, documented |
| 2 | Confirm Once | Irreversible but private |
| 3 | Always Align | Public-facing, financial, contacts others |
```

**On each rule (in the detailed section):**

```markdown
#### `composure_protocol`
- **Triggers:** "fix this", "this is broken", ...
- **Domain:** DESIGN, COMMS, FINANCIAL
- **Excludes:** INFRA, DATA_READ, RESPONSE
- **Tier:** 3 — Always Align
- **Notes:** Apply SEA...
```

**On each integration (in Agent-Callable APIs):**

```markdown
### ✈️ Amadeus
- **Data policy:** Allowed: dates, location, public_info. Blocked: passport_data, credentials.
```

---

## 6. Implementation Plan

### Phase 1 — Schema + Storage (no behavior change)

1. Add `domains` array to `registry.meta` with defaults
2. Add `domain`, `excludes`, `tier` as optional fields in `upsertIntentRule` validation
3. Add `dataPolicy` as optional field in service schemas
4. Create `/api/domains` CRUD endpoints
5. Update generator to render domains table, tier reference, and per-rule scope
6. Regenerate TOOLS.md

**Result:** Model sees scope info in context but no enforcement logic yet. Behavior improves immediately through context alone — the model reads "Excludes: INFRA" and knows not to fire the rule for infrastructure ops.

### Phase 2 — Migration (assign scopes to existing rules)

7. Assign domain/tier/excludes to all 25 existing rules
8. Assign dataPolicy to all active integrations
9. Verify TOOLS.md renders correctly with all new fields

### Phase 3 — Privacy enforcement (optional, future)

10. Add pre-flight middleware in tools server that validates data against integration policies
11. Add audit logging for blocked/flagged requests
12. Add `/api/audit` endpoint to query audit log

Phase 3 is optional because Phase 1 already delivers most of the value — the model is the enforcement layer, and explicit scope in context is sufficient for a single-user system. Phase 3 adds programmatic enforcement for multi-tenant or unsupervised scenarios.

---

## 7. File Changes

| File | Change |
|------|--------|
| `lib/registry.js` | Add domain CRUD functions, update `upsertIntentRule` to accept new fields |
| `lib/generator.js` | Render domains table, tier reference, per-rule scope, per-integration data policy |
| `schema.js` | Add `dataPolicy` field to service schemas |
| `server.js` | Add `/api/domains` endpoints, pass new fields through rule endpoints |
| `TOOLS.md` | Auto-generated — gains domains, tiers, scoped rules, data policies |

---

## Open Questions

1. **Should dataPolicy live on the schema (static) or the credential (per-instance)?**
   Recommendation: schema for defaults, credential for overrides. A user might have two Notion instances with different policies.

2. **Should the audit log be persistent (file/DB) or in-memory?**
   Recommendation: append-only JSONL file at `~/.openclaw/logs/privacy-audit.jsonl`. Cheap, greppable, rotatable.

3. **Should domain assignment be suggested automatically based on integration category?**
   Recommendation: yes — when a rule references a target integration, the generator could suggest domains based on the integration's category (travel → DATA_READ, messaging → COMMS). But always allow override.
