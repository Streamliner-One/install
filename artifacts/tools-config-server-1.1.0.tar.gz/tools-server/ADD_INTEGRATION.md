# How to Add a New Integration

Authoritative step-by-step guide. Read this first — do not discover the process by trial and error.

---

## Overview: 4 things to do

1. Create `packages/<id>/package.json` — schema, fields, labels, skill routing
2. Add a usage definition to `lib/usage.js` — the runnable curl example for TOOLS.md
3. Add a validator to `server.js` → `VALIDATORS` — powers the "Test connection" button
4. Restart + POST real credential via API (no placeholders)

---

## Step 1 — Package schema (`packages/<id>/package.json`)

```json
{
  "id": "tavily",
  "name": "Tavily",
  "version": "1.0.0",
  "description": "AI-optimised web search for LLM agents",
  "icon": "🔍",
  "category": "search",
  "author": "Streamliner One",

  "labels": ["search", "ai", "research", "web", "fresh-data", "extract", "crawl"],

  "skill": {
    "useWhen": "search with tavily, tavily search, extract page content, crawl this site, deep research",
    "intents": ["web_search", "ai_research"],
    "params": ["query", "search_depth (basic|advanced)", "max_results"],
    "fallback": "brave",
    "note": "Auth via api_key in request body — not Authorization header."
  },

  "fields": {
    "apiKey": {
      "label": "API Key",
      "type": "password",
      "required": true,
      "sensitive": true,
      "placeholder": "tvly-xxxx",
      "help": "Get your key at https://app.tavily.com"
    }
  }
}
```

**Key fields:**
- `skill.useWhen` — comma-separated triggers → appear in TOOLS.md routing table
- `skill.intents` — semantic tags for the intent router
- `skill.fallback` — service to use if this one fails
- `labels` — filtering/tagging in the dashboard

Note: the `validation` block in `package.json` is not used by the server. Validation lives in `server.js` (step 3).

---

## Step 2 — Usage example (`lib/usage.js`)

⚠️ **The `usage` block in `package.json` is NOT read by the server.** The curl example in TOOLS.md comes exclusively from the hardcoded `defs` object in `lib/usage.js`.

Add an entry to the `defs` object (find the correct section by category):

```javascript
tavily: {
  title: 'Tavily — AI web search',
  summary: 'AI-optimised search. Auth via api_key in body (not header).',
  allowedHosts: ['api.tavily.com'],
  params: [
    { key: 'query',        type: 'string', required: true,  default: 'latest AI news' },
    { key: 'search_depth', type: 'string', required: false, default: 'basic' },
    { key: 'max_results',  type: 'int',    required: false, default: 5 }
  ],
  request: {
    method: 'POST',
    url: 'https://api.tavily.com/search',
    headers: { 'Content-Type': 'application/json' },
    body: {
      api_key: key('apiKey'),   // key() reads the stored credential value
      query: '{{query}}',
      search_depth: '{{search_depth}}',
      max_results: '{{max_results}}'
    }
  },
  expected: 'JSON with results[].title, results[].url, results[].content, results[].score',
  commonError: '401 invalid api_key; 429 rate limit',
  docs: 'https://docs.tavily.com/documentation/api-reference/introduction'
},
```

**Redaction:** `redactForDisplay()` auto-redacts header and body fields matching `api_key|api.?key|token|secret|authorization|password`. Keys in the request body are safe.

---

## Step 3 — Validator (`server.js` → `VALIDATORS`)

Add to the `VALIDATORS` object in `server.js`. Find the right section by category (search validators are near `brave`):

```javascript
tavily: async (fields) => {
  const apiKey = fields.apiKey?.value;
  if (!apiKey) return { valid: false, message: 'API Key required' };

  try {
    const https = require('https');
    const body = JSON.stringify({ api_key: apiKey, query: 'test', max_results: 1 });
    const response = await new Promise((resolve, reject) => {
      const req = https.request('https://api.tavily.com/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) }
      }, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => resolve({ status: res.statusCode, data }));
      });
      req.on('error', reject);
      req.setTimeout(10000, () => reject(new Error('Timeout')));
      req.write(body);
      req.end();
    });

    if (response.status === 200) return { valid: true, message: 'Connected to Tavily ✓' };
    if (response.status === 401) return { valid: false, message: 'Invalid API key (401)' };
    if (response.status === 429) return { valid: true, message: 'Key valid but rate-limited (429)' };
    return { valid: false, message: `HTTP ${response.status}` };
  } catch (err) {
    return { valid: false, message: err.message };
  }
},
```

Return format: `{ valid: true|false|null, message: string }`. Use `null` for "can't verify" (e.g. CLI-based services).

---

## Step 4 — Restart + register credential

Only add a credential when you have the real key. No placeholders.

```bash
cd ~/.openclaw/workspace/tools-server && ./restart.sh
sleep 3

COOKIE=$(mktemp); trap "rm -f $COOKIE" EXIT
curl -s -c "$COOKIE" -X POST http://localhost:8080/api/login \
  -H 'Content-Type: application/json' -d '{"password":"mel2026"}' >/dev/null

# Verify package loaded
curl -s -b "$COOKIE" http://localhost:8080/api/services | \
  python3 -c "import sys,json; d=json.load(sys.stdin); print([s['id'] for s in d.get('services',[])])"

# Register credential with real key
curl -s -b "$COOKIE" -X POST http://localhost:8080/api/credentials \
  -H 'Content-Type: application/json' \
  -d '{"packageId":"tavily","name":"Tavily","fields":{"apiKey":"tvly-REAL_KEY"}}'
```

TOOLS.md regenerates automatically.

---

## Optional: intent rule

Only needed for data-write actions or special routing beyond `skill.useWhen`.

```bash
curl -s -b "$COOKIE" -X POST http://localhost:8080/api/intent-rules \
  -H 'Content-Type: application/json' \
  -d '{
    "id": "tavily_search",
    "type": "intent",
    "intent": "tavily_search",
    "description": "AI web search via Tavily",
    "triggers": ["search with tavily", "tavily search", "deep research"],
    "action": "call_api",
    "target": "tavily",
    "notes": "POST to api.tavily.com/search; api_key goes in request body not header"
  }'
```

---

## What NOT to do

- ❌ `CUSTOM_SERVICES.md` describes `custom-services.json` — **ignored by the server**
- ❌ Do not edit `tools-registry.json` directly — server-managed
- ❌ Do not add to `registry.services` — server uses `registry.credentials`
- ❌ Do not put the curl example only in `package.json usage` block — server doesn't read it
- ❌ Do not register a credential with a placeholder key — misleading, and the dashboard shows it as configured

---

## How TOOLS.md is generated (mental model)

```
packages/<id>/package.json
  └─ skill.useWhen       → routing table row
  └─ skill.intents       → intent labels
  └─ skill.params        → param hints
  └─ skill.fallback      → fallback service
  └─ category/icon/name  → display

lib/usage.js → defs[id]
  └─ request + params    → curl example (key redacted)
  └─ commonError         → error notes
  └─ docs                → link

server.js → VALIDATORS[id]
  └─ async fn(fields)    → "Test connection" button

registry.credentials[id]
  └─ fields.apiKey.value → injected into curl at render time
```

If a package has no entry in `defs`: TOOLS.md shows *"No runnable example defined."*
If a package has no entry in `VALIDATORS`: dashboard "Test" button returns *"No validation configured."*
