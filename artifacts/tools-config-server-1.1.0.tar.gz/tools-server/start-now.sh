#!/bin/bash
cd /home/alex/.openclaw/workspace/tools-server
pkill -9 -f "server.js" 2>/dev/null
sleep 1
node server.js --bind mel.taile54a5b.ts.net:8443 --https --password mel2026 > /tmp/TS.log 2>&1 &
echo "Started with PID $!"
sleep 2
echo "Status:"
curl -s -k -o /dev/null -w "%{http_code}\n" https://mel.taile54a5b.ts.net:8443/login.html