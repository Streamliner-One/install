# Release Checklist — tools-config-server

Run this top to bottom every release. No skipping steps, no back-and-forth.

---

## Adding a New Credential Type

Every new credential type needs **all** of these to be fully wired. Missing any one makes it invisible to the agent, TOOLS.md, or the intent router. Use this as a checklist every time.

### Package Definition (`packages/<id>/package.json`)

- [ ] **`id`** — unique package identifier (e.g. `readwise`, `obsidian-sync`)
- [ ] **`name`** — human-readable name (no implementation details like "Headless")
- [ ] **`description`** — one-line description for TOOLS.md
- [ ] **`icon`** — emoji for the routing table
- [ ] **`category`** — e.g. `knowledge`, `travel`, `voice`, `productivity`
- [ ] **`fields`** — all credential fields with `label`, `type`, `required`, `sensitive`, `placeholder`, `help`
- [ ] **`skill`** block (required for agent-callable services):
  ```json
  "skill": {
    "useWhen": "comma-separated trigger phrases",
    "intents": ["intent_1", "intent_2"],
    "params": ["param1", "param2 (optional)"],
    "fallback": "brave or none",
    "note": "Optional context for the agent"
  }
  ```
  Without `skill`, the service appears under "Infrastructure" in TOOLS.md — invisible to the intent router.
- [ ] **`validation`** — either `{ "type": "http", ... }` (declarative) or `{ "type": "javascript", "entry": "validator.js" }` (custom)

### Validator (`packages/<id>/validator.js`)

- [ ] Exports `validate(fields)` → returns `{ valid: true/false, message: "..." }`
- [ ] Handles missing fields gracefully
- [ ] Uses a lightweight API probe (not a full query)

### Usage Example (`lib/usage.js`)

- [ ] Add an entry in `EXAMPLES` for the package ID
- [ ] Include `title`, `summary`, `method`, `url`, `headers`, `params` with defaults
- [ ] Verify with: `GET /api/credentials/:id/usage` and `POST /api/credentials/:id/example/run`

### Intent Router (`router.json`)

- [ ] Add relevant intents pointing to the new package ID
- [ ] **Note:** Package-based credentials get timestamp-suffixed IDs (e.g. `readwise-1772811314235`). The router and usage layer must resolve both the base package ID and the suffixed credential ID.
- [ ] Place it in the correct priority order (most specific first, `brave` as fallback)
- [ ] Verify with: `GET /api/router?intent=<new_intent>`

### Schema (if not package-based)

- [ ] If adding to `schema.js` instead of `packages/`, include the `skill` block there
- [ ] Ensure it has `labels` array for dashboard category filtering

### Verification

After all the above, run this to confirm the full chain:

```bash
# 1. Package schema loaded with skill?
node -e '
  const { loadAllPackages, getPackageSchemas } = require("./lib/packages");
  loadAllPackages();
  const s = getPackageSchemas()["NEW_ID"];
  console.log(s ? `✅ ${s.name} | skill=${!!s.skill}` : "❌ MISSING");
'

# 2. Credential exists in registry?
cat ~/.openclaw/workspace/tools-registry.json | jq '.credentials | keys[]' | grep NEW_ID

# 3. Shows in TOOLS.md routing table?
node -e 'require("./lib/generator").generateToolsMd()'
grep "NEW_NAME" ~/.openclaw/workspace/TOOLS.md

# 4. Router resolves intent?
# (requires running server)
curl -sk ... "/api/router?intent=NEW_INTENT" | jq '.candidates'

# 5. Usage example works?
curl -sk ... "/api/credentials/CRED_ID/usage"

# 6. Live API query succeeds?
# Fetch the actual credential, make a real API call, confirm valid response.
# Example for Readwise:
#   TOKEN=$(curl -sk -b $COOKIE "$BASE/api/credentials/readwise-XXXXX" | jq -r '.fields.apiToken.value')
#   curl -s "https://readwise.io/api/v2/highlights/?page_size=1" -H "Authorization: Token $TOKEN" | jq '.count'
# Must return real data, not 401/403/empty.

# 7. Agent delivery simulation
# Simulate the full user-facing flow:
#   a) User intent → router resolves to correct service
#   b) Credential fetched (note: package IDs may have timestamp suffixes!)
#   c) API queried with real parameters
#   d) Response parsed and formatted for user delivery
# If ANY step fails, the integration is NOT ready to ship.
```

> ⚠️ **Steps 6–7 are mandatory.** Without them, you have a credential in a vault
> and routes in a router, but the agent can't actually USE the integration.
> This is exactly the failure mode we hit with Readwise on 2026-03-06:
> everything looked wired, but the agent defaulted to web search because
> the live query path was never tested end-to-end.

---

## 0) Pre-flight

- [ ] All changes committed locally in `tools-server/`
- [ ] `CHANGELOG.md` updated with version entry and summary of changes
- [ ] Version bumped in `package.json`: `sed -i 's/"version": "X.X.X"/"version": "X.X.Y"/' package.json`
- [ ] Run `./verify-integrations.sh` — all green before shipping

### ⚠️ Version Consistency Rule

**All three repos MUST be at the same version tag on every release:**

| Repo | What to update |
|------|----------------|
| `Streamliner-One/tools-config-server` | Server code, CHANGELOG, package.json |
| `Streamliner-One/tools` | Artifact tarball, `versions.json` (stable + latest), README if new capabilities |
| `Streamliner-One/tools-packages` | New/updated packages, or version-bump tag if no package changes |

**Both push targets:**
- `prudkov/mel-memory` (internal workspace backup)
- `Streamliner-One/*` (public repos)

### README Update Triggers

Update `install/README.md` (the public product page) when:
- [ ] New credential type / service added → update services table
- [ ] New capability or feature → update features section
- [ ] Security changes → update security section
- [ ] Breaking changes → add migration notes

Update `tools-config-server/README.md` (dev reference) when:
- [ ] New API endpoints added
- [ ] Architecture changes
- [ ] New package structure/conventions

---

## 1) `Streamliner-One/tools-config-server`

```bash
cd ~/.openclaw/workspace

# Commit everything — workspace root is the mono-repo
git add -A
git commit -m "feat/fix: short description — vX.X.Y"

# Tag
git tag vX.X.Y

# Push personal backup
git push origin master --tags

# Push to Streamliner (tools-server/ subtree → their main branch)
# ⚠️ git subtree push rejects non-fast-forward. If it fails, use the force pattern:
git subtree push --prefix=tools-server streamliner main
# If rejected (diverged):
git subtree split --prefix=tools-server -b _ts-release
git push streamliner _ts-release:main --force
git branch -D _ts-release
git push streamliner vX.X.Y   # push tag separately
```

```bash
gh release create vX.X.Y \
  --repo Streamliner-One/tools-config-server \
  --title "vX.X.Y — Short description" \
  --notes "..." \
  --latest
```

---

## 2) `Streamliner-One/tools`

```bash
# Clone fresh (or pull if already cloned)
cd /tmp && rm -rf streamliner-install
gh repo clone Streamliner-One/tools streamliner-install -- --depth=1
cd /tmp/streamliner-install
git remote set-url origin git@github.com:Streamliner-One/tools.git

# Build versioned artifact + update rolling 'main'
tar czf artifacts/tools-config-server-X.X.Y.tar.gz \
  -C ~/.openclaw/workspace \
  --exclude='tools-server/node_modules' \
  --exclude='tools-server/.health-cache.json' \
  --exclude='tools-server/certs' \
  --exclude='tools-server/*.log' \
  tools-server/
cp artifacts/tools-config-server-X.X.Y.tar.gz artifacts/tools-config-server-main.tar.gz

# Update versions.json (both channels — version AND artifact_url)
jq '.channels.stable.version="X.X.Y" |
    .channels.latest.version="X.X.Y" |
    .channels.stable.artifact_url="https://raw.githubusercontent.com/Streamliner-One/tools/main/artifacts/tools-config-server-X.X.Y.tar.gz" |
    .channels.latest.artifact_url="https://raw.githubusercontent.com/Streamliner-One/tools/main/artifacts/tools-config-server-X.X.Y.tar.gz"' \
  versions.json > /tmp/v.json && mv /tmp/v.json versions.json

# Update README channels table — ONLY the two version cells, not the whole file
# ⚠️ Do NOT use a blanket sed on version numbers — it clobbers artifact URLs and other refs
sed -i "s/| \`stable\` | [0-9]\+\.[0-9]\+\.[0-9]\+ |/| \`stable\` | X.X.Y |/" README.md
sed -i "s/| \`latest\` | [0-9]\+\.[0-9]\+\.[0-9]\+ |/| \`latest\` | X.X.Y |/" README.md

git config user.email "bot@streamliner.one" && git config user.name "Mel Bot"
git add -A
git commit -m "release: vX.X.Y — short description"
git tag vX.X.Y
git push origin main --tags
```

```bash
gh release create vX.X.Y \
  --repo Streamliner-One/tools \
  --title "vX.X.Y — Short description" \
  --notes "Synced with [tools-config-server vX.X.Y](https://github.com/Streamliner-One/tools-config-server/releases/tag/vX.X.Y)." \
  --latest
```

---

## 3) `Streamliner-One/tools-packages`

No code changes unless a package was added/modified. Always publish a matching release tag:

```bash
# Create annotated tag via API (no clone needed if no code changes)
SHA=$(gh api repos/Streamliner-One/tools-packages/git/refs/heads/main --jq '.object.sha')
gh api repos/Streamliner-One/tools-packages/git/tags \
  -X POST -f tag=vX.X.Y -f message="vX.X.Y" -f object="$SHA" -f type=commit

gh release create vX.X.Y \
  --repo Streamliner-One/tools-packages \
  --title "vX.X.Y — Synced with tools-config-server" \
  --notes "Version alignment with tools-config-server vX.X.Y. No package changes." \
  --latest
```

If packages changed: commit + push to their repo first, then release.

---

## 4) Verify — MANDATORY before declaring release done

> ⚠️ **Do not skip this step.** A pushed tag is NOT a release. All three repos need
> `gh release create` called explicitly — GitHub does not auto-create releases from tags.
> Run the checks below and confirm all three show the new version as `Latest`.

```bash
# All three releases at same version AND marked Latest?
gh release list --repo Streamliner-One/tools-config-server | head -2
gh release list --repo Streamliner-One/tools | head -2
gh release list --repo Streamliner-One/tools-packages | head -2

# Expected output — all three should show vX.X.Y with "Latest" flag:
# vX.X.Y — Description    Latest    vX.X.Y    <date>

# versions.json live and correct?
curl -s https://raw.githubusercontent.com/Streamliner-One/tools/main/versions.json
# Expected: both channels showing vX.X.Y and correct artifact_url

# README channels table updated?
curl -s https://raw.githubusercontent.com/Streamliner-One/tools/main/README.md | grep -A3 "## Channels"
# Expected: both stable and latest showing X.X.Y

# Install one-liner reachable?
curl -s https://tools.streamliner.one | head -5
# Expected: first lines of install.sh
```

**Common mistakes caught here:**
- Tag pushed but `gh release create` not called → shows as tag only, not Latest release
- `versions.json` version updated but `artifact_url` still pointing to old tarball
- `tools` or `tools-packages` still at previous version
- README channels table still showing previous version (stale docs)

---

## Notes

- **Remotes:** `origin` = `prudkov/mel-memory` (personal workspace backup), `streamliner` = `Streamliner-One/tools-config-server`. Streamliner uses `main`; our local is `master`.
- **`git subtree push` divergence:** Streamliner's `main` may have direct commits (docs, etc). Always try fast-forward first; use force pattern (split → force-push) if rejected.
- **`versions.json`:** update BOTH `version` AND `artifact_url` fields — easy to forget the URL.
- **Install repo:** clone fresh with `gh repo clone` + switch to SSH remote — avoids HTTPS auth failures.
- **README split:** `tools-config-server/README.md` = dev/contributor reference. `install/README.md` = public product page. Update install README when adding services or significant features.
- **README channels table:** Always update the `| stable |` and `| latest |` version cells in `install/README.md` on every release — even patch releases. Use the targeted `sed` lines in step 2 (not a blanket version replace). This was missed in v0.9.2 and v0.9.3, discovered in v0.9.4.
- **Never stage:** `.health-cache.json`, `server.log`, `update-run.log`, `tools-registry.json`, `node_modules`, `certs/`
- **Patch releases** (doc-only fixes): batch with next substantive change unless the fix affects install behavior.
- **`gh release create` is required for ALL THREE repos** — not just tools-config-server. Pushing a tag without a release leaves the repo showing the old version as Latest. Verify with `gh release list` after every release.
