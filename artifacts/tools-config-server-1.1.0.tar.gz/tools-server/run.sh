#!/bin/bash
set -e

PID_FILE=/tmp/tools-server.pid
BIND="mel.taile54a5b.ts.net:8443"
CHECK_URL="https://100.84.57.51:8443/login.html"

# --- Stop any existing instance ---
if [ -f "$PID_FILE" ]; then
  OLD_PID=$(cat "$PID_FILE")
  if kill -0 "$OLD_PID" 2>/dev/null; then
    echo "Stopping existing server (pid $OLD_PID)..."
    kill "$OLD_PID" 2>/dev/null
    sleep 2
  fi
  rm -f "$PID_FILE"
fi

# Fallback: kill by port if PID file was stale
EXISTING=$(lsof -ti tcp:8443 2>/dev/null || true)
if [ -n "$EXISTING" ]; then
  echo "Killing lingering process on port 8443 (pid $EXISTING)..."
  kill "$EXISTING" 2>/dev/null
  sleep 2
fi

# --- Start server ---
cd "$(dirname "$0")"
nohup node server.js --bind "$BIND" --https --password mel2026 > /tmp/tools-server.log 2>&1 &
echo $! > "$PID_FILE"
echo "Server starting (pid $(cat $PID_FILE))..."

# --- Wait for it to be ready ---
for i in $(seq 1 10); do
  sleep 1
  STATUS=$(curl -sk -o /dev/null -w "%{http_code}" "$CHECK_URL" 2>/dev/null || echo "000")
  if [ "$STATUS" = "200" ] || [ "$STATUS" = "302" ]; then
    echo "✅ Server ready (HTTP $STATUS)"
    exit 0
  fi
  echo "  waiting... ($i/10)"
done

echo "❌ Server did not respond after 10s — check /tmp/tools-server.log"
cat /tmp/tools-server.log | tail -20
exit 1
