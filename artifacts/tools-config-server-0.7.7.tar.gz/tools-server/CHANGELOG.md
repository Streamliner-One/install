## [0.7.7] — 2026-03-05

### Added — Agent discoverability

**`GET /api/agent-guide` (no auth required):**
New self-describing endpoint for AI agents. Returns: quickstart steps, all key endpoints with descriptions, intent router summary with supported intents, list of configured credential IDs, and agent tips. Available without authentication so agents can discover how to use the server before they have credentials.

**`/root/.tools-server-access` written on install:**
Installer now writes a JSON file with URL, password, version, install path, and agent-guide URL to `/root/.tools-server-access` (chmod 600). Agents and operators can always find server access details without scrolling through install logs.

# Changelog

## [0.7.6] — 2026-03-05

### Fixed — Pinecone integration

**Probe was a false positive:**
The health check was hitting `app.pinecone.io/actions/whoami`, which returns an HTML 200 regardless of API key validity. Any Pinecone credential always showed ✅ Connected even when the key was wrong or expired.

**Probe now hits the real data plane:**
`POST /describe_index_stats` on the actual index host. Returns vector count on success (`Connected to Pinecone • 1059 vectors in sop-docs`), and meaningful errors on failure (`403 — check API key or IP allowlist`).

**Index Host field now accepts full URLs:**
Pinecone's dashboard shows the host as `https://your-index.svc.aped-xxxx.pinecone.io`. Users can now paste this directly — the `https://` prefix is stripped automatically. No more "getaddrinfo EAI_AGAIN https" DNS errors.

**Schema updated:**
- Renamed `host` → `indexHost` (with updated placeholder showing full URL format)
- Added `indexName` field
- Removed stale `environment` field from required set

**Usage example added:**
`lib/usage.js` now includes a runnable Pinecone example (`describe_index_stats`) with correct headers, expected response shape, and common error guidance.

---

## [0.7.5] — 2026-03-01

- 1Password agent-callable (service account, skill block)
- Full VPS installer validated on fresh Hetzner VM
- Health dashboard with OAuth token expiry tracking
