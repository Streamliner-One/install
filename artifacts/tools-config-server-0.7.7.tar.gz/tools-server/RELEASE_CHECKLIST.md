# Release Checklist — tools-config-server

Run this top to bottom every release. No skipping steps, no back-and-forth.

---

## 0) Pre-flight

- [ ] All changes committed locally in `tools-server/`
- [ ] `CHANGELOG.md` updated with version entry and summary of changes
- [ ] Version bumped in `package.json`: `sed -i 's/"version": "X.X.X"/"version": "X.X.Y"/' package.json`

---

## 1) `Streamliner-One/tools-config-server` (private)

```bash
cd ~/.openclaw/workspace/tools-server

# Stage relevant files (never stage secrets, logs, health-cache)
git add schema.js server.js lib/usage.js package.json CHANGELOG.md
# Add any other changed source files as needed

# If a new service was added or features changed — update install repo README too:
#   ~/.openclaw/workspace/streamliner/install/README.md
#   (services table, features table, or security section as relevant)
git add ../streamliner/install/README.md 2>/dev/null || true

git commit -m "fix/feat/chore: short description — vX.X.Y"

# Push to both remotes
# NOTE: streamliner remote is configured to push master → main
git push origin master        # prudkov/mel-memory (personal backup)
git push streamliner master   # Streamliner-One/tools-config-server (→ main branch)
```

```bash
export GH_TOKEN=$(curl -sk -b /tmp/tools-cookie.jar \
  "https://100.84.57.51:8443/api/credentials/github-1772381712551" \
  | jq -r '.flatFields.token')

gh release create vX.X.Y \
  --repo Streamliner-One/tools-config-server \
  --title "vX.X.Y — Short description" \
  --notes "$(cat CHANGELOG.md | awk '/^## \[X.X.Y\]/,/^## \[/' | head -n -1)"
```

---

## 2) `Streamliner-One/install` (public)

```bash
cd ~/.openclaw/workspace/streamliner/install
git pull origin main

# Build fresh artifact (exclude node_modules, git, secrets, logs)
tar -czf artifacts/tools-config-server-main.tar.gz \
  -C ~/.openclaw/workspace \
  --exclude="tools-server/node_modules" \
  --exclude="tools-server/.git" \
  --exclude="tools-server/.health-cache.json" \
  --exclude="tools-server/server.log" \
  --exclude="tools-server/update-run.log" \
  tools-server/

# Bump versions.json (both stable + latest)
python3 -c "
import json
with open('versions.json') as f: v = json.load(f)
v['channels']['stable']['version'] = 'X.X.Y'
v['channels']['latest']['version'] = 'X.X.Y'
with open('versions.json','w') as f: json.dump(v, f, indent=2)
print('versions.json updated')
"

git add artifacts/tools-config-server-main.tar.gz versions.json
git commit -m "release: vX.X.Y — short description"
git push origin main
```

```bash
gh release create vX.X.Y \
  --repo Streamliner-One/install \
  --title "vX.X.Y — Short description" \
  --notes "Installer artifact updated for tools-config-server vX.X.Y.

See [tools-config-server release notes](https://github.com/Streamliner-One/tools-config-server/releases/tag/vX.X.Y) for full changelog."
```

---

## 3) `Streamliner-One/tools-packages` (public)

No code changes unless a package was added/modified. Always publish a matching release tag regardless:

```bash
gh release create vX.X.Y \
  --repo Streamliner-One/tools-packages \
  --title "vX.X.Y" \
  --notes "Version bump to align with tools-config-server vX.X.Y. No package changes in this release."
```

If packages were changed: commit + push first, then release.

---

## 4) Verify

```bash
# Confirm all three releases exist
gh release list --repo Streamliner-One/tools-config-server | head -3
gh release list --repo Streamliner-One/install | head -3
gh release list --repo Streamliner-One/tools-packages | head -3

# Confirm versions.json is live
curl -s https://raw.githubusercontent.com/Streamliner-One/install/main/versions.json

# Confirm install one-liner still works (dry run)
curl -s https://install.streamliner.one | head -20
```

---

## Notes

- **GH_TOKEN:** always pull fresh from tools server — `curl -sk -b /tmp/tools-cookie.jar "https://100.84.57.51:8443/api/credentials/github-1772381712551" | jq -r '.flatFields.token'`
- **Remotes in tools-server:** `origin` = prudkov/mel-memory (personal backup), `streamliner` = Streamliner-One/tools-config-server (configured to push `master` → `main`)
- **README split:** `tools-config-server/README.md` = dev/contributor reference (architecture, adding services, API). `install/README.md` = public product page (features, services list, security). **Always update `install` README when adding services or significant features.**
- **tools-packages:** only needs a matching version tag; source changes are rare
- **Never stage:** `.health-cache.json`, `server.log`, `update-run.log`, `tools-registry.json`, node_modules
