#!/usr/bin/env bash
set -euo pipefail

BASE_URL="${TOOLS_SERVER_URL:-https://mel.taile54a5b.ts.net:8443}"
PASSWORD="${TOOLS_SERVER_PASSWORD:-mel2026}"
COOKIE_FILE="/tmp/tools_server_cookie_$$.txt"

cleanup() { rm -f "$COOKIE_FILE" >/dev/null 2>&1 || true; }
trap cleanup EXIT

if ! curl -sk --max-time 5 -c "$COOKIE_FILE" -X POST "$BASE_URL/api/login" \
  -H 'Content-Type: application/json' \
  -d "{\"password\":\"$PASSWORD\"}" >/dev/null; then
  echo "TOOLS_SERVER_CHECK: FAIL (login/unreachable)"
  exit 1
fi

CREDS_JSON=$(curl -sk --max-time 8 -b "$COOKIE_FILE" "$BASE_URL/api/credentials" || true)
if [[ -z "$CREDS_JSON" ]]; then
  echo "TOOLS_SERVER_CHECK: FAIL (credentials endpoint)"
  exit 1
fi

COUNT=$(printf '%s' "$CREDS_JSON" | jq '.credentials | length' 2>/dev/null || echo 0)
VER=$(curl -sk --max-time 5 -b "$COOKIE_FILE" "$BASE_URL/api/version" | jq -r '.current.version // "unknown"' 2>/dev/null || echo unknown)

echo "TOOLS_SERVER_CHECK: OK (version=$VER, credentials=$COUNT)"
