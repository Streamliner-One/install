# Changelog

## [0.8.7] — 2026-03-06

### Added — End-to-end integration verification

- New `verify-integrations.sh` script: tests full chain for every credential
  - Package schema + skill block check
  - Credential field validation
  - Intent router resolution
  - Usage example availability
  - Live API probe (actual HTTP calls to each service)
- Supports `--skip-live` (infrastructure-only check) and `--only <pkg>` (single service)
- 33 credentials verified, all green

### Added — Router intents for NanoBanana and Oura

- `image_generation`, `image_edit` → nanoBanana
- `sleep_data`, `health_metrics`, `readiness_check` → oura
- Previously these credentials existed but the intent router couldn't route to them

### Fixed — Todoist API v1 migration

- Todoist deprecated `rest/v2` (returns 410 Gone), migrated to `api/v1`
- Updated verify probe to use new endpoint

### Updated — Release checklist (steps 6–7)

- Added mandatory live API probe step after wiring a new credential
- Added agent delivery simulation step (full intent → router → credential → query → deliver chain)
- Documented the Readwise incident as canonical example of shipping without E2E verification
- Added note about timestamp-suffixed credential IDs for package-based credentials

## [0.8.6] — 2026-03-06

### Fixed — Package→TOOLS.md pipeline

- `generator.js` was reading stale `registry.services` instead of `credentials`
- Package-based credentials (Readwise, Obsidian-Sync) were invisible to TOOLS.md and routing
- `packages.js` now passes the `skill` block to schemas correctly

## [0.8.5] — 2026-03-06

### Fixed — Secret field safety

- Restored pre-fill for password/API-key fields on Edit (1Password-style reveal + compare)
- Added `data-original` guard: unchanged secrets are **not re-saved**, preventing silent truncation/corruption
- Confirmed no `maxlength` or server-side length limits on credential fields

## [0.8.4] — 2026-03-06

### Added — Obsidian Sync (Headless)

- New credential type: `obsidian-sync`
- OTP-only one-shot login flow from the dashboard (no terminal required)
- Optional server-managed vault paths with safe base directory
- Auto `ob sync-setup` after login when remote vault is selected
- Vault picker: remote vault list endpoint + dropdown on credential edit

### Added — Readwise API token support

- New credential type: `readwise`
- Validator confirms token via `GET /api/v2/auth/` and returns "Readwise token OK"

### Improved — Health + validation signal quality

- Clicking **Test** now invalidates cached health so refresh reflects the latest result
- Pinecone validator sends `X-Pinecone-API-Version: 2024-04` and surfaces auth rejection reason headers

### Safety

- Registry now keeps automatic versioned backups (`tools-registry-backups/`, newest 50)

## [0.8.3] — 2026-03-05

### Improved — Mem0 card UX and health feedback

- Mem0 labels simplified to `long-term-memory`
- After clicking **Test**, credential card health now updates immediately (`health: ok` / `health: fail`) without waiting for global refresh

## [0.8.2] — 2026-03-05

### Fixed — Mem0 credential validation signal quality

- Mem0 validator now probes `/v1/memories/` with optional `userId`
- Treats `400` context-required responses as **key valid** (warning) instead of ambiguous endpoint mismatch
- Keeps `401/403` as hard invalid key failures

## [0.8.1] — 2026-03-05

### Added — Mem0 as first-class credential type

- New service schema: `mem0` (Memory category)
- Dashboard fields: `apiKey`, `userId`, `orgId`, `projectId`, `mode`
- Live validator added for Mem0 API key connectivity
- Included in generated Tool Catalog routing metadata

## [0.8.0] — 2026-03-05

### Added — Gemini credential as first-class AI provider

- New infrastructure provider schema: `google` (Gemini API)
- Dedicated validator for Gemini API key (`/v1beta/models`)
- Supports separate dashboard setup/testing from Nano Banana

### Improved — OpenClaw compare/status source resolution

- `openclaw auth` compare now resolves provider source from effective OpenClaw auth state
- Supports both `profiles` and `env` origins instead of profile-file-only assumptions
- OpenAI now reports correctly when key is active via profile/env and avoids false "missing" state

## [0.7.9] — 2026-03-05

### Fixed — Update checker downgrade false-positive

- `/api/update/check` now treats update availability as **remote newer only** (semver-aware)
- Added response fields: `remoteIsNewer`, `versionComparison`, and refined `relation`
- Dashboard Update chip/modal now block downgrade prompts and correctly show "Local build is ahead" when applicable

## [0.7.8] — 2026-03-05

### Added — Dashboard push to OpenClaw auth profiles

- New status endpoint: `GET /api/openclaw/auth/status`
- New compare endpoint: `GET /api/openclaw/auth/compare/:credentialId`
- New push endpoint: `POST /api/credentials/:id/push/openclaw`
- Dashboard adds **OpenClaw** action on supported provider cards (`anthropic|openai|moonshot|google`)
- Push flow now backs up `auth-profiles.json`, writes `provider:default` API key profile, updates `lastGood`, and attempts gateway restart

### Safety gates

- Feature is disabled by default
- Enable with `TOOLS_CONFIG_OPENCLAW_PUSH=1`
- Optional overrides: `OPENCLAW_STATE_DIR`, `OPENCLAW_AGENT_ID`, `OPENCLAW_AUTH_PROFILES_PATH`, `OPENCLAW_RESTART_CMD`

## [0.7.7] — 2026-03-05

### Added — Agent discoverability

**`GET /api/agent-guide` (no auth required):**
New self-describing endpoint for AI agents. Returns: quickstart steps, all key endpoints with descriptions, intent router summary with supported intents, list of configured credential IDs, and agent tips. Available without authentication so agents can discover how to use the server before they have credentials.

**`/root/.tools-server-access` written on install:**
Installer now writes a JSON file with URL, password, version, install path, and agent-guide URL to `/root/.tools-server-access` (chmod 600). Agents and operators can always find server access details without scrolling through install logs.

## [0.7.6] — 2026-03-05

### Fixed — Pinecone integration

**Probe was a false positive:**
The health check was hitting `app.pinecone.io/actions/whoami`, which returns an HTML 200 regardless of API key validity. Any Pinecone credential always showed ✅ Connected even when the key was wrong or expired.

**Probe now hits the real data plane:**
`POST /describe_index_stats` on the actual index host. Returns vector count on success (`Connected to Pinecone • 1059 vectors in sop-docs`), and meaningful errors on failure (`403 — check API key or IP allowlist`).

**Index Host field now accepts full URLs:**
Pinecone's dashboard shows the host as `https://your-index.svc.aped-xxxx.pinecone.io`. Users can now paste this directly — the `https://` prefix is stripped automatically. No more "getaddrinfo EAI_AGAIN https" DNS errors.

**Schema updated:**
- Renamed `host` → `indexHost` (with updated placeholder showing full URL format)
- Added `indexName` field
- Removed stale `environment` field from required set

**Usage example added:**
`lib/usage.js` now includes a runnable Pinecone example (`describe_index_stats`) with correct headers, expected response shape, and common error guidance.

---

## [0.7.5] — 2026-03-01

- 1Password agent-callable (service account, skill block)
- Full VPS installer validated on fresh Hetzner VM
- Health dashboard with OAuth token expiry tracking
