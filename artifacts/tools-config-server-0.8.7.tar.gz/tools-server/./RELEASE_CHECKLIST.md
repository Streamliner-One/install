# Release Checklist — tools-config-server

Run this top to bottom every release. No skipping steps, no back-and-forth.

---

## Adding a New Credential Type

Every new credential type needs **all** of these to be fully wired. Missing any one makes it invisible to the agent, TOOLS.md, or the intent router. Use this as a checklist every time.

### Package Definition (`packages/<id>/package.json`)

- [ ] **`id`** — unique package identifier (e.g. `readwise`, `obsidian-sync`)
- [ ] **`name`** — human-readable name (no implementation details like "Headless")
- [ ] **`description`** — one-line description for TOOLS.md
- [ ] **`icon`** — emoji for the routing table
- [ ] **`category`** — e.g. `knowledge`, `travel`, `voice`, `productivity`
- [ ] **`fields`** — all credential fields with `label`, `type`, `required`, `sensitive`, `placeholder`, `help`
- [ ] **`skill`** block (required for agent-callable services):
  ```json
  "skill": {
    "useWhen": "comma-separated trigger phrases",
    "intents": ["intent_1", "intent_2"],
    "params": ["param1", "param2 (optional)"],
    "fallback": "brave or none",
    "note": "Optional context for the agent"
  }
  ```
  Without `skill`, the service appears under "Infrastructure" in TOOLS.md — invisible to the intent router.
- [ ] **`validation`** — either `{ "type": "http", ... }` (declarative) or `{ "type": "javascript", "entry": "validator.js" }` (custom)

### Validator (`packages/<id>/validator.js`)

- [ ] Exports `validate(fields)` → returns `{ valid: true/false, message: "..." }`
- [ ] Handles missing fields gracefully
- [ ] Uses a lightweight API probe (not a full query)

### Usage Example (`lib/usage.js`)

- [ ] Add an entry in `EXAMPLES` for the package ID
- [ ] Include `title`, `summary`, `method`, `url`, `headers`, `params` with defaults
- [ ] Verify with: `GET /api/credentials/:id/usage` and `POST /api/credentials/:id/example/run`

### Intent Router (`router.json`)

- [ ] Add relevant intents pointing to the new package ID
- [ ] **Note:** Package-based credentials get timestamp-suffixed IDs (e.g. `readwise-1772811314235`). The router and usage layer must resolve both the base package ID and the suffixed credential ID.
- [ ] Place it in the correct priority order (most specific first, `brave` as fallback)
- [ ] Verify with: `GET /api/router?intent=<new_intent>`

### Schema (if not package-based)

- [ ] If adding to `schema.js` instead of `packages/`, include the `skill` block there
- [ ] Ensure it has `labels` array for dashboard category filtering

### Verification

After all the above, run this to confirm the full chain:

```bash
# 1. Package schema loaded with skill?
node -e '
  const { loadAllPackages, getPackageSchemas } = require("./lib/packages");
  loadAllPackages();
  const s = getPackageSchemas()["NEW_ID"];
  console.log(s ? `✅ ${s.name} | skill=${!!s.skill}` : "❌ MISSING");
'

# 2. Credential exists in registry?
cat ~/.openclaw/workspace/tools-registry.json | jq '.credentials | keys[]' | grep NEW_ID

# 3. Shows in TOOLS.md routing table?
node -e 'require("./lib/generator").generateToolsMd()'
grep "NEW_NAME" ~/.openclaw/workspace/TOOLS.md

# 4. Router resolves intent?
# (requires running server)
curl -sk ... "/api/router?intent=NEW_INTENT" | jq '.candidates'

# 5. Usage example works?
curl -sk ... "/api/credentials/CRED_ID/usage"

# 6. Live API query succeeds?
# Fetch the actual credential, make a real API call, confirm valid response.
# Example for Readwise:
#   TOKEN=$(curl -sk -b $COOKIE "$BASE/api/credentials/readwise-XXXXX" | jq -r '.fields.apiToken.value')
#   curl -s "https://readwise.io/api/v2/highlights/?page_size=1" -H "Authorization: Token $TOKEN" | jq '.count'
# Must return real data, not 401/403/empty.

# 7. Agent delivery simulation
# Simulate the full user-facing flow:
#   a) User intent → router resolves to correct service
#   b) Credential fetched (note: package IDs may have timestamp suffixes!)
#   c) API queried with real parameters
#   d) Response parsed and formatted for user delivery
# If ANY step fails, the integration is NOT ready to ship.
```

> ⚠️ **Steps 6–7 are mandatory.** Without them, you have a credential in a vault
> and routes in a router, but the agent can't actually USE the integration.
> This is exactly the failure mode we hit with Readwise on 2026-03-06:
> everything looked wired, but the agent defaulted to web search because
> the live query path was never tested end-to-end.

---

## 0) Pre-flight

- [ ] All changes committed locally in `tools-server/`
- [ ] `CHANGELOG.md` updated with version entry and summary of changes
- [ ] Version bumped in `package.json`: `sed -i 's/"version": "X.X.X"/"version": "X.X.Y"/' package.json`

---

## 1) `Streamliner-One/tools-config-server` (private)

```bash
cd ~/.openclaw/workspace/tools-server

# Stage relevant files (never stage secrets, logs, health-cache)
git add schema.js server.js lib/usage.js package.json CHANGELOG.md
# Add any other changed source files as needed

# If a new service was added or features changed — update install repo README too:
#   ~/.openclaw/workspace/streamliner/install/README.md
#   (services table, features table, or security section as relevant)
git add ../streamliner/install/README.md 2>/dev/null || true

git commit -m "fix/feat/chore: short description — vX.X.Y"

# Push to both remotes
# NOTE: streamliner remote is configured to push master → main
git push origin master        # prudkov/mel-memory (personal backup)
git push streamliner master   # Streamliner-One/tools-config-server (→ main branch)
```

```bash
export GH_TOKEN=$(curl -sk -b /tmp/tools-cookie.jar \
  "https://100.84.57.51:8443/api/credentials/github-1772381712551" \
  | jq -r '.flatFields.token')

gh release create vX.X.Y \
  --repo Streamliner-One/tools-config-server \
  --title "vX.X.Y — Short description" \
  --notes "$(cat CHANGELOG.md | awk '/^## \[X.X.Y\]/,/^## \[/' | head -n -1)"
```

---

## 2) `Streamliner-One/install` (public)

```bash
cd ~/.openclaw/workspace/streamliner/install
git pull origin main

# Build fresh artifact (exclude node_modules, git, secrets, logs)
tar -czf artifacts/tools-config-server-main.tar.gz \
  -C ~/.openclaw/workspace \
  --exclude="tools-server/node_modules" \
  --exclude="tools-server/.git" \
  --exclude="tools-server/.health-cache.json" \
  --exclude="tools-server/server.log" \
  --exclude="tools-server/update-run.log" \
  tools-server/

# Bump versions.json (both stable + latest)
python3 -c "
import json
with open('versions.json') as f: v = json.load(f)
v['channels']['stable']['version'] = 'X.X.Y'
v['channels']['latest']['version'] = 'X.X.Y'
with open('versions.json','w') as f: json.dump(v, f, indent=2)
print('versions.json updated')
"

git add artifacts/tools-config-server-main.tar.gz versions.json
git commit -m "release: vX.X.Y — short description"
git push origin main
```

```bash
gh release create vX.X.Y \
  --repo Streamliner-One/install \
  --title "vX.X.Y — Short description" \
  --notes "Installer artifact updated for tools-config-server vX.X.Y.

See [tools-config-server release notes](https://github.com/Streamliner-One/tools-config-server/releases/tag/vX.X.Y) for full changelog."
```

---

## 3) `Streamliner-One/tools-packages` (public)

No code changes unless a package was added/modified. Always publish a matching release tag regardless:

```bash
gh release create vX.X.Y \
  --repo Streamliner-One/tools-packages \
  --title "vX.X.Y" \
  --notes "Version bump to align with tools-config-server vX.X.Y. No package changes in this release."
```

If packages were changed: commit + push first, then release.

---

## 4) Verify

```bash
# Confirm all three releases exist
gh release list --repo Streamliner-One/tools-config-server | head -3
gh release list --repo Streamliner-One/install | head -3
gh release list --repo Streamliner-One/tools-packages | head -3

# Confirm versions.json is live
curl -s https://raw.githubusercontent.com/Streamliner-One/install/main/versions.json

# Confirm install one-liner still works (dry run)
curl -s https://install.streamliner.one | head -20
```

---

## Notes

- **GH_TOKEN:** always pull fresh from tools server — `curl -sk -b /tmp/tools-cookie.jar "https://100.84.57.51:8443/api/credentials/github-1772381712551" | jq -r '.flatFields.token'`
- **Remotes in tools-server:** `origin` = prudkov/mel-memory (personal backup), `streamliner` = Streamliner-One/tools-config-server (configured to push `master` → `main`)
- **README split:** `tools-config-server/README.md` = dev/contributor reference (architecture, adding services, API). `install/README.md` = public product page (features, services list, security). **Always update `install` README when adding services or significant features.**
- **tools-packages:** only needs a matching version tag; source changes are rare
- **Never stage:** `.health-cache.json`, `server.log`, `update-run.log`, `tools-registry.json`, node_modules
