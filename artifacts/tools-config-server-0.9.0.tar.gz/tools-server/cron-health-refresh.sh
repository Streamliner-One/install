#!/usr/bin/env bash
set -euo pipefail

BASE_URL="${TOOLS_SERVER_URL:-https://100.84.57.51:8443}"
PASSWORD="${TOOLS_SERVER_PASSWORD:-mel2026}"
COOKIE_FILE="/tmp/tools_health_cookie_$$.txt"

cleanup() { rm -f "$COOKIE_FILE" >/dev/null 2>&1 || true; }
trap cleanup EXIT

# Add jitter to avoid synchronized bursts across instances
JITTER_MAX_SECONDS="${TOOLS_HEALTH_JITTER_SECONDS:-1800}"
if [[ "$JITTER_MAX_SECONDS" =~ ^[0-9]+$ ]] && [ "$JITTER_MAX_SECONDS" -gt 0 ]; then
  sleep $(( RANDOM % JITTER_MAX_SECONDS ))
fi

curl -sk --max-time 8 -c "$COOKIE_FILE" -X POST "$BASE_URL/api/login" \
  -H 'Content-Type: application/json' \
  -d "{\"password\":\"$PASSWORD\"}" >/dev/null

curl -sk --max-time 60 -b "$COOKIE_FILE" -X POST "$BASE_URL/api/health/refresh" \
  -H 'Content-Type: application/json' >/dev/null

echo "[$(date -Iseconds)] health refresh completed"
