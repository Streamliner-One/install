#!/usr/bin/env node
/**
 * Query Via Travel SOPs from Pinecone
 * Uses credentials from tools-registry.json
 */

const fs = require('fs');
const path = require('path');
const https = require('https');

const REGISTRY_PATH = path.join(process.env.HOME || '/home/alex', '.openclaw/workspace/tools-registry.json');

function loadRegistry() {
  return JSON.parse(fs.readFileSync(REGISTRY_PATH, 'utf8'));
}

async function getOpenAIEmbedding(text) {
  const registry = loadRegistry();
  const apiKey = registry.services.openai?.fields?.apiKey?.value;
  
  if (!apiKey) {
    throw new Error('OpenAI API key not found in registry');
  }
  
  return new Promise((resolve, reject) => {
    const data = JSON.stringify({
      model: 'text-embedding-ada-002',
      input: text
    });
    
    const req = https.request('https://api.openai.com/v1/embeddings', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
        'Content-Length': data.length
      }
    }, (res) => {
      let responseData = '';
      res.on('data', chunk => responseData += chunk);
      res.on('end', () => {
        try {
          const json = JSON.parse(responseData);
          if (json.error) {
            reject(new Error(json.error.message));
          } else {
            resolve(json.data[0].embedding);
          }
        } catch (e) {
          reject(e);
        }
      });
    });
    
    req.on('error', reject);
    req.write(data);
    req.end();
  });
}

async function queryPinecone(vector, topK = 5) {
  const registry = loadRegistry();
  const apiKey = registry.services.pinecone?.fields?.apiKey?.value;
  const host = 'sop-docs-lylkec2.svc.aped-4627-b74a.pinecone.io';
  
  if (!apiKey) {
    throw new Error('Pinecone API key not found in registry');
  }
  
  // Try using node-fetch if available, otherwise https
  try {
    const fetch = require('node-fetch');
    const response = await fetch(`https://${host}/query`, {
      method: 'POST',
      headers: {
        'Api-Key': apiKey,
        'Content-Type': 'application/json',
        'X-Pinecone-API-Version': '2024-04'
      },
      body: JSON.stringify({
        vector,
        topK,
        includeMetadata: true
      })
    });
    return await response.json();
  } catch {
    // Fallback to https
    return new Promise((resolve, reject) => {
      const data = JSON.stringify({
        vector,
        topK,
        includeMetadata: true
      });
      
      const req = https.request(`https://${host}/query`, {
        method: 'POST',
        headers: {
          'Api-Key': apiKey,
          'Content-Type': 'application/json',
          'X-Pinecone-API-Version': '2024-04',
          'Content-Length': Buffer.byteLength(data)
        }
      }, (res) => {
        let responseData = '';
        res.on('data', chunk => responseData += chunk);
        res.on('end', () => {
          try {
            const json = JSON.parse(responseData);
            resolve(json);
          } catch (e) {
            reject(new Error(responseData || e.message));
          }
        });
      });
      
      req.on('error', reject);
      req.write(data);
      req.end();
    });
  }
}

async function searchSOPs(query) {
  console.log(`🔍 Searching SOPs for: "${query}"\n`);
  
  try {
    // Get embedding from OpenAI
    console.log('🧠 Generating embedding...');
    const embedding = await getOpenAIEmbedding(query);
    
    // Query Pinecone
    console.log('🌲 Querying Pinecone...');
    const results = await queryPinecone(embedding);
    
    // Display results
    console.log(`\n📄 Found ${results.matches?.length || 0} relevant SOPs:\n`);
    
    if (results.matches) {
      results.matches.forEach((match, i) => {
        const score = (match.score * 100).toFixed(1);
        const text = match.metadata?.text || 'No text available';
        console.log(`${i + 1}. [${score}% match] ${text}`);
      });
    }
    
    return results;
  } catch (err) {
    console.error('❌ Error:', err.message);
    process.exit(1);
  }
}

// CLI usage
const query = process.argv[2];
if (!query) {
  console.log('Usage: node query-sops.js "your search query"');
  console.log('Example: node query-sops.js "cancellation policy"');
  process.exit(1);
}

searchSOPs(query);