# Quick Installation

## One-Line Install

```bash
curl -fsSL https://install.openclaw.dev | bash
```

This will:
- Install Node.js 18+ (if needed)
- Install 1Password CLI (if needed)
- Download Tools Config Server
- Generate secure admin password
- Start the server
- Display access URL and password

## Docker

```bash
docker run -d \
  -p 8443:8443 \
  -v tools-data:/data \
  -e TOOLS_PASSWORD=$(openssl rand -hex 16) \
  streamliner/tools-config:latest
```

## Manual

```bash
git clone https://github.com/prudkov/mel-memory.git
cd mel-memory/tools-server
npm install
node server.js --bind 0.0.0.0:8443 --https --password your-password
```

## Access

After installation:
1. Open browser to displayed URL
2. Enter the password (shown during install)
3. Immediately change the password in UI
4. Start adding credentials!

## Updating

When already installed, update in place:

```bash
cd /opt/tools-config/tools-server
./update.sh
```

Managed instances: run this via orchestration/SSH (or cron) and monitor service health after restart.

Installer also provisions `agent-tools-check.sh` and `cron-health-refresh.sh`, and (when possible) injects an AGENTS.md reminder so agents keep Tools server in attention automatically.

Optional cron auto-install during setup:

```bash
TOOLS_INSTALL_HEALTH_CRON=1 curl -fsSL https://install.openclaw.dev | bash
```

## Documentation

- [API Reference](API.md)
- [Build Summary](BUILD_SUMMARY.md)
- [Distribution Guide](DISTRIBUTION.md)
- [1Password Setup](1PASSWORD_SETUP.md)

## Support

GitHub: https://github.com/prudkov/mel-memory