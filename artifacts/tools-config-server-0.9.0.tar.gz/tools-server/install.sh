#!/bin/bash
#
# OpenClaw Tools Config Server - One-Line Installer
# Usage: curl -fsSL https://install.openclaw.dev | bash
#

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
INSTALL_DIR="${TOOLS_INSTALL_DIR:-/opt/tools-config}"
REPO_URL="https://github.com/prudkov/mel-memory.git"
NODE_VERSION="18"

# Logging
log() { echo -e "${BLUE}[install]${NC} $1"; }
error() { echo -e "${RED}[error]${NC} $1" >&2; }
success() { echo -e "${GREEN}[success]${NC} $1"; }
warning() { echo -e "${YELLOW}[warning]${NC} $1"; }

# Check if running as root
check_root() {
    if [[ $EUID -eq 0 ]]; then
        warning "Running as root. Installing system-wide."
        SUDO=""
    else
        log "Running as user. Installing to $HOME/.tools-config"
        INSTALL_DIR="$HOME/.tools-config"
        SUDO=""
    fi
}

# Detect OS
detect_os() {
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        if [ -f /etc/debian_version ]; then
            OS="debian"
        elif [ -f /etc/redhat-release ]; then
            OS="redhat"
        else
            OS="linux"
        fi
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        OS="macos"
    else
        error "Unsupported OS: $OSTYPE"
        exit 1
    fi
    log "Detected OS: $OS"
}

# Install Node.js
install_node() {
    if command -v node &> /dev/null; then
        NODE_CURRENT=$(node --version | cut -d'v' -f2 | cut -d'.' -f1)
        if [ "$NODE_CURRENT" -ge "$NODE_VERSION" ]; then
            success "Node.js $(node --version) already installed"
            return
        fi
    fi
    
    log "Installing Node.js $NODE_VERSION..."
    
    if [ "$OS" == "debian" ]; then
        curl -fsSL https://deb.nodesource.com/setup_${NODE_VERSION}.x | bash -
        apt-get install -y nodejs
    elif [ "$OS" == "redhat" ]; then
        curl -fsSL https://rpm.nodesource.com/setup_${NODE_VERSION}.x | bash -
        yum install -y nodejs
    elif [ "$OS" == "macos" ]; then
        if ! command -v brew &> /dev/null; then
            error "Homebrew not found. Please install: https://brew.sh"
            exit 1
        fi
        brew install node@$NODE_VERSION
    fi
    
    success "Node.js $(node --version) installed"
}

# Install 1Password CLI
install_op_cli() {
    if command -v op &> /dev/null; then
        success "1Password CLI already installed: $(op --version)"
        return
    fi
    
    log "Installing 1Password CLI..."
    
    OP_VERSION="2.30.3"
    
    if [ "$OS" == "macos" ]; then
        brew install --cask 1password-cli
    else
        # Linux
        curl -sS https://cache.agilebits.com/dist/1P/op2/pkg/v${OP_VERSION}/op_linux_amd64_v${OP_VERSION}.zip -o /tmp/op.zip
        unzip -o /tmp/op.zip -d /tmp/op
        $SUDO mv /tmp/op/op /usr/local/bin/
        $SUDO chmod +x /usr/local/bin/op
        rm -rf /tmp/op /tmp/op.zip
    fi
    
    success "1Password CLI installed"
}

# Clone repository
clone_repo() {
    log "Cloning Tools Config Server..."
    
    if [ -d "$INSTALL_DIR" ]; then
        warning "Directory exists. Updating..."
        cd "$INSTALL_DIR"
        git pull
    else
        git clone --depth 1 "$REPO_URL" "$INSTALL_DIR"
        cd "$INSTALL_DIR/tools-server"
    fi
    
    success "Repository ready"
}

# Install dependencies
install_deps() {
    log "Installing npm dependencies..."
    cd "$INSTALL_DIR/tools-server"
    npm install --production
    success "Dependencies installed"
}

# Install agent reminder/check helper
install_agent_check() {
    local helper="$INSTALL_DIR/tools-server/agent-tools-check.sh"
    local health_helper="$INSTALL_DIR/tools-server/cron-health-refresh.sh"
    if [ -f "$helper" ]; then
        chmod +x "$helper" || true
        log "Agent tools-check helper ready: $helper"
    fi
    if [ -f "$health_helper" ]; then
        chmod +x "$health_helper" || true
        log "Health refresh cron helper ready: $health_helper"
    fi

    # If an OpenClaw workspace AGENTS.md exists, append reminder once
    local agents_md="${OPENCLAW_WORKSPACE:-$HOME/.openclaw/workspace}/AGENTS.md"
    if [ -f "$agents_md" ]; then
        if ! grep -q "agent-tools-check.sh" "$agents_md"; then
            {
                echo ""
                echo "## Tools Server Attention Hook"
                echo "At session start, run: ~/.openclaw/workspace/tools-server/agent-tools-check.sh"
                echo "Purpose: keep tools-server availability and credentials in immediate agent attention."
            } >> "$agents_md"
            log "Patched AGENTS.md with tools-server attention hook"
        fi
    fi
}

# Generate password
generate_password() {
    ADMIN_PASS=$(openssl rand -hex 16)
    echo "$ADMIN_PASS" > "$INSTALL_DIR/.admin_password"
    chmod 600 "$INSTALL_DIR/.admin_password"
}

# Detect IP
detect_ip() {
    # Try to get Tailscale IP first
    TAILSCALE_IP=$(tailscale ip -4 2>/dev/null || echo "")
    
    if [ -n "$TAILSCALE_IP" ]; then
        BIND_IP="$TAILSCALE_IP"
        ACCESS_METHOD="Tailscale"
    else
        # Get public IP
        PUBLIC_IP=$(curl -s https://api.ipify.org 2>/dev/null || echo "localhost")
        BIND_IP="0.0.0.0"
        ACCESS_METHOD="Public Internet"
    fi
}

# Create systemd service
create_service() {
    if [ "$OS" != "debian" ] && [ "$OS" != "redhat" ]; then
        warning "Systemd service not created (not Linux)"
        return
    fi
    
    log "Creating systemd service..."
    
    cat > /tmp/tools-config.service << 'EOF'
[Unit]
Description=OpenClaw Tools Config Server
After=network.target

[Service]
Type=simple
User=tools-config
WorkingDirectory=INSTALL_DIR/tools-server
ExecStart=/usr/bin/node server.js --bind BIND_IP:8443 --https --password ADMIN_PASS
Restart=always
RestartSec=10
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
EOF

    # Replace placeholders
    sed -i "s|INSTALL_DIR|$INSTALL_DIR|g" /tmp/tools-config.service
    sed -i "s|BIND_IP|$BIND_IP|g" /tmp/tools-config.service
    sed -i "s|ADMIN_PASS|$ADMIN_PASS|g" /tmp/tools-config.service
    
    $SUDO mv /tmp/tools-config.service /etc/systemd/system/
    $SUDO systemctl daemon-reload
    $SUDO systemctl enable tools-config
    
    success "Systemd service created"
}

# Create user
create_user() {
    if ! id -u tools-config &>/dev/null; then
        log "Creating tools-config user..."
        $SUDO useradd -r -s /bin/false tools-config
    fi
    
    $SUDO chown -R tools-config:tools-config "$INSTALL_DIR"
}

# Optional health refresh cron setup
setup_health_cron() {
    local enable="${TOOLS_INSTALL_HEALTH_CRON:-0}"
    if [ "$enable" != "1" ]; then
        return
    fi

    local helper="$INSTALL_DIR/tools-server/cron-health-refresh.sh"
    if [ ! -f "$helper" ]; then
        warning "Health cron helper not found: $helper"
        return
    fi

    local line="0 9,21 * * * $helper >> /var/log/tools-health-refresh.log 2>&1"
    (crontab -l 2>/dev/null | grep -v "cron-health-refresh.sh"; echo "$line") | crontab -
    log "Installed health refresh cron: $line"
}

# Start service
start_service() {
    log "Starting Tools Config Server..."
    
    if [ -f /etc/systemd/system/tools-config.service ]; then
        $SUDO systemctl start tools-config
        sleep 3
        
        if $SUDO systemctl is-active --quiet tools-config; then
            success "Service started successfully"
        else
            error "Service failed to start"
            $SUDO journalctl -u tools-config --no-pager -n 10
            exit 1
        fi
    else
        # Manual start
        cd "$INSTALL_DIR/tools-server"
        nohup node server.js --bind "$BIND_IP:8443" --https --password "$ADMIN_PASS" > /tmp/tools-config.log 2>&1 &
        sleep 3
        success "Server started (manual mode)"
    fi
}

# Display success message
show_success() {
    echo ""
    echo "╔════════════════════════════════════════════════════════════════╗"
    echo "║          🎉 OpenClaw Tools Config Server Installed!            ║"
    echo "╠════════════════════════════════════════════════════════════════╣"
    printf "║  URL:      https://%-43s ║\n" "$BIND_IP:8443"
    printf "║  Password: %-51s ║\n" "$ADMIN_PASS"
    echo "╠════════════════════════════════════════════════════════════════╣"
    echo "║  ⚠️  SAVE THIS PASSWORD NOW - it won't be shown again!         ║"
    echo "╠════════════════════════════════════════════════════════════════╣"
    printf "║  Access: %-53s ║\n" "$ACCESS_METHOD"
    echo "║                                                                ║"
    echo "║  Commands:                                                     ║"
    echo "║    systemctl status tools-config    # Check status            ║"
    echo "║    systemctl restart tools-config   # Restart                 ║"
    echo "║    journalctl -u tools-config -f    # View logs               ║"
    echo "╚════════════════════════════════════════════════════════════════╝"
    echo ""
    warning "Store this password in your password manager!"
    echo ""
    log "Installation complete! 🚀"
}

# Configure OpenClaw agent workspace
configure_agent() {
    local workspace="${OPENCLAW_WORKSPACE:-$HOME/.openclaw/workspace}"
    if [ ! -d "$workspace" ]; then
        warning "OpenClaw workspace not found at $workspace — skipping agent config"
        warning "Run scripts/agent-init.sh manually after OpenClaw is installed"
        return
    fi
    log "Configuring OpenClaw agent workspace..."
    OPENCLAW_WORKSPACE="$workspace" \
    TOOLS_SERVER_URL="https://${BIND_IP}:8443" \
    TOOLS_SERVER_PASSWORD="$ADMIN_PASS" \
    bash "$(dirname "$0")/scripts/agent-init.sh"
}

# Main installation
main() {
    echo ""
    echo "🔧 OpenClaw Tools Config Server Installer"
    echo "========================================="
    echo ""
    
    check_root
    detect_os
    install_node
    install_op_cli
    clone_repo
    install_deps
    install_agent_check
    setup_health_cron
    generate_password
    detect_ip
    configure_agent
    
    if [ -z "$SUDO" ]; then
        create_user
        create_service
        start_service
    else
        # User install - manual start
        cd "$INSTALL_DIR/tools-server"
        echo ""
        log "To start the server, run:"
        echo "  cd $INSTALL_DIR/tools-server"
        echo "  node server.js --bind 127.0.0.1:8443 --password \$(cat $INSTALL_DIR/.admin_password)"
    fi
    
    show_success
}

# Run
main "$@"