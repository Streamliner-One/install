# Distribution & Onboarding Guide

## Overview
How to deploy Tools Config Server to client installations and onboard users.

---

## Installation Methods

### Method 1: One-Line Installer (Recommended)

```bash
# Client runs this on their VPS/server
curl -fsSL https://install.openclaw.dev | bash
```

**What it does:**
1. Detects OS (Ubuntu, Debian, CentOS, macOS)
2. Installs Node.js 18+ if missing
3. Installs 1Password CLI if needed
4. Clones tools-server repository
5. Installs npm dependencies
6. Generates random admin password
7. Creates systemd service
8. Starts server on port 8443
9. Displays access URL and password

**Installer script location:** `https://raw.githubusercontent.com/streamliner/install/main/install.sh`

### Method 2: Docker Compose

```yaml
# docker-compose.yml
version: '3.8'
services:
  tools-config:
    image: streamliner/tools-config:latest
    ports:
      - "8443:8443"
    volumes:
      - ./data:/data
      - ./packages:/app/packages
    environment:
      - TOOLS_PASSWORD=${TOOLS_PASSWORD:-changeme}
      - TOOLS_BIND=0.0.0.0:8443
    restart: unless-stopped
```

```bash
# Client runs:
export TOOLS_PASSWORD=$(openssl rand -hex 16)
docker-compose up -d
```

### Method 3: Manual Installation

```bash
# For advanced users who want control
git clone https://github.com/prudkov/mel-memory.git
cd mel-memory/tools-server
npm install

# Generate password
export ADMIN_PASS=$(openssl rand -hex 16)
echo "Password: $ADMIN_PASS"

# Start
node server.js --bind 0.0.0.0:8443 --https --password "$ADMIN_PASS"
```

---

## Initial Password Strategy

### Option A: Auto-Generated (Secure)

```bash
# During installation
ADMIN_PASS=$(openssl rand -hex 16)
echo "Your Tools Config password: $ADMIN_PASS"
echo "Save this securely - displayed only once!"
```

**Display to user:**
```
╔══════════════════════════════════════════════════════════╗
║  OpenClaw Tools Config Server Installed                  ║
╠══════════════════════════════════════════════════════════╣
║  URL:      https://your-server:8443                     ║
║  Password: a3f7b2d8e9c1... (SAVE THIS!)                ║
╠══════════════════════════════════════════════════════════╣
║  ⚠️  This password will NOT be shown again               ║
║  Store it in your password manager now                   ║
╚══════════════════════════════════════════════════════════╝
```

### Option B: Client-Provided

```bash
# Ask client for password during install
read -s -p "Enter admin password for Tools Config: " ADMIN_PASS
echo
```

### Option C: Bootstrap via 1Password

```bash
# Retrieve initial password from 1Password
ADMIN_PASS=$(op read "op://Private/Tools Config/password")
```

---

## Package Distribution

### Option 1: Git Repository (Current)

**Structure:**
```
github.com/streamliner/tool-packages/
├── README.md
├── packages/
│   ├── stripe/
│   │   └── package.json
│   ├── notion/
│   │   └── package.json
│   └── ...
└── versions.json
```

**Installation:**
```bash
# On client server
git clone https://github.com/streamliner/tool-packages.git /tmp/packages
cp -r /tmp/packages/packages/* /opt/tools-server/packages/
```

### Option 2: Tarball Downloads

**Hosted at:** `https://packages.openclaw.dev/`

```bash
# Download latest packages
curl -O https://packages.openclaw.dev/tool-packages-v1.2.0.tar.gz
tar -xzf tool-packages-v1.2.0.tar.gz -C /opt/tools-server/
```

### Option 3: Built-in Package Manager (Future)

```bash
# Via CLI
claw-tools install stripe
claw-tools install notion
claw-tools update-all
```

Or via Web UI:
- Dashboard → "Install Package" → Browse catalog → Click Install

---

## Onboarding Workflow

### For Managed Clients (Streamliner One)

**Step 1: Pre-Configuration**
```bash
# We prepare:
# - VPS provisioned
# - Domain/DNS configured (optional)
# - Tailscale installed
```

**Step 2: Install Tools Config**
```bash
# Run on client VPS
curl -fsSL https://install.openclaw.dev | bash

# Output:
# ✓ Tools Config Server installed
# ✓ Running on https://100.x.x.x:8443
# ✓ Admin password: [DISPLAYED ONCE]
```

**Step 3: Initial Setup**
```
1. Client logs in with displayed password
2. Prompted to change password immediately
3. Guided to add first credentials (Stripe, Notion, etc.)
4. Optional: Import from 1Password
```

**Step 4: Handoff**
```
We provide:
- Access URL
- New (changed) password
- Quick start guide
- Support contact
```

### For Self-Service Users

**Docker Compose Path:**
```bash
# 1. Download compose file
curl -O https://raw.githubusercontent.com/streamliner/tools-config/main/docker-compose.yml

# 2. Set password
export TOOLS_PASSWORD=$(openssl rand -hex 16)
echo "Password: $TOOLS_PASSWORD" > .env

# 3. Start
docker-compose up -d

# 4. Access
echo "Open: https://localhost:8443"
echo "Password: $(cat .env | grep TOOLS_PASSWORD)"
```

---

## Security Considerations

### Initial Access

```bash
# Option 1: Temporary public access
tools-config serve --temp 30m --public
# Auto-generates password, shuts down after 30 min

# Option 2: Tailscale only (recommended)
tools-config serve --bind 100.x.x.x:8443
# Only accessible via Tailscale network

# Option 3: SSH tunnel
ssh -L 8443:localhost:8443 user@vps
# Access via https://localhost:8443
```

### Password Management

```bash
# Force password change on first login
# Implemented in UI

# Password complexity requirements
MIN_LENGTH=12
REQUIRE_MIXED_CASE=true
REQUIRE_NUMBERS=true
```

### Backup Strategy

```bash
# Automated backup
0 2 * * * /opt/tools-server/backup.sh

# Backup includes:
# - tools-registry.json
# - .certs/
# - packages/
# - TOOLS.md
```

---

## Multi-Tenant Considerations

### Single Instance per Client

**Pros:**
- Simple
- Complete isolation
- Easy to troubleshoot

**Cons:**
- More servers to manage

### Shared Instance (Future)

```javascript
// Add tenant_id to credentials
{
  "credentials": {
    "stripe-prod": {
      "_tenant": "client-a",
      "_package": "stripe",
      ...
    }
  }
}
```

**Currently:** Single tenant per instance (recommended)

---

## Update Strategy

### Automatic Updates (Optional)

```bash
# Cron job
0 4 * * * /opt/tools-server/update.sh

# What update.sh does:
# 1. Check for new version
# 2. Backup current
# 3. Pull updates
# 4. Restart service
# 5. Verify health
```

### Manual Updates

```bash
# Client runs:
cd /opt/tools-server
git pull
npm install
pm2 restart tools-config
```

---

## Monitoring & Alerts

### Health Checks

```bash
# Built-in endpoint
curl https://server:8443/api/health

# External monitoring (UptimeRobot, etc.)
# Ping every 5 minutes
```

### Alerts

```bash
# On credential validation failure
# Send alert to Slack/Email

# On disk space low
# Alert admin

# On failed login attempts
# Block IP after 5 attempts
```

---

## Migration Path

### From Environment Variables

```bash
# Old way: .env file
STRIPE_KEY=sk_live_...
NOTION_TOKEN=ntn_...

# New way: Import to Tools Config
node scripts/migrate-from-env.js
```

### From 1Password

```bash
# Pull all credentials from 1Password
# Store locally in Tools Config
node scripts/import-from-1password.js --vault "Client Vault"
```

---

## Quick Reference

| Task | Command |
|------|---------|
| Install | `curl -fsSL https://install.openclaw.dev \| bash` |
| Start | `tools-config serve --bind 0.0.0.0:8443` |
| Update | `cd /opt/tools-server && git pull && npm install` |
| Backup | `tools-config backup` |
| Reset password | `tools-config reset-password` |
| Install package | Copy to `packages/` folder |
| View logs | `pm2 logs tools-config` |

---

## Support

**Documentation:** https://docs.openclaw.ai
**Issues:** https://github.com/streamliner/tools-config/issues
**Email:** support@streamliner.one

---

## Next Steps

1. **Create install script** at `install.openclaw.dev`
2. **Set up package repository** for distribution
3. **Create Docker image** and publish to registry
4. **Write onboarding guide** for clients
5. **Build CLI tool** `claw-tools` for management