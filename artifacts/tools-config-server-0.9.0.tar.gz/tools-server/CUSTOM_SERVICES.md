# Custom Services

Add your own services to the Tools Config dashboard by creating a `custom-services.json` file.

## Quick Start

1. Create `~/.openclaw/workspace/tools-server/custom-services.json`:

```json
{
  "services": {
    "supabase": {
      "id": "supabase",
      "name": "Supabase",
      "category": "database",
      "icon": "🟢",
      "description": "PostgreSQL database with realtime",
      "fields": [
        { "key": "url", "label": "Project URL", "type": "url", "required": true, "placeholder": "https://xxxx.supabase.co" },
        { "key": "anonKey", "label": "Anon Key", "type": "password", "required": true, "sensitive": true },
        { "key": "serviceKey", "label": "Service Role Key", "type": "password", "required": false, "sensitive": true }
      ]
    },
    "resend": {
      "id": "resend",
      "name": "Resend",
      "category": "email",
      "icon": "✉️",
      "description": "Email API for developers",
      "fields": [
        { "key": "apiKey", "label": "API Key", "type": "password", "required": true, "sensitive": true }
      ]
    }
  }
}
```

2. Restart the server:
```bash
cd tools-server
./restart.sh
```

3. Your custom services appear in the dashboard automatically!

## Field Types

| Type | Description | Example |
|------|-------------|---------|
| `text` | Single-line text | API keys, tokens |
| `password` | Masked input | Secrets, keys |
| `url` | URL validation | Webhook endpoints |
| `number` | Numeric input | Port numbers |
| `select` | Dropdown options | `options: ["a", "b"]` |

## Field Properties

```json
{
  "key": "fieldName",           // Required: unique identifier
  "label": "Display Name",      // Required: human-readable label
  "type": "text",               // Required: field type
  "required": true,             // Optional: validation
  "sensitive": true,            // Optional: mask value
  "placeholder": "hint",        // Optional: input placeholder
  "default": "defaultValue",    // Optional: default value
  "help": "Help text here"      // Optional: shown below field
}
```

## Categories

Use any category name. Common ones:
- `ai` — AI/ML services
- `database` — Databases
- `email` — Email services
- `storage` — File storage
- `messaging` — Notifications, SMS
- `payment` — Payment processors
- `custom` — Your own category

## Validation

Custom services get basic "connection test" validation automatically:
- Sends a lightweight request to check if credentials work
- Returns success/failure without detailed API testing

For full validation, add a validator in `server.js` (advanced).

## Example: Complete Supabase Config

```json
{
  "services": {
    "supabase": {
      "id": "supabase",
      "name": "Supabase",
      "category": "database",
      "icon": "🟢",
      "description": "PostgreSQL database with realtime subscriptions",
      "fields": [
        { 
          "key": "url", 
          "label": "Project URL", 
          "type": "url", 
          "required": true, 
          "placeholder": "https://xxxxx.supabase.co",
          "help": "Found in Settings > API"
        },
        { 
          "key": "anonKey", 
          "label": "Anon Public Key", 
          "type": "password", 
          "required": true, 
          "sensitive": true,
          "help": "Client-side API key"
        },
        { 
          "key": "serviceKey", 
          "label": "Service Role Key", 
          "type": "password", 
          "required": false, 
          "sensitive": true,
          "help": "Server-side admin key (optional)"
        }
      ]
    }
  }
}
```

## Sharing Custom Services

Share your `custom-services.json` with your team:
- Commit to git (without values, just the schema)
- Or send the file to teammates
- They add their own credentials via the UI

## Import/Export in UI

Coming soon: Direct import/export of service definitions via the web interface.