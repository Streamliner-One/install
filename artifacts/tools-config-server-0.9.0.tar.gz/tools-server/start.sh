#!/bin/bash
# Start OpenClaw Tools Config Server

cd "$(dirname "$0")"

# Get Tailscale IP if available
if command -v tailscale &> /dev/null; then
    TAILSCALE_IP=$(tailscale ip -4 2>/dev/null | head -1)
fi

# Use Tailscale IP if available, otherwise localhost
if [ -n "$TAILSCALE_IP" ]; then
    BIND="${TAILSCALE_IP}:8443"
    echo "🔒 Tailscale detected — binding to ${BIND}"
else
    BIND="127.0.0.1:8080"
    echo "⚠️  Tailscale not detected — binding to localhost only"
fi

# Generate or use provided password
PASSWORD="${1:-$(openssl rand -hex 8)}"

echo ""
echo "╔══════════════════════════════════════════════════════════╗"
echo "║  OpenClaw Tools Config Server v0.1.0                     ║"
echo "╠══════════════════════════════════════════════════════════╣"
printf "║  URL:      http://%-36s ║\n" "${BIND}"
printf "║  Password: %-42s ║\n" "${PASSWORD}"
echo "╚══════════════════════════════════════════════════════════╝"
echo ""
echo "Press Ctrl+C to stop"
echo ""

exec node server.js --bind "${BIND}" --password "${PASSWORD}"